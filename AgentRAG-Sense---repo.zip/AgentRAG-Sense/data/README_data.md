# Obtaining the datasets

The raw files are not redistributed. Request or download them from the owners and place them in `data/raw/<dataset>/`.

| Dataset | Source | Files expected |
|---|---|---|
| SWaT (2015, A1) | iTrust Centre, SUTD: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/ | `SWaT_Dataset_Normal_v1.csv`, `SWaT_Dataset_Attack_v0.csv` |
| WADI (2017) | iTrust Centre, SUTD (same request form) | `WADI_14days_new.csv`, `WADI_attackdataLABLE.csv` |
| BATADAL | https://www.batadal.net/data.html | `BATADAL_dataset03.csv`, `BATADAL_dataset04.csv`, `BATADAL_test_dataset.csv` |

Then run:

```bash
python data/download_scripts/verify_checksums.py --manifest data/checksums.sha256
python -m data.split_indices.make_splits --config configs/datasets.yaml
```

The split indices are chronological (70/10/20), so no future window is used for training or threshold selection.
