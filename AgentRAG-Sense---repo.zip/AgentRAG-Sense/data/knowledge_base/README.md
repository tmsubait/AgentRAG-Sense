# Knowledge base artefacts

Produced by `make kb`:

* `kb_50000.json` (50,000 synthetic fault-resolution records: symptom, root cause, category, playbook, provenance)
* `faiss_ivfpq.index` (IVFPQ, nlist 256, m 64, 3.2 MB)
* `expert_labels_2000.csv` (anonymised expert labels and consensus, rater identities removed)
* `rating_form_template.csv`, `consensus_log.csv`

SHA-256 checksums are written to `checksums_kb.sha256` by `make checksums`.
