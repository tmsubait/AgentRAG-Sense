"""Verify raw dataset files against data/checksums.sha256."""
import argparse, hashlib, pathlib, sys

def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(chunk), b''):
            h.update(b)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', default='data/checksums.sha256')
    a = ap.parse_args()
    bad = 0
    for line in pathlib.Path(a.manifest).read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        digest, path = line.split(maxsplit=1)
        p = pathlib.Path(path)
        if not p.exists():
            print(f'MISSING  {path}'); bad += 1; continue
        if digest == 'TO_CONFIRM':
            print(f'UNPINNED {path}  {sha256(p)}'); continue
        ok = sha256(p) == digest
        print(('OK       ' if ok else 'MISMATCH ') + path)
        bad += (not ok)
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
