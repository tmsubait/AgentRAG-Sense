"""Chronological train/val/test split indices (Table 3)."""
import argparse, json, pathlib
import yaml
from agentrag.utils.io import load_dataset

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='configs/datasets.yaml')
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    out = pathlib.Path('data/split_indices')
    for name in cfg['datasets']:
        X, y, _ = load_dataset(name, cfg)
        n = len(y)
        tr = int(n * cfg['split']['train']); va = int(n * (cfg['split']['train'] + cfg['split']['val']))
        idx = {'train': [0, tr], 'val': [tr, va], 'test': [va, n], 'n': n}
        (out / f'{name}_splits.json').write_text(json.dumps(idx, indent=2))
        print(name, idx)

if __name__ == '__main__':
    main()
