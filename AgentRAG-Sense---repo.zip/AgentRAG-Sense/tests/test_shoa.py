from agentrag.shoa.validator import validate, order_actions
from agentrag.shoa.state import step, restored

def test_validate_and_order():
    pb = [{"action": "restore_slice", "slice_id": "s1"}, {"action": "isolate_slice", "slice_id": "s1"}]
    assert validate(pb, {"s1"})
    assert order_actions(pb)[0]["action"] == "isolate_slice"

def test_state_machine():
    s = step(step("degraded", "isolate_slice"), "restore_slice")
    assert s == "restored" and restored({"s1": s}, ["s1"])
