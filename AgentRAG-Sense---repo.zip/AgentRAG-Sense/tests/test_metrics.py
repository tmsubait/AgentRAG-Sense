from agentrag.utils.metrics import wilson_ci, prf1, cohen_kappa

def test_wilson_matches_paper():
    for p, lo, hi in [(0.979, 96.2, 98.8), (0.976, 95.9, 98.6), (0.967, 94.7, 97.9)]:
        a, b = wilson_ci(p * 500, 500)
        assert round(100 * a, 1) == lo and round(100 * b, 1) == hi
    a, b = wilson_ci(0.974 * 1500, 1500)
    assert round(100 * a, 1) == 96.5 and round(100 * b, 1) == 98.1

def test_prf1():
    assert prf1([1, 0, 1, 1], [1, 0, 0, 1])[2] == 0.8

def test_kappa_identity():
    assert cohen_kappa([1, 2, 3], [1, 2, 3]) == 1.0
