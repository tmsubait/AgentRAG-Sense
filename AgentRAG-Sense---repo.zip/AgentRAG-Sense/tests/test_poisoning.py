from agentrag.kb.poisoning import sem, admit

def test_sem_lexical():
    p = [{"action": "isolate_slice", "slice_id": "s1"}]
    assert sem(p, p) == 1.0

def test_admit_gate():
    r = {"category": 1, "playbook": [{"action": "scale_vnf", "slice_id": "s1"}]}
    assert admit(r, [r], True, 0.99) == "commit"
    assert admit(r, [r], True, 0.50) == "reject"
