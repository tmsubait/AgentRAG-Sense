from agentrag.kb.taxonomy import rule_label

def test_category_14_is_rule_based():
    assert rule_label({}) == 14

def test_multi_stage():
    assert rule_label({"network_flags": {"dos": True}, "process_flags": {"kinds": ["pump"]}}) == 13
