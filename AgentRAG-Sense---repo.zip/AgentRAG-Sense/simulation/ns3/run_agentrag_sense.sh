#!/usr/bin/env bash
# Usage: simulation/ns3/run_agentrag_sense.sh --dataset [swat|batadal|wadi] --seed [42|123]
set -euo pipefail
DATASET=swat; SEED=42
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dataset) DATASET="$2"; shift 2;;
    --seed) SEED="$2"; shift 2;;
    *) echo "unknown option $1"; exit 1;;
  esac
done
NS3_DIR="${NS3_DIR:-/opt/ns-3.42}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cp "$HERE/scenarios/agentrag-sense.cc" "$NS3_DIR/scratch/"
cd "$NS3_DIR"
./ns3 build scratch/agentrag-sense
./ns3 run "scratch/agentrag-sense --seed=${SEED} --dataset=${DATASET} --events=${HERE}/replay/events_${DATASET}.csv --out=/results/raw/seed_${SEED}/ns3_${DATASET}.csv" &
NS3_PID=$!
python -m simulation.ns3.replay.fault_replay --dataset "$DATASET" --seed "$SEED"
wait $NS3_PID
