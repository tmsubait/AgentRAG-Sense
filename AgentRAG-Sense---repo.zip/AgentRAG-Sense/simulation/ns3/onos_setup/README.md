# ONOS 2.7 setup

`docker compose up onos` starts the controller. The slice definitions in `slices.json` are loaded by
`experiments/common.py`. tau_API = 6 ms is the median REST response time measured under the simulated
control-plane load (`python -m experiments.latency_fog_jetson --measure-api`).
