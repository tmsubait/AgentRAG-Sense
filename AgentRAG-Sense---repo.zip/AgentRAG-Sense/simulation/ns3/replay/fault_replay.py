"""Replays the 500 multi-slice fault events into the AgentRAG-Sense pipeline and the HITL console,
logging the per-event terms of Eq. (10): tau_det, tau_eff, tau_queue, tau_exec, tau_ack and MTTR."""
import argparse, csv, json, pathlib
import numpy as np

def sample_events(dataset, n=500, seed=42):
    rng = np.random.default_rng(seed)
    ev = json.load(open(f"simulation/ns3/replay/candidate_events_{dataset}.json"))
    multi = [e for e in ev if len(e["affected_slices"]) >= 2]
    idx = rng.choice(len(multi), size=min(n, len(multi)), replace=False)
    return [multi[i] for i in sorted(idx)]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="swat"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--n", type=int, default=500)
    a = ap.parse_args()
    from experiments.common import build_system
    sysm = build_system(a.dataset, a.seed)
    out = pathlib.Path(f"results/raw/seed_{a.seed}/mttr_events_{a.dataset}.csv"); out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["event_id", "n_slices", "tau_det", "tau_ret", "tau_gen", "tau_rem", "tau_queue", "tau_exec", "tau_ack", "mttr_s"])
        for e in sample_events(a.dataset, a.n, a.seed):
            r = sysm.replay(e)
            w.writerow([e["event_id"], len(e["affected_slices"]), r["tau_det"], r["tau_ret"], r["tau_gen"], r["tau_rem"],
                        r["tau_queue"], r["tau_exec"], r["tau_ack"], r["mttr_s"]])
    print(out)

if __name__ == "__main__":
    main()
