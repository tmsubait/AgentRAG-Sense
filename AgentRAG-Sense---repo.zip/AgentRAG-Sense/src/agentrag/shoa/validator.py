"""Playbook schema validation V(p) of Eq. (29) and the conservative default of Eq. (30)."""
A_VALID = {"isolate_slice", "reroute_flow", "scale_vnf", "restore_slice"}

def validate(playbook, known_slices):
    if not isinstance(playbook, list) or not playbook:
        return False
    return all(isinstance(a, dict) and a.get("action") in A_VALID and a.get("slice_id") in known_slices
               for a in playbook)

def default_action(node_scores, slice_of_node):
    j = max(node_scores, key=node_scores.get)
    return [{"action": "isolate_slice", "slice_id": slice_of_node[j]}]

CONTAINMENT = ("isolate_slice", "reroute_flow")

def order_actions(playbook):
    """Containment before scale_vnf and restore_slice (Step 3 ordering rule)."""
    return sorted(playbook, key=lambda a: 0 if a["action"] in CONTAINMENT else 1)
