"""Slice state machine (Eq. 31) and network-level restoration condition (Eq. 32)."""
TRANSITIONS = {
    ("degraded", "isolate_slice"): "isolated",
    ("degraded", "reroute_flow"): "rerouted",
    ("isolated", "reroute_flow"): "rerouted",
    ("rerouted", "scale_vnf"): "scaled",
    ("isolated", "scale_vnf"): "scaled",
    ("degraded", "scale_vnf"): "scaled",
    ("isolated", "restore_slice"): "restored",
    ("rerouted", "restore_slice"): "restored",
    ("scaled", "restore_slice"): "restored",
}

def step(state, action):
    return TRANSITIONS.get((state, action), state)

def restored(states, affected):
    return all(states.get(j) == "restored" for j in affected)
