"""Self-Healing Orchestrator Agent: translation (Eq. 8, 24), ParMap over affected slices (Eq. 25),
operator confirmation gate for categories 9 to 14, restoration check (Eq. 32).

Timing terms recorded per event (Eq. 10): tau_rem (dispatch), tau_exec (until all slices restored), tau_ack.
"""
import json, time
from concurrent.futures import ThreadPoolExecutor
from agentrag.shoa.validator import validate, default_action, order_actions

class Orchestrator:
    def __init__(self, client, mapping_path="docs/playbook_mapping.json", m_max=4, confirm=None, poll_s=0.1):
        self.c = client; self.m_max = m_max; self.poll_s = poll_s
        self.mapping = json.load(open(mapping_path))
        self.confirm = confirm or (lambda event: True)   # operator gate, simulated in NS-3 runs

    def _run_slice(self, slice_actions, category, event):
        t_rem = 0.0
        for a in order_actions(slice_actions):
            if a["action"] == "restore_slice" and self.mapping["categories"][str(category)]["operator_confirmation"]:
                if not self.confirm(event):
                    return {"slice": a["slice_id"], "restored": False, "tau_rem": t_rem}
            code, dt = getattr(self.c, a["action"])(a["slice_id"], **a.get("params", {}))
            t_rem += dt
        return {"slice": slice_actions[0]["slice_id"], "tau_rem": t_rem}

    def remediate(self, explanation, affected, node_scores, slice_of_node, category, event=None):
        pb = explanation.get("playbook", [])
        if not validate(pb, set(affected)):
            pb = default_action(node_scores, slice_of_node)
        by_slice = {}
        for a in pb:
            by_slice.setdefault(a["slice_id"], []).append(a)
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=self.m_max) as ex:
            res = list(ex.map(lambda s: self._run_slice(by_slice[s], category, event), by_slice))
        t_dispatch = time.perf_counter() - t0
        while not all(self.c.slice_state(j) == "restored" for j in by_slice):
            time.sleep(self.poll_s)
        t_exec = time.perf_counter() - t0 - t_dispatch
        ta = time.perf_counter(); _ = [self.c.slice_state(j) for j in by_slice]; t_ack = time.perf_counter() - ta
        return {"tau_rem": max(r["tau_rem"] for r in res), "tau_exec": t_exec, "tau_ack": t_ack,
                "slices": list(by_slice), "playbook": pb}
