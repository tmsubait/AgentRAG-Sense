"""Thin ONOS 2.7 northbound REST client used by the SHOA (Eq. 24)."""
import os, time
import requests

class ONOSClient:
    def __init__(self, base=None, auth=("onos", "rocks"), timeout=5.0):
        self.base = base or os.environ.get("ONOS_URL", "http://localhost:8181/onos/v1")
        self.s = requests.Session(); self.s.auth = auth; self.timeout = timeout

    def _post(self, path, payload):
        t0 = time.perf_counter()
        r = self.s.post(f"{self.base}/{path}", json=payload, timeout=self.timeout)
        return r.status_code, time.perf_counter() - t0

    def isolate_slice(self, slice_id, **p):
        return self._post(f"slices/{slice_id}/isolate", p)

    def reroute_flow(self, slice_id, **p):
        return self._post(f"slices/{slice_id}/reroute", p)

    def scale_vnf(self, slice_id, **p):
        return self._post(f"slices/{slice_id}/vnf/scale", p)

    def restore_slice(self, slice_id, **p):
        return self._post(f"slices/{slice_id}/restore", p)

    def slice_state(self, slice_id):
        r = self.s.get(f"{self.base}/slices/{slice_id}/state", timeout=self.timeout)
        return r.json().get("state", "unknown")
