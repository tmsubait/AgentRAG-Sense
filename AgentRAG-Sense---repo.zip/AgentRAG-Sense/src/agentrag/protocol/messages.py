"""Typed inter-agent message of Eq. (27)."""
from dataclasses import dataclass, field
import time, uuid

@dataclass(order=True)
class Message:
    priority: int
    created: float = field(default_factory=time.perf_counter, compare=False)
    src: str = field(default="", compare=False)
    dst: str = field(default="", compare=False)
    kind: str = field(default="", compare=False)
    payload: dict = field(default_factory=dict, compare=False)
    msg_id: str = field(default_factory=lambda: uuid.uuid4().hex, compare=False)
