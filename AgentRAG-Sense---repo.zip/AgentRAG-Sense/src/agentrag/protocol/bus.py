"""Bounded priority FIFO message bus, Eq. (28): delay <= Q/(mu M) + tau_bus."""
import queue, time

class MessageBus:
    def __init__(self, capacity=256):
        self.q = queue.PriorityQueue(maxsize=capacity)
        self.wait_times = []

    def send(self, msg, block=True, timeout=None):
        self.q.put(msg, block=block, timeout=timeout)

    def recv(self, timeout=None):
        m = self.q.get(timeout=timeout)
        self.wait_times.append(time.perf_counter() - m.created)   # contributes to tau_queue
        return m

    def utilisation(self):
        return self.q.qsize() / self.q.maxsize
