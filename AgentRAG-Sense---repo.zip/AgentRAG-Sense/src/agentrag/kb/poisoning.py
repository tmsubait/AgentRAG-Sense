"""Knowledge-base integrity guard, Eqs. (26), (35), (36).

Sem(.,.) is a lexical operator: exact-match token overlap (Jaccard) between action token sequences. It resists
verbatim replay poisoning only; paraphrase-based poisoning is outside its coverage (Section 6.4).
"""
import numpy as np

def tokens(playbook):
    return {f"{a['action']}:{a.get('slice_id', '')}" for a in playbook}

def sem(p1, p2):
    a, b = tokens(p1), tokens(p2)
    return len(a & b) / len(a | b) if a | b else 1.0

def poison_score(new_rec, neighbours):
    """1 minus the mean lexical agreement with the retrieved neighbours of the same category."""
    same = [r for r in neighbours if r["category"] == new_rec["category"]]
    if not same:
        return 1.0
    return 1.0 - float(np.mean([sem(new_rec["playbook"], r["playbook"]) for r in same]))

def admit(new_rec, neighbours, schema_valid, accuracy, delta_p=0.30, alpha=0.95):
    if accuracy < alpha:                      # quality gate, Eq. (26)
        return "reject"
    if poison_score(new_rec, neighbours) <= delta_p and schema_valid:
        return "commit"                       # Eq. (36)
    return "quarantine"
