"""Deterministic taxonomy rules used for the 48,000 rule-labelled records (Step 2)."""
import csv

def load_taxonomy(path="docs/taxonomy_14_categories.csv"):
    with open(path) as f:
        return {int(r["id"]): r for r in csv.DictReader(f)}

def rule_label(event):
    """event: dict with flagged process channels and network-layer indicators produced in Step 1.

    Returns a category id in 1..14. Category 14 is assigned when no rule matches; it does not depend on kappa.
    """
    proc = event.get("process_flags", {})
    net = event.get("network_flags", {})
    matched = []
    if net.get("replay"): matched.append(9)
    if net.get("fdi"): matched.append(10)
    if net.get("dos"): matched.append(11)
    if net.get("mitm"): matched.append(12)
    kinds = proc.get("kinds", [])
    n_sensor = proc.get("n_sensor_channels", 0)
    if "pump" in kinds: matched.append(3)
    if "valve" in kinds: matched.append(4)
    if "flow" in kinds: matched.append(5)
    if "pressure" in kinds: matched.append(6)
    if "level" in kinds: matched.append(7)
    if "dosing" in kinds: matched.append(8)
    if not matched and n_sensor >= 2: matched.append(2)
    if not matched and n_sensor == 1: matched.append(1)
    if len(set(matched)) >= 2:
        return 13
    return matched[0] if matched else 14
