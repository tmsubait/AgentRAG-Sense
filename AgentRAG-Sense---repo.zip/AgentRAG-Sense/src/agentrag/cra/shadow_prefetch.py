"""Shadow CRA thread: pre-fetches retrieval results for queued queries when utilisation rho > 0.8 (Section 6.3)."""
import threading, queue

class ShadowPrefetcher:
    def __init__(self, retriever, rho_threshold=0.80):
        self.r = retriever; self.th = rho_threshold
        self.cache = {}; self.q = queue.Queue(); self._stop = threading.Event()
        self.t = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.t.start()

    def offer(self, event_id, symptom, rho):
        if rho > self.th:
            self.q.put((event_id, symptom))

    def get(self, event_id):
        return self.cache.pop(event_id, None)

    def _run(self):
        while not self._stop.is_set():
            try:
                eid, s = self.q.get(timeout=0.05)
            except queue.Empty:
                continue
            self.cache[eid] = self.r.retrieve(s)

    def stop(self):
        self._stop.set()
