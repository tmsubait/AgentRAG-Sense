"""Sentence encoder phi of Eq. (4). Backend and projection are set in configs/encoder.yaml (TO_CONFIRM items)."""
import numpy as np

class Encoder:
    def __init__(self, cfg):
        self.cfg = cfg; self.backend = cfg["backend"]
        if self.backend == "sentence_transformers":
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(cfg["sentence_transformers_model"])
        elif self.backend == "phi3_mean_pool_projection":
            import torch
            from transformers import AutoTokenizer, AutoModel
            self.torch = torch
            self.tok = AutoTokenizer.from_pretrained(cfg["phi3_model"])
            self.model = AutoModel.from_pretrained(cfg["phi3_model"], torch_dtype=torch.float16).eval()
            self.proj = np.load(cfg["projection_file"]).astype(np.float32)
        else:
            raise ValueError(self.backend)

    def encode(self, texts):
        if self.backend == "sentence_transformers":
            e = self.model.encode(texts, convert_to_numpy=True)
        else:
            with self.torch.no_grad():
                b = self.tok(texts, return_tensors="pt", padding=True, truncation=True, max_length=256)
                h = self.model(**b).last_hidden_state.float()
                m = b["attention_mask"].unsqueeze(-1).float()
                pooled = ((h * m).sum(1) / m.sum(1)).cpu().numpy()
            e = pooled @ self.proj
        e = e.astype(np.float32)
        if self.cfg.get("normalize", True):
            e /= np.linalg.norm(e, axis=1, keepdims=True) + 1e-12
        return e
