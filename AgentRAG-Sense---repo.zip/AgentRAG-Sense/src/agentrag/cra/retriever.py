"""Context Retriever Agent: top-k retrieval (Eq. 5) and retrieval confidence kappa_t (Eq. 22)."""
import json
import numpy as np
from agentrag.cra import index as ix

class ContextRetriever:
    def __init__(self, encoder, index_path, kb_json, k=5, nprobe=16):
        self.enc = encoder; self.k = k
        self.index = ix.load(index_path, nprobe)
        self.kb = json.load(open(kb_json))["records"]

    def retrieve(self, symptom):
        q = self.enc.encode([symptom])
        sims, ids = ix.search(self.index, q, self.k)
        recs = [self.kb[i] for i in ids[0] if i >= 0]
        kappa = float(np.mean(sims[0][: len(recs)])) if recs else 0.0   # mean cosine similarity
        return recs, kappa, q[0]
