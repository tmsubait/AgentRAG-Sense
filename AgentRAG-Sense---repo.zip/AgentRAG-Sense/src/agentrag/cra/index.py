"""FAISS IVFPQ index of Eqs. (19) and (20): nlist 256, m 64, 8-bit codes, nprobe 16."""
import faiss
import numpy as np

def build_ivfpq(emb, nlist=256, m=64, nbits=8, seed=42):
    d = emb.shape[1]
    quant = faiss.IndexFlatIP(d)
    index = faiss.IndexIVFPQ(quant, d, nlist, m, nbits, faiss.METRIC_INNER_PRODUCT)
    index.cp.seed = seed
    index.train(emb)
    index.add(emb)
    return index

def build_flat(emb):
    index = faiss.IndexFlatIP(emb.shape[1]); index.add(emb); return index

def save(index, path):
    faiss.write_index(index, str(path))

def load(path, nprobe=16):
    index = faiss.read_index(str(path))
    if hasattr(index, "nprobe"):
        index.nprobe = nprobe
    return index

def search(index, q, k=5):
    sims, ids = index.search(np.ascontiguousarray(q, dtype=np.float32), k)
    return sims, ids
