"""AgentRAG-Sense: multi-agent RAG for anomaly explanation and self-healing in 6G IIoT fog networks."""
__version__ = "1.0.0"
