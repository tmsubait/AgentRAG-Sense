"""Dilated causal TCN backbone of the Fault Detector Agent, Eqs. (15) and (16)."""
import torch
import torch.nn as nn

class CausalBlock(nn.Module):
    def __init__(self, c_in, c_out, k, d, p):
        super().__init__()
        self.pad = (k - 1) * d
        self.conv1 = nn.utils.parametrizations.weight_norm(nn.Conv1d(c_in, c_out, k, dilation=d))
        self.conv2 = nn.utils.parametrizations.weight_norm(nn.Conv1d(c_out, c_out, k, dilation=d))
        self.act = nn.ReLU(); self.drop = nn.Dropout(p)
        self.res = nn.Conv1d(c_in, c_out, 1) if c_in != c_out else nn.Identity()

    def forward(self, x):
        h = nn.functional.pad(x, (self.pad, 0))
        h = self.drop(self.act(self.conv1(h)))
        h = nn.functional.pad(h, (self.pad, 0))
        h = self.drop(self.act(self.conv2(h)))
        return self.act(h + self.res(x))

class TCNFDA(nn.Module):
    """h_t = TCN(X_{t-W:t}); a_t = sigmoid(w^T h_t + b)."""
    def __init__(self, n_channels, hidden=128, dilations=(1, 2, 4, 8, 16), kernel_size=3, dropout=0.1):
        super().__init__()
        layers, c = [], n_channels
        for d in dilations:
            layers.append(CausalBlock(c, hidden, kernel_size, d, dropout)); c = hidden
        self.net = nn.Sequential(*layers)
        self.head = nn.Linear(hidden, 1)

    def forward(self, x):                 # x: (B, W, D)
        h = self.net(x.transpose(1, 2))   # (B, h, W)
        h_t = h[:, :, -1]
        return torch.sigmoid(self.head(h_t)).squeeze(-1), h_t
