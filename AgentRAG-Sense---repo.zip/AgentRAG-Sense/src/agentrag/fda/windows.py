"""Sliding windows of length W over standardised sensor streams."""
import numpy as np
import torch
from torch.utils.data import Dataset

class WindowDataset(Dataset):
    def __init__(self, X, y, W=60, mean=None, std=None):
        self.mean = X.mean(0) if mean is None else mean
        self.std = (X.std(0) + 1e-6) if std is None else std
        self.X = ((X - self.mean) / self.std).astype(np.float32)
        self.y = y.astype(np.float32)
        self.W = W

    def __len__(self):
        return len(self.y) - self.W + 1

    def __getitem__(self, i):
        j = i + self.W
        return torch.from_numpy(self.X[i:j]), torch.tensor(self.y[j - 1])
