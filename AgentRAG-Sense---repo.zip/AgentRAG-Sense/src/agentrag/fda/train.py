"""TCN-FDA training with binary cross-entropy, Eq. (18). Threshold chosen on the validation split only."""
import argparse, pathlib
import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader
from agentrag.fda.tcn import TCNFDA
from agentrag.fda.windows import WindowDataset
from agentrag.utils.seed import set_seed
from agentrag.utils.io import load_dataset, load_splits, write_json
from agentrag.utils.metrics import prf1

def scores(model, loader, dev):
    model.eval(); out, ys = [], []
    with torch.no_grad():
        for xb, yb in loader:
            a, _ = model(xb.to(dev)); out.append(a.cpu().numpy()); ys.append(yb.numpy())
    return np.concatenate(out), np.concatenate(ys)

def best_threshold(a, y):
    grid = np.quantile(a, np.linspace(0.50, 0.999, 300))
    f1s = [prf1(y, a >= t)[2] for t in grid]
    i = int(np.argmax(f1s)); return float(grid[i]), float(f1s[i])

def train_one(name, cfg, ds_cfg, seed, out_dir):
    set_seed(seed)
    X, y, _ = load_dataset(name, ds_cfg)
    s = load_splits(name)
    tr = slice(*s["train"]); va = slice(*s["val"]); te = slice(*s["test"])
    dtr = WindowDataset(X[tr], y[tr], cfg["window"])
    dva = WindowDataset(X[va], y[va], cfg["window"], dtr.mean, dtr.std)
    dte = WindowDataset(X[te], y[te], cfg["window"], dtr.mean, dtr.std)
    g = torch.Generator().manual_seed(seed)
    ltr = DataLoader(dtr, batch_size=cfg["batch_size"], shuffle=True, generator=g, drop_last=True)
    lva = DataLoader(dva, batch_size=1024); lte = DataLoader(dte, batch_size=1024)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = TCNFDA(X.shape[1], cfg["hidden"], cfg["dilations"], cfg["kernel_size"], cfg["dropout"]).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    bce = torch.nn.BCELoss(); best, wait = -1.0, 0
    ckpt = pathlib.Path(out_dir) / f"tcn_{name}_seed{seed}.pt"; ckpt.parent.mkdir(parents=True, exist_ok=True)
    for ep in range(cfg["epochs"]):
        model.train()
        for xb, yb in ltr:
            opt.zero_grad(); a, _ = model(xb.to(dev)); loss = bce(a, yb.to(dev)); loss.backward(); opt.step()
        a, yv = scores(model, lva, dev); th, f1v = best_threshold(a, yv)
        if f1v > best:
            best, wait = f1v, 0
            torch.save({"state": model.state_dict(), "theta": th, "mean": dtr.mean, "std": dtr.std}, ckpt)
        else:
            wait += 1
            if wait >= cfg["early_stopping_patience"]:
                break
    st = torch.load(ckpt, weights_only=False); model.load_state_dict(st["state"])
    a, yt = scores(model, lte, dev)
    p, r, f1 = prf1(yt, a >= st["theta"])
    res = {"dataset": name, "seed": seed, "theta": st["theta"], "P": p, "R": r, "F1_detector": f1}
    write_json(res, pathlib.Path("results/raw") / f"seed_{seed}" / f"fda_{name}.json")
    return res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/tcn_fda.yaml")
    ap.add_argument("--datasets_config", default="configs/datasets.yaml")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="models")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config)); ds_cfg = yaml.safe_load(open(a.datasets_config))
    for name in cfg["datasets"]:
        print(train_one(name, cfg, ds_cfg, a.seed, a.out))

if __name__ == "__main__":
    main()
