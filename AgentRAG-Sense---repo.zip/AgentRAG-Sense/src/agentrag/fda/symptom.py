"""Symptom descriptor of Eq. (17) and Step 1 of the knowledge-base construction (|z| > 3 over 300 samples)."""
import numpy as np

TEMPLATE = ("Anomaly detected at timestamp {t}: sensors [{channel_list}] deviated by "
            "[{magnitude_list}] sigma above normal; associated network slice: {slice_id}.")

def zscores(X, t, window=300):
    lo = max(0, t - window)
    ref = X[lo:t] if t - lo > 1 else X[: t + 1]
    mu = ref.mean(0); sd = ref.std(0) + 1e-6
    return (X[t] - mu) / sd

def describe(X, t, channels, slice_id, z_thr=3.0, window=300):
    z = zscores(X, t, window)
    idx = np.where(np.abs(z) > z_thr)[0]
    if len(idx) == 0:
        idx = np.argsort(-np.abs(z))[:1]
    return TEMPLATE.format(t=t, channel_list=", ".join(channels[i] for i in idx),
                           magnitude_list=", ".join(f"{abs(z[i]):.2f}" for i in idx), slice_id=slice_id), idx, z[idx]
