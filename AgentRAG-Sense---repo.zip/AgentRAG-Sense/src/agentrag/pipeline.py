"""Algorithm 1: AgentRAG-Sense inference procedure with per-stage timing."""
import time
import numpy as np
import torch
from agentrag.fda.symptom import describe
from agentrag.utils.timing import StageTimer

class AgentRAGSense:
    def __init__(self, fda, theta, retriever, generator, orchestrator, channels, mean, std, W=60, device="cpu"):
        self.fda, self.theta, self.cra, self.ega, self.shoa = fda.eval(), theta, retriever, generator, orchestrator
        self.channels, self.mean, self.std, self.W, self.dev = channels, mean, std, W, device
        self.timer = StageTimer()

    def step(self, X, t, slice_id, affected, node_scores, slice_of_node, use_rag=True, use_shoa=True):
        t_alert = time.perf_counter()
        with self.timer.stage("tau_det"):
            x = torch.from_numpy(((X[t - self.W + 1:t + 1] - self.mean) / self.std).astype(np.float32))[None]
            with torch.no_grad():
                a, _ = self.fda(x.to(self.dev))
            a = float(a)
        if a < self.theta:
            return {"alert": False, "a_t": a}
        symptom, idx, z = describe(X, t, self.channels, slice_id)
        with self.timer.stage("tau_ret"):
            recs, kappa, _ = self.cra.retrieve(symptom) if use_rag else ([], 0.0, None)
        with self.timer.stage("tau_gen"):
            expl = self.ega.explain(symptom, recs, kappa)
        if not expl["confirmed_alert"]:
            return {"alert": False, "a_t": a, "benign_transient": True, "explanation": expl}
        out = {"alert": True, "a_t": a, "symptom": symptom, "explanation": expl}
        if use_shoa:
            rem = self.shoa.remediate(expl, affected, node_scores, slice_of_node, expl.get("fault_category", 14))
            self.timer.add("tau_rem", rem["tau_rem"]); self.timer.add("tau_exec", rem["tau_exec"])
            self.timer.add("tau_ack", rem["tau_ack"])
            out["remediation"] = rem
            out["mttr_s"] = time.perf_counter() - t_alert
        return out
