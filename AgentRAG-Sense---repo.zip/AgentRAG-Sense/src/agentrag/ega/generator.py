"""Explanation Generator Agent: Phi-3-mini INT4 via llama.cpp with grammar-constrained JSON (Eqs. 6, 21 to 23).

Final-alert rule (Section 7.2): an FDA candidate is an alert only if the EGA confirms it; a root_cause equal to
"benign_transient" marks the candidate as a negative, which is logged and not forwarded to the SHOA.
"""
import json
import jsonschema
from agentrag.ega.prompt import build_prompt

BENIGN = "benign_transient"

class ExplanationGenerator:
    def __init__(self, cfg, kappa_min=0.65):
        from llama_cpp import Llama, LlamaGrammar
        self.cfg = cfg; self.kappa_min = kappa_min
        self.llm = Llama(model_path=cfg["model_path"], n_ctx=cfg["n_ctx"], n_gpu_layers=cfg["n_gpu_layers"],
                         seed=0, verbose=False)
        self.grammar = LlamaGrammar.from_file(cfg["json_grammar"])
        self.schema = json.load(open(cfg["json_schema"]))

    def set_seed(self, seed):
        self.llm.set_seed(seed)

    def explain(self, symptom, records, kappa):
        prompt = build_prompt(symptom, records)
        out = self.llm(prompt, max_tokens=self.cfg["max_new_tokens"], temperature=self.cfg["temperature"],
                       top_p=self.cfg["top_p"], grammar=self.grammar)
        text = out["choices"][0]["text"]
        try:
            c = json.loads(text); jsonschema.validate(c, self.schema); valid = True
        except (json.JSONDecodeError, jsonschema.ValidationError):
            c, valid = {"root_cause": "unparsed", "confidence": 0.0, "playbook": []}, False
        c["kappa"] = kappa
        c["review_flag"] = kappa < self.kappa_min                  # Eq. (23), does not block remediation
        c["confirmed_alert"] = c.get("root_cause") != BENIGN       # final-alert rule
        c["schema_valid"] = valid
        return c
