"""Prompt construction of Eq. (7). The template is fixed for all inference calls."""
import pathlib

TEMPLATE = pathlib.Path(__file__).with_name("prompt_template.txt").read_text().strip()

def serialise_record(r):
    return f"symptom: {r['symptom']} | root_cause: {r['root_cause']} | category: {r['category']} | playbook: {r['playbook']}"

def build_prompt(symptom, records):
    return TEMPLATE.format(symptom_descriptor=symptom,
                           top_k_records=" || ".join(serialise_record(r) for r in records))
