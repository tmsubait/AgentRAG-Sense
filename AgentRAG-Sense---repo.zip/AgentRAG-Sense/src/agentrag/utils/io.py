"""Dataset loading and result writing."""
import json, pathlib
import numpy as np
import pandas as pd

def load_dataset(name, cfg):
    spec = cfg["datasets"][name]
    root = pathlib.Path(cfg["raw_dir"]) / name
    frames = [pd.read_csv(root / f, skipinitialspace=True) for f in spec["files"]]
    df = pd.concat(frames, ignore_index=True)
    df.columns = [c.strip() for c in df.columns]
    lab = spec["label_col"]
    raw = df[lab]
    if name == "swat":
        y = (raw.astype(str).str.strip().str.lower() != "normal").astype(int).values
    elif name == "wadi":
        y = (raw.fillna(1).astype(int) == -1).astype(int).values
    else:
        y = (raw.fillna(0).astype(int) == 1).astype(int).values
    feats = df.drop(columns=[lab]).select_dtypes(include=[np.number])
    feats = feats.ffill().bfill().fillna(0.0)
    return feats.values.astype(np.float32), y, list(feats.columns)

def load_splits(name):
    return json.loads(pathlib.Path(f"data/split_indices/{name}_splits.json").read_text())

def write_table(rows, path):
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def write_json(obj, path):
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2))
    return p
