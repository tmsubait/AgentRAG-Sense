"""Wall-clock stage timers for tau_det, tau_ret, tau_gen, tau_rem, tau_queue, tau_exec, tau_ack."""
import time
from contextlib import contextmanager
from collections import defaultdict

class StageTimer:
    def __init__(self):
        self.records = defaultdict(list)

    @contextmanager
    def stage(self, name):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.records[name].append(time.perf_counter() - t0)

    def add(self, name, seconds):
        self.records[name].append(seconds)

    def summary(self):
        import numpy as np
        return {k: {"mean_s": float(np.mean(v)), "median_s": float(np.median(v)),
                    "std_s": float(np.std(v, ddof=1)) if len(v) > 1 else 0.0, "n": len(v)}
                for k, v in self.records.items()}
