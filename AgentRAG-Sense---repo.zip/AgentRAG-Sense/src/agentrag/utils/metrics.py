"""Detection, agreement and interval metrics used in Sections 7.2 and 7.12."""
from math import sqrt
import numpy as np

def prf1(y_true, y_pred):
    y_true = np.asarray(y_true).astype(int); y_pred = np.asarray(y_pred).astype(int)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f1

def wilson_ci(successes, n, z=1.959964):
    """Wilson score interval for a binomial proportion."""
    if n == 0:
        return (0.0, 0.0)
    ph = successes / n
    denom = 1 + z * z / n
    centre = (ph + z * z / (2 * n)) / denom
    half = z * sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / denom
    return centre - half, centre + half

def cohen_kappa(a, b):
    a = np.asarray(a); b = np.asarray(b)
    labels = np.union1d(a, b)
    po = float((a == b).mean())
    pe = sum(float((a == l).mean()) * float((b == l).mean()) for l in labels)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0

def explanation_accuracy(scores, threshold=4):
    """EA: share of explanations rated 4 or 5 on the 1 to 5 scale."""
    s = np.asarray(scores)
    return float((s >= threshold).mean()), int((s >= threshold).sum()), int(len(s))
