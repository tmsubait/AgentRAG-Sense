"""Step 3: category to ONOS action sequence (docs/playbook_mapping.json)."""
import json

def load_mapping(path="docs/playbook_mapping.json"):
    return json.load(open(path))

def playbook_for(category, slice_id, mapping):
    acts = mapping["categories"][str(category)]["actions"]
    return [{"action": a, "slice_id": slice_id} for a in acts]
