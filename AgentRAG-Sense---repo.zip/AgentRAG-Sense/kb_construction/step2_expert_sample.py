"""Step 2: stratified 2,000-record expert sample (about 4%) and rule labels for the remaining records."""
import numpy as np
import pandas as pd
from agentrag.kb.taxonomy import rule_label

def stratified_sample(events, n=2000, seed=42):
    df = pd.DataFrame(events)
    rng = np.random.default_rng(seed)
    frac = n / len(df)
    parts = [g.sample(n=max(1, int(round(len(g) * frac))), random_state=int(rng.integers(1 << 31)))
             for _, g in df.groupby("dataset")]
    s = pd.concat(parts)
    return s.iloc[:n]

def apply_rules(events):
    return [dict(e, category=rule_label(e), label_source="rule") for e in events]

def export_rating_form(sample, path):
    cols = ["record_id", "dataset", "symptom", "rater_A_category", "rater_B_category", "consensus_category", "notes"]
    f = sample[["record_id", "dataset", "symptom"]].copy()
    for c in cols[3:]:
        f[c] = ""
    f.to_csv(path, index=False)
