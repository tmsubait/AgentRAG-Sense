"""Step 1: anomaly windows to deterministic symptom descriptors (|z| > 3.0 over a 300-sample window)."""
import numpy as np
from agentrag.fda.symptom import describe

def anomaly_events(y):
    """Start index of every contiguous anomalous run."""
    y = np.asarray(y).astype(int)
    starts = np.where((y[1:] == 1) & (y[:-1] == 0))[0] + 1
    return ([0] if y[0] == 1 else []) + starts.tolist()

def map_dataset(X, y, channels, slice_of_channel, z_thr=3.0, window=300):
    out = []
    for t in anomaly_events(y):
        sid = slice_of_channel.get(int(np.argmax(np.abs(X[t] - X[max(0, t - window):t + 1].mean(0)))), "slice_0")
        s, idx, z = describe(X, t, channels, sid, z_thr, window)
        out.append({"t": int(t), "symptom": s, "channels": [channels[i] for i in idx],
                    "magnitudes": [float(abs(v)) for v in z], "slice_id": sid})
    return out
