"""Build the 50,000-record knowledge base and its FAISS IVFPQ index (Algorithm 2)."""
import argparse, json, pathlib
import numpy as np
import pandas as pd
import yaml
from agentrag.utils.io import load_dataset
from agentrag.utils.seed import set_seed
from agentrag.cra.encoder import Encoder
from agentrag.cra import index as ix
from kb_construction.step1_symptom_mapping import map_dataset
from kb_construction.step2_expert_sample import apply_rules
from kb_construction.step3_playbook_mapping import load_mapping, playbook_for

ROOT_CAUSE = {1: "sensor threshold crossing", 2: "correlated multi-sensor deviation", 3: "pump actuator fault",
              4: "valve actuator fault", 5: "flow-rate manipulation", 6: "pressure anomaly", 7: "tank level manipulation",
              8: "chemical dosing interference", 9: "network-layer replay attack", 10: "false data injection",
              11: "denial of service on the SCADA channel", 12: "man in the middle on the sensor bus",
              13: "multi-stage coordinated attack", 14: "unknown or novel anomaly"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/kb.yaml")
    ap.add_argument("--datasets_config", default="configs/datasets.yaml")
    ap.add_argument("--encoder_config", default="configs/encoder.yaml")
    ap.add_argument("--faiss_config", default="configs/faiss_ivfpq.yaml")
    ap.add_argument("--exclude_categories", default="", help="comma list, used by the category hold-out")
    ap.add_argument("--only_datasets", default="", help="comma list, used by the cross-dataset hold-out")
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    set_seed(42)
    cfg = yaml.safe_load(open(a.config)); dcfg = yaml.safe_load(open(a.datasets_config))
    fcfg = yaml.safe_load(open(a.faiss_config)); mapping = load_mapping(cfg["playbook_mapping"])
    events = []
    names = a.only_datasets.split(",") if a.only_datasets else list(dcfg["datasets"])
    for name in names:
        X, y, ch = load_dataset(name, dcfg)
        for e in map_dataset(X, y, ch, {}, cfg["zscore_threshold"], cfg["zscore_window"]):
            e["dataset"] = name; events.append(e)
    events = apply_rules(events)
    expert = pathlib.Path(cfg["expert_labels"])
    if expert.exists():   # consensus labels override rule labels for the 2,000 reviewed records
        ex = pd.read_csv(expert).set_index("record_id")["consensus_category"].to_dict()
        for i, e in enumerate(events):
            if i in ex:
                e["category"], e["label_source"] = int(ex[i]), "expert"
    excl = {int(c) for c in a.exclude_categories.split(",") if c}
    recs = []
    for i, e in enumerate(events):
        if e["category"] in excl:
            continue
        recs.append({"record_id": i, "dataset": e["dataset"], "symptom": e["symptom"], "category": e["category"],
                     "root_cause": ROOT_CAUSE[e["category"]], "playbook": playbook_for(e["category"], e["slice_id"], mapping),
                     "label_source": e["label_source"]})
    recs = recs[: cfg["records_total"]]
    out = pathlib.Path(cfg["out_json"].replace(".json", f"{a.tag}.json"))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"records": recs}))
    enc = Encoder(yaml.safe_load(open(a.encoder_config)))
    emb = np.concatenate([enc.encode([r["symptom"] for r in recs[i:i + 512]]) for i in range(0, len(recs), 512)])
    index = ix.build_ivfpq(emb, fcfg["nlist"], fcfg["m"], fcfg["nbits"])
    ix.save(index, cfg["out_index"].replace(".index", f"{a.tag}.index"))
    print(f"records={len(recs)} index={cfg['out_index']}")

if __name__ == "__main__":
    main()
