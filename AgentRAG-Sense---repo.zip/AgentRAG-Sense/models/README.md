# Model files

* `Phi-3-mini-4k-instruct-q4_0.gguf`: Phi-3-mini 3.8B converted and quantised with llama.cpp (command and commit in
  `configs/llm_phi3_int4.yaml`, TO_CONFIRM).
* `tcn_<dataset>_seed<s>.pt`: TCN-FDA checkpoints written by `make train`.
* `phi3_proj_3072x384.npy`: projection used by the encoder (TO_CONFIRM).
