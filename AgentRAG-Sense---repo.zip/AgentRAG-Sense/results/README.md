# Results

* `raw/seed_<s>/` per-seed JSON and CSV files (detector, final-alert metrics, timing, MTTR events)
* `tables/` CSV behind Tables 3 and 5 to 12, EA Wilson intervals and HITL summary
* `logs/` pipeline logs

Every figure script in `scripts/figures/` reads only files in this folder.
