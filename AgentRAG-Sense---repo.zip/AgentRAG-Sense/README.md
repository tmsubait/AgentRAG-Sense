# AgentRAG-Sense

Reproducibility package for the manuscript *A Multi-Agent Retrieval-Augmented Generation Framework for
Context-Aware Anomaly Explanation and Self-Healing in 6G Industrial IoT Fog Networks* (submitted to CMC).
The repository is anonymised for peer review.

AgentRAG-Sense couples four agents over a compressed fog-node knowledge base:

| Agent | Role | Code |
|---|---|---|
| Fault Detector Agent (FDA) | dilated TCN anomaly detector, symptom descriptor, Eqs. (15) to (18) | `src/agentrag/fda/` |
| Context Retriever Agent (CRA) | FAISS IVFPQ top-k retrieval, Eqs. (4), (5), (19), (20) | `src/agentrag/cra/` |
| Explanation Generator Agent (EGA) | Phi-3-mini INT4 with constrained JSON output, Eqs. (6), (7), (21) to (23) | `src/agentrag/ega/` |
| Self-Healing Orchestrator Agent (SHOA) | playbook to ONOS REST translation, ParMap, Eqs. (8), (24) to (26), (29) to (32) | `src/agentrag/shoa/` |

## Hardware

* Latency results: NVIDIA Jetson AGX Orin 32 GB, JetPack 6.0, 15 W power mode (`sudo nvpmodel -m <15W id>`).
* Functional fallback: any CUDA desktop GPU or CPU (`configs/hardware_profiles.yaml`, profile `desktop`).
  Absolute latencies differ from the paper on this profile.

## One-command setup

```bash
docker build -t agentrag-sense .
docker run --gpus all -v $PWD/data:/workspace/data agentrag-sense make all
# or
conda env create -f environment.yml && conda activate agentrag-sense && pip install -e .
```

## Data

SWaT, WADI (iTrust, SUTD) and BATADAL are **not redistributed**. Follow `data/README_data.md`, then run
`make data` to verify checksums and build the chronological split indices.

## Pipeline

```bash
make data      # checksums + chronological splits
make kb        # Steps 1 to 3 of the knowledge-base construction, FAISS IVFPQ index
make train     # TCN-FDA training (seed 42, plus the five-seed protocol)
make eval      # Tables 5 to 12
make figures   # Figures 5, 6 and 8 to 14 (600 dpi)
make all
```

Every paper table and figure is mapped to its command in `REPRODUCE.md`.

## Network simulation

```bash
simulation/ns3/run_agentrag_sense.sh --dataset swat --seed 42
```

Requires NS-3 3.42 and ONOS 2.7 (`docker-compose.yml` starts both).

## Items whose values are not reported in the manuscript

The following values are marked `TO_CONFIRM` in `configs/` and must be filled before the repository is
made public: sentence-embedding backend and projection file, sampling temperature and top-p, llama.cpp commit
hash and quantisation command, JetPack image digest. All other values are taken from Table 4 and Sections 4 to 7.

## Licence

Code: MIT (`LICENSE`). Third-party components keep their own licences (`THIRD_PARTY_NOTICES.md`).
