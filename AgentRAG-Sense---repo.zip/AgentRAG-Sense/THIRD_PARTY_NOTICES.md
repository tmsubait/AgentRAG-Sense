# Third-party components

| Component | Version | Licence |
|---|---|---|
| PyTorch | 2.2.2 | BSD-3-Clause |
| LangChain | 0.2.16 | MIT |
| FAISS | 1.8.0 | MIT |
| llama.cpp / llama-cpp-python | 0.2.90 | MIT |
| Phi-3-mini-4k-instruct | 3.8B | MIT (model card) |
| NS-3 | 3.42 | GPL-2.0 (used as an external simulator, not linked into this code) |
| ONOS | 2.7.0 | Apache-2.0 |
| matplotlib | 3.9.2 | PSF-based |

SWaT, WADI and BATADAL are distributed by their owners under their own terms and are not included.
