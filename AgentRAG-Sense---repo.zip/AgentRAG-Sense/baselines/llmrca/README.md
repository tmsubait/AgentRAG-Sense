# LLMRCA [33]

* Type: end to end
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: public code; SWaT only, BATADAL and WADI runs did not converge (logs in run_logs/)
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/llmrca_<dataset>.json` with keys P, R, F1, EA, status.
