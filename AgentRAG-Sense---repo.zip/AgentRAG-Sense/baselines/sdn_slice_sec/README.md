# SDN-Slice-Sec [11]

* Type: end to end, rule-based SDN/NFV
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: rule playbooks of the original framework
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/sdn_slice_sec_<dataset>.json` with keys P, R, F1, EA, status.
