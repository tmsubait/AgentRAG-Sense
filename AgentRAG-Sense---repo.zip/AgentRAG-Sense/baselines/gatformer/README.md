# GATformer [40]

* Type: detection only
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: official hyperparameters of the original paper
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/gatformer_<dataset>.json` with keys P, R, F1, EA, status.
