# LSTM-AE [39]

* Type: detection only
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: reconstruction-error threshold chosen on the validation split
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/lstm_ae_<dataset>.json` with keys P, R, F1, EA, status.
