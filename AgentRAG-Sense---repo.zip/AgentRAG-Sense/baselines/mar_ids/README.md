# MAR-IDS [41]

* Type: end to end, multi-agent RAG
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: SWaT only; feature extractor could not be mapped to BATADAL and WADI (logs in run_logs/)
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/mar_ids_<dataset>.json` with keys P, R, F1, EA, status.
