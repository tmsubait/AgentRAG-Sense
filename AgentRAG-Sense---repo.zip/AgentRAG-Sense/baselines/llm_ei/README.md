# LLM-EI [4]

* Type: end to end
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: LLM explanation without retrieval or agent coordination, same Phi-3-mini INT4
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/llm_ei_<dataset>.json` with keys P, R, F1, EA, status.
