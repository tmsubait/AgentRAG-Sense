# RAGLog [35]

* Type: end to end, single agent
* Protocol: same chronological splits, seed list and final-alert F1 definition as AgentRAG-Sense (Section 7.2).
* Notes: same KB and encoder as AgentRAG-Sense, no SDN integration
* Hyperparameters: `config.yaml` in this folder (TO_CONFIRM values must match the runs reported in Table 6).
* Output: `results/raw/seed_<s>/raglog_<dataset>.json` with keys P, R, F1, EA, status.
