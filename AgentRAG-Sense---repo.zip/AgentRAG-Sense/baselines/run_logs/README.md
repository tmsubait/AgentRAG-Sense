# Baseline run logs

Place the raw stdout and stderr of every baseline run here as `<method>_<dataset>_seed<s>.log`, including the
non-converging LLMRCA runs and the MAR-IDS feature-extraction failures on BATADAL and WADI that justify the
unavailable (–) cells of Table 6.
