"""Cross-dataset hold-out (Table 11): K rebuilt from SWaT records only, evaluated on the 500 WADI EA events."""
import subprocess, sys

def main():
    subprocess.run([sys.executable, "-m", "kb_construction.build_kb", "--only_datasets", "swat", "--tag", "_swat_only"], check=True)
    subprocess.run([sys.executable, "-m", "experiments.ea_evaluation.generate_for_rating", "--dataset", "wadi",
                    "--kb_tag", "_swat_only", "--out", "results/raw/holdout_cross_dataset_wadi.csv"], check=True)
    subprocess.run([sys.executable, "-m", "experiments.ea_evaluation.wilson_ci", "--ratings",
                    "results/raw/holdout_cross_dataset_wadi_rated.csv", "--tag", "holdout_cross_dataset"], check=True)

if __name__ == "__main__":
    main()
