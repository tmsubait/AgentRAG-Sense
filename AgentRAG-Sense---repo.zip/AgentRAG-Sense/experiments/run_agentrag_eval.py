"""Runs AgentRAG-Sense over a test split and writes final-alert P/R/F1 (Section 7.2 definition)."""
import argparse, json, pathlib
import numpy as np
import yaml
from agentrag.utils.io import load_dataset, load_splits, write_json
from agentrag.utils.metrics import prf1
from experiments.common import build_system

def evaluate(dataset, seed, variant="full", kb_tag=""):
    dcfg = yaml.safe_load(open("configs/datasets.yaml"))
    X, y, ch = load_dataset(dataset, dcfg); s = load_splits(dataset)
    sysm = build_system(dataset, seed, kb_tag); sysm.channels = ch
    W = sysm.W; preds, det = [], []
    for t in range(s["test"][0] + W - 1, s["test"][1]):
        out = sysm.step(X, t, "slice_0", ["slice_0"], {0: 1.0}, {0: "slice_0"},
                        use_rag=(variant != "no_rag"), use_shoa=False)
        det.append(int(out["a_t"] >= sysm.theta)); preds.append(int(out["alert"]))
    yt = y[s["test"][0] + W - 1: s["test"][1]]
    p, r, f1 = prf1(yt, preds); pd_, rd, f1d = prf1(yt, det)
    res = {"dataset": dataset, "seed": seed, "variant": variant, "P": p, "R": r, "F1_final_alert": f1,
           "P_detector": pd_, "R_detector": rd, "F1_detector": f1d, "timing": sysm.timer.summary()}
    write_json(res, pathlib.Path(f"results/raw/seed_{seed}/agentrag_sense_{variant}_{dataset}.json"))
    return res

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", default="swat"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--variant", default="full"); ap.add_argument("--kb_tag", default="")
    a = ap.parse_args(); print(evaluate(a.dataset, a.seed, a.variant, a.kb_tag))
