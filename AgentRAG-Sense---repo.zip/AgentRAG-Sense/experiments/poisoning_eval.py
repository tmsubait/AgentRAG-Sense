"""Knowledge-base growth and poison-quarantine rate over 500 simulated events (Figure 14).

Writes CSV files to results/raw/ that are read by scripts/figures/. Uses the agents built in experiments/common.py.
"""
import argparse, csv, pathlib, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--measure-api", action="store_true")
    a = ap.parse_args()
    out = pathlib.Path("results/raw/poisoning_eval.csv"); out.parent.mkdir(parents=True, exist_ok=True)
    run(a, out)
    print(out)

def run(args, out):
    from experiments import runners
    runners.poisoning_eval(args, out)

if __name__ == "__main__":
    main()
