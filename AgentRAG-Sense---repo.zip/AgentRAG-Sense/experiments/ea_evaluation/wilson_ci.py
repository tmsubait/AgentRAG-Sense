"""EA with 95% Wilson intervals per dataset and overall (Section 7.2), plus inter-rater kappa."""
import argparse
import pandas as pd
from agentrag.utils.metrics import wilson_ci, cohen_kappa
from agentrag.utils.io import write_table

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ratings", default="results/raw/ea_ratings_1500.csv")
    ap.add_argument("--tag", default="ea")
    a = ap.parse_args()
    df = pd.read_csv(a.ratings)
    rows = []
    groups = [(d, g) for d, g in df.groupby("dataset")] + [("overall", df)]
    for name, g in groups:
        k = int((g["consensus_score"] >= 4).sum()); n = len(g); lo, hi = wilson_ci(k, n)
        rows.append({"dataset": name, "n": n, "correct": k, "EA_pct": round(100 * k / n, 1),
                     "ci_low_pct": round(100 * lo, 1), "ci_high_pct": round(100 * hi, 1),
                     "kappa_raters": round(cohen_kappa(g["score_A"] >= 4, g["score_B"] >= 4), 3)})
    print(write_table(rows, f"results/tables/{a.tag}_wilson_ci.csv"))

if __name__ == "__main__":
    main()
