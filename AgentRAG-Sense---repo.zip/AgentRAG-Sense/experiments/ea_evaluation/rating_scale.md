# Explanation rating scale (Section 7.2)

| Score | Definition |
|---|---|
| 1 | root cause entirely incorrect (wrong fault category, wrong sensor channels) |
| 2 | partially correct root cause but wrong fault category |
| 3 | correct fault category but incomplete or partially wrong playbook |
| 4 | correct root cause and fault category with a minor playbook omission |
| 5 | fully correct root cause, fault category and complete actionable playbook |

Scores 4 and 5 count as correct for EA. Raters annotate independently from the raw sensor traces and the symptom
descriptor; the system explanation is shown only after both independent scores are recorded. Unresolved
disagreements take the lower score.
