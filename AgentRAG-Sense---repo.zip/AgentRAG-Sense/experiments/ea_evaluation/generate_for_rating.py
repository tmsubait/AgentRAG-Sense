"""Generates EGA explanations for the stratified evaluation sample and writes the blinded rating form."""
import argparse, csv, json
import yaml
from agentrag.utils.io import load_dataset
from experiments.common import build_system

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="swat"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--kb_tag", default=""); ap.add_argument("--categories", default="")
    ap.add_argument("--sample", default=None); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    sample = json.load(open(a.sample or f"data/split_indices/{a.dataset}_ea_sample_500.json"))
    if a.categories:
        keep = {int(c) for c in a.categories.split(",")}; sample = [e for e in sample if e["category"] in keep]
    X, y, ch = load_dataset(a.dataset, yaml.safe_load(open("configs/datasets.yaml")))
    sysm = build_system(a.dataset, a.seed, a.kb_tag); sysm.channels = ch
    with open(a.out, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["event_id", "dataset", "category", "symptom", "system_explanation"])
        for e in sample:
            out = sysm.step(X, e["t"], e["slice_id"], [e["slice_id"]], {0: 1.0}, {0: e["slice_id"]}, use_shoa=False)
            w.writerow([e["event_id"], a.dataset, e["category"], out.get("symptom", ""), json.dumps(out.get("explanation", {}))])

if __name__ == "__main__":
    main()
