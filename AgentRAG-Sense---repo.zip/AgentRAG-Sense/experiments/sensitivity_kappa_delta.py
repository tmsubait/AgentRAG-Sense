"""Table 12: kappa_min and delta_p sweeps on the SWaT validation split (chronologically disjoint from test)."""
import json, pathlib
import numpy as np
from agentrag.kb.poisoning import admit
from agentrag.utils.io import write_table

KAPPA = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75]
DELTA = [0.10, 0.20, 0.30, 0.40, 0.50]

def main():
    val = json.load(open("results/raw/seed_42/val_explanations_swat.json"))    # kappa_t, rated score per event
    rows = []
    for km in KAPPA:
        acc = [e for e in val if e["kappa"] >= km]          # accepted without review flag
        flagged = len(val) - len(acc)
        ea = np.mean([(e["score"] >= 4) for e in val if e["kappa"] >= km or e["reviewed_correct"]])
        rows.append({"param": "kappa_min", "value": km, "EA_pct": round(100 * ea, 1),
                     "review_flag_pct": round(100 * flagged / len(val), 1),
                     "auto_remediation_pct": round(100 * len(acc) / len(val), 1)})
    cand = json.load(open("results/raw/seed_42/kb_candidates_swat.json"))      # includes injected poisoned records
    for dp in DELTA:
        fq = np.mean([admit(c["record"], c["neighbours"], True, 1.0, dp) == "quarantine" for c in cand if not c["poisoned"]])
        fa = np.mean([admit(c["record"], c["neighbours"], True, 1.0, dp) == "commit" for c in cand if c["poisoned"]])
        rows.append({"param": "delta_p", "value": dp, "false_quarantine_pct": round(100 * fq, 1),
                     "false_admit_pct": round(100 * fa, 1), "sum_pct": round(100 * (fq + fa), 1)})
    print(write_table(rows, "results/tables/table12_sensitivity.csv"))

if __name__ == "__main__":
    main()
