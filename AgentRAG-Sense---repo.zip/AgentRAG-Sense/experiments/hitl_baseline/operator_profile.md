# HITL operator profile (anonymised)

* Network operations professional, three years of SDN management experience.
* Not familiar with the 14-category fault taxonomy before the study.
* Interface: screen-sharing session to the ONOS dashboard and domain documentation while NS-3 replays the same
  500 multi-slice events used for the MTTR measurement, over multiple sessions.
* Clock start: NS-3 alert emission. Clock stop: issuance of the correct ONOS REST API call.
* The AgentRAG-Sense MTTR stops at the ONOS acknowledgement of Eq. (32); `summarize_hitl.py` also reports the
  AgentRAG-Sense time to API issuance for an end-point-matched comparison.
