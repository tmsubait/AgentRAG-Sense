"""Mean, standard deviation, median and IQR of the HITL baseline, and the end-point-matched AgentRAG-Sense time."""
import glob
import numpy as np
import pandas as pd
from agentrag.utils.io import write_table

def main():
    h = pd.read_csv("experiments/hitl_baseline/hitl_timing_log.csv")
    d = h["duration_min"]
    a = pd.concat([pd.read_csv(f) for f in glob.glob("results/raw/seed_42/mttr_events_*.csv")])
    to_api = (a["tau_det"] + a["tau_ret"] + a["tau_gen"] + a["tau_rem"] + a["tau_queue"]).mean()
    rows = [{"metric": "HITL mean (min)", "value": round(d.mean(), 2)},
            {"metric": "HITL std (min)", "value": round(d.std(ddof=1), 2)},
            {"metric": "HITL median (min)", "value": round(d.median(), 2)},
            {"metric": "HITL IQR low (min)", "value": round(d.quantile(0.25), 2)},
            {"metric": "HITL IQR high (min)", "value": round(d.quantile(0.75), 2)},
            {"metric": "HITL sessions", "value": int(h["session_id"].nunique())},
            {"metric": "AgentRAG-Sense time to API issuance (s)", "value": round(float(to_api), 2)},
            {"metric": "AgentRAG-Sense MTTR to acknowledgement (s)", "value": round(float(a["mttr_s"].mean()), 2)}]
    print(write_table(rows, "results/tables/hitl_summary.csv"))

if __name__ == "__main__":
    main()
