"""Implementations behind the thin experiment entry points."""
import csv, json, time
import numpy as np
import yaml
from agentrag.cra import index as ix
from agentrag.cra.encoder import Encoder
from agentrag.shoa.onos_client import ONOSClient

def _w(out, header, rows):
    with open(out, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)

def ivfpq_sweep(args, out):
    kcfg = yaml.safe_load(open("configs/kb.yaml")); kb = json.load(open(kcfg["out_json"]))["records"]
    enc = Encoder(yaml.safe_load(open("configs/encoder.yaml")))
    emb = np.concatenate([enc.encode([r["symptom"] for r in kb[i:i + 512]]) for i in range(0, len(kb), 512)])
    rng = np.random.default_rng(args.seed); q = emb[rng.choice(len(emb), 1000, replace=False)]
    flat = ix.build_flat(emb); _, gt = ix.search(flat, q, 10)
    t0 = time.perf_counter(); ix.search(flat, q, 10); flat_ms = 1000 * (time.perf_counter() - t0) / len(q)
    rows = []
    for m in (16, 32, 48, 64, 96, 128):
        idx = ix.build_ivfpq(emb, 256, m, 8); idx.nprobe = 16
        t0 = time.perf_counter(); _, ids = ix.search(idx, q, 10); ms = 1000 * (time.perf_counter() - t0) / len(q)
        rec = np.mean([len(set(a) & set(b)) / 10 for a, b in zip(ids, gt)])
        rows.append([m, rec, ms, flat_ms])
    _w(out, ["m", "recall_at_10", "ivfpq_latency_ms", "flat_l2_latency_ms"], rows)

def latency_fog_jetson(args, out):
    rows = []
    if args.measure_api:
        c = ONOSClient()
        for _ in range(1000):
            t0 = time.perf_counter(); c.slice_state("slice_0"); rows.append(["tau_api", 1000 * (time.perf_counter() - t0)])
    _w(out, ["stage", "latency_ms"], rows)

def _from_raw(pattern, out, header):
    import glob, pandas as pd
    files = glob.glob(pattern)
    if files:
        pd.concat([pd.read_csv(f) for f in files]).to_csv(out, index=False)
    else:
        _w(out, header, [])

def throughput_lambda(args, out):
    _from_raw(f"results/raw/seed_{args.seed}/lambda_*.csv", out, ["lambda", "mttr_s", "throughput", "prefetch"])

def poisoning_eval(args, out):
    _from_raw(f"results/raw/seed_{args.seed}/kb_growth_*.csv", out, ["event", "kb_size", "quarantine_rate"])

def k_sweep(args, out):
    _from_raw(f"results/raw/seed_{args.seed}/k_sweep_*.csv", out, ["k", "F1", "EA"])

def slm_comparison(args, out):
    _from_raw(f"results/raw/seed_{args.seed}/slm_*.csv", out, ["model", "params_b", "memory_gb", "latency_ms", "EA"])

def dataset_stats(args, out):
    from agentrag.utils.io import load_dataset
    dcfg = yaml.safe_load(open("configs/datasets.yaml")); rows = []
    for n in dcfg["datasets"]:
        X, y, _ = load_dataset(n, dcfg); rows.append([n, len(y), X.shape[1], round(100 * y.mean(), 1)])
    _w(out, ["dataset", "samples", "features", "anomaly_pct"], rows)
