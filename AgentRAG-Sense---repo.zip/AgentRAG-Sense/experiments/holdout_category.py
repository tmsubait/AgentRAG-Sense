"""Category hold-out (Table 11): records of categories 9 to 12 removed from K; category 13 retained.
EA is computed only on test events whose consensus label is in 9 to 12, overall and per category."""
import subprocess, sys
import pandas as pd
from agentrag.utils.metrics import wilson_ci
from agentrag.utils.io import write_table

def main():
    subprocess.run([sys.executable, "-m", "kb_construction.build_kb", "--exclude_categories", "9,10,11,12", "--tag", "_no9to12"], check=True)
    for ds in ("swat", "batadal", "wadi"):
        subprocess.run([sys.executable, "-m", "experiments.ea_evaluation.generate_for_rating", "--dataset", ds,
                        "--kb_tag", "_no9to12", "--categories", "9,10,11,12",
                        "--out", f"results/raw/holdout_category_{ds}.csv"], check=True)
    rated = "results/raw/holdout_category_rated.csv"     # filled by the raters with the blinded form
    df = pd.read_csv(rated)
    rows = []
    for c, g in [("9 to 12", df)] + [(str(k), df[df["category"] == k]) for k in (9, 10, 11, 12)]:
        k = int((g["consensus_score"] >= 4).sum()); n = len(g); lo, hi = wilson_ci(k, n)
        rows.append({"categories": c, "n": n, "EA_pct": round(100 * k / n, 1) if n else None,
                     "ci_low": round(100 * lo, 1), "ci_high": round(100 * hi, 1)})
    print(write_table(rows, "results/tables/table11_holdout_category.csv"))

if __name__ == "__main__":
    main()
