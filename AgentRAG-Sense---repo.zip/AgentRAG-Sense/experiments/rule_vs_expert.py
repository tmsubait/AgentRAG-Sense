"""Table 10: deterministic rule labels versus expert consensus labels on the 2,000 reviewed records.
The rule labeller is applied without access to the consensus labels."""
import json
import numpy as np
import pandas as pd
from agentrag.kb.taxonomy import rule_label
from agentrag.utils.metrics import cohen_kappa
from agentrag.utils.io import write_table

GROUPS = {"1 to 3": [1, 2, 3], "4 to 6": [4, 5, 6], "7 to 8": [7, 8], "9 to 12": [9, 10, 11, 12], "13": [13], "14": [14]}

def main():
    ex = pd.read_csv("data/knowledge_base/expert_labels_2000.csv")
    events = json.load(open("data/knowledge_base/step1_events.json"))
    ev = {e["record_id"]: e for e in events}
    ex["rule_category"] = [rule_label(ev[i]) for i in ex["record_id"]]
    rows = []
    for g, cats in GROUPS.items():
        s = ex[ex["consensus_category"].isin(cats)]
        rows.append({"group": g, "n": len(s), "agreement_pct": round(100 * float((s["rule_category"] == s["consensus_category"]).mean()), 1),
                     "kappa": round(cohen_kappa(s["rule_category"], s["consensus_category"]), 3)})
    rows.append({"group": "all", "n": len(ex), "agreement_pct": round(100 * float((ex["rule_category"] == ex["consensus_category"]).mean()), 1),
                 "kappa": round(cohen_kappa(ex["rule_category"], ex["consensus_category"]), 3)})
    cm = pd.crosstab(ex["consensus_category"], ex["rule_category"]).reindex(index=range(1, 15), columns=range(1, 15), fill_value=0)
    cm.to_csv("results/tables/table10_confusion_14x14.csv")
    print(write_table(rows, "results/tables/table10_rule_vs_expert.csv"))

if __name__ == "__main__":
    main()
