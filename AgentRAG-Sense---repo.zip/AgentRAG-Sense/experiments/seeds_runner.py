"""Five-seed protocol and seed-123 robustness run (Section 8.1). Writes results/raw/seed_<s>/."""
import argparse, subprocess, sys

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", default="42,43,44,45,46")
    a = ap.parse_args()
    for s in a.seeds.split(","):
        subprocess.run([sys.executable, "-m", "agentrag.fda.train", "--seed", s], check=True)
        for ds in ("swat", "batadal", "wadi"):
            subprocess.run([sys.executable, "-m", "experiments.run_agentrag_eval", "--dataset", ds, "--seed", s], check=True)
            subprocess.run(["bash", "simulation/ns3/run_agentrag_sense.sh", "--dataset", ds, "--seed", s], check=True)

if __name__ == "__main__":
    main()
