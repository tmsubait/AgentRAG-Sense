"""Table 7: decomposition of the mean MTTR over the 500 multi-slice events into the terms of Eq. (10)."""
import glob
import pandas as pd
from agentrag.utils.io import write_table

def main(seed=42):
    df = pd.concat([pd.read_csv(f) for f in glob.glob(f"results/raw/seed_{seed}/mttr_events_*.csv")])
    df["compute"] = df[["tau_det", "tau_ret", "tau_gen", "tau_rem"]].sum(axis=1)
    total = df["mttr_s"].mean()
    rows = []
    for name, col in [("Detection, retrieval, generation and API dispatch", "compute"),
                      ("Message-bus scheduling and queueing", "tau_queue"),
                      ("Action execution, SDN propagation and slice convergence", "tau_exec"),
                      ("ONOS acknowledgement and restoration check", "tau_ack")]:
        m = df[col].mean(); rows.append({"component": name, "mean_s": round(m, 3), "share_pct": round(100 * m / total, 1)})
    rows.append({"component": "Total (mean MTTR)", "mean_s": round(total, 2), "share_pct": 100.0})
    rows.append({"component": "Residual (total minus sum of terms)", "mean_s": round(total - sum(r["mean_s"] for r in rows[:4]), 3), "share_pct": None})
    by = df.groupby(df["n_slices"].clip(upper=4))["mttr_s"].agg(["mean", "std", "count"]).reset_index()
    by.to_csv("results/tables/table7_mttr_by_slices.csv", index=False)
    share3 = float((df["n_slices"] >= 3).mean())
    print(write_table(rows, "results/tables/table7_mttr.csv"), "share of events with >=3 slices:", round(share3, 3))

if __name__ == "__main__":
    main()
