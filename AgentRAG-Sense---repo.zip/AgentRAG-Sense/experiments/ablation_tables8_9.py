"""Table 8 (ablation) and Table 9 (cumulative contribution) on SWaT.
All F1 values use the final-alert definition; B1 and w/o RAG equal the TCN detector alone."""
import argparse, json, pathlib
from agentrag.utils.io import write_table

VARIANTS_8 = ["full", "no_rag", "no_multi_agent", "no_shoa", "flat_l2", "threshold_fda"]
VARIANTS_9 = ["b1_detection_only", "b2_single_agent_rag", "b3_multi_agent_no_shoa", "full"]

def load(v, seed):
    p = pathlib.Path(f"results/raw/seed_{seed}/agentrag_sense_{v}_swat.json")
    return json.loads(p.read_text()) if p.exists() else {}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--table", type=int, default=8); ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    vs = VARIANTS_8 if a.table == 8 else VARIANTS_9
    rows = [{"variant": v, "F1": load(v, a.seed).get("F1_final_alert"), "EA": load(v, a.seed).get("EA"),
             "MTTR_s": load(v, a.seed).get("MTTR_s")} for v in vs]
    print(write_table(rows, f"results/tables/table{a.table}_{'ablation' if a.table == 8 else 'cumulative'}.csv"))

if __name__ == "__main__":
    main()
