"""Shared loaders for experiments: builds the four agents from configs."""
import json, yaml
import torch
from agentrag.fda.tcn import TCNFDA
from agentrag.cra.encoder import Encoder
from agentrag.cra.retriever import ContextRetriever
from agentrag.ega.generator import ExplanationGenerator
from agentrag.shoa.onos_client import ONOSClient
from agentrag.shoa.orchestrator import Orchestrator
from agentrag.pipeline import AgentRAGSense
from agentrag.utils.seed import set_seed

def cfg(path):
    return yaml.safe_load(open(path))

def build_system(dataset, seed=42, kb_tag="", n_channels=None):
    set_seed(seed)
    tcfg = cfg("configs/tcn_fda.yaml"); acfg = cfg("configs/agents_protocol.yaml")
    st = torch.load(f"models/tcn_{dataset}_seed{seed}.pt", weights_only=False)
    n_channels = n_channels or st["mean"].shape[0]
    fda = TCNFDA(n_channels, tcfg["hidden"], tcfg["dilations"], tcfg["kernel_size"], tcfg["dropout"])
    fda.load_state_dict(st["state"])
    enc = Encoder(cfg("configs/encoder.yaml"))
    kcfg = cfg("configs/kb.yaml"); fcfg = cfg("configs/faiss_ivfpq.yaml")
    cra = ContextRetriever(enc, kcfg["out_index"].replace(".index", f"{kb_tag}.index"),
                           kcfg["out_json"].replace(".json", f"{kb_tag}.json"), fcfg["k"], fcfg["nprobe"])
    ega = ExplanationGenerator(cfg("configs/llm_phi3_int4.yaml"), acfg["kappa_min"]); ega.set_seed(seed)
    shoa = Orchestrator(ONOSClient(), m_max=acfg["m_max"])
    return AgentRAGSense(fda, st["theta"], cra, ega, shoa, None, st["mean"], st["std"], tcfg["window"])

def read_ratings(path):
    """Per-event expert ratings: columns event_id, dataset, category, score_A, score_B, consensus_score."""
    import pandas as pd
    return pd.read_csv(path)
