"""Table 6: P, R, F1 on the final system alert, and EA, for AgentRAG-Sense and seven baselines."""
import json, pathlib
import pandas as pd
from agentrag.utils.io import write_table

METHODS = {"end_to_end": ["raglog", "llm_ei", "llmrca", "sdn_slice_sec", "mar_ids", "agentrag_sense"],
           "detection_only": ["lstm_ae", "gatformer"]}

def main(seed=42):
    rows = []
    for block, methods in METHODS.items():
        for m in methods:
            for ds in ("swat", "batadal", "wadi"):
                p = pathlib.Path(f"results/raw/seed_{seed}/{m}_{ds}.json")
                r = json.loads(p.read_text()) if p.exists() else {}
                rows.append({"block": block, "method": m, "dataset": ds, "P": r.get("P"), "R": r.get("R"),
                             "F1": r.get("F1_final_alert", r.get("F1")), "EA": r.get("EA"),
                             "status": r.get("status", "missing" if not r else "ok")})
    print(write_table(rows, "results/tables/table6_comparison.csv"))

if __name__ == "__main__":
    main()
