"""SHA-256 checksums for the KB JSON, FAISS index, model weights and split files."""
import glob, hashlib, pathlib

PATTERNS = ["data/knowledge_base/*.json", "data/knowledge_base/*.index", "models/*.gguf", "models/*.pt",
            "data/split_indices/*.json"]

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

def main():
    lines = [f"{sha(p)}  {p}" for pat in PATTERNS for p in sorted(glob.glob(pat))]
    pathlib.Path("checksums_artifacts.sha256").write_text("\n".join(lines) + "\n")
    print(len(lines), "files")

if __name__ == "__main__":
    main()
