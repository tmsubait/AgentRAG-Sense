"""Regenerates Figure 14 from results/raw/poisoning_eval.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/raw/poisoning_eval.csv"

def main():
    apply()
    df = pd.read_csv(SRC)
    fig, ax = plt.subplots(figsize=(3.5, 2.3)); ax2 = ax.twinx()
    ax.plot(df["event"], df["kb_size"], label="KB size"); ax2.plot(df["event"], 100 * df["quarantine_rate"], color="C1", label="Quarantine rate (%)")
    ax.set_xlabel("Simulated fault event"); ax.set_ylabel("KB records"); ax2.set_ylabel("Quarantine rate (%)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2, frameon=False)
    save(fig, "fig14.png")

if __name__ == "__main__":
    main()
