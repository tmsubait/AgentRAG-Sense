"""Regenerates Figure 05 from results/raw/ivfpq_sweep.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/raw/ivfpq_sweep.csv"

def main():
    apply()
    df = pd.read_csv(SRC)
    fig, ax = plt.subplots(figsize=(3.5, 2.4)); ax2 = ax.twinx()
    ax.plot(df["m"], df["recall_at_10"], marker="s", label="IVFPQ Recall@10")
    ax2.plot(df["m"], df["ivfpq_latency_ms"], marker="^", color="C1", label="IVFPQ latency")
    ax2.plot(df["m"], df["flat_l2_latency_ms"], ls="--", marker="o", mfc="none", color="C2", label="Flat-L2 latency")
    ax.set_xlabel("PQ subquantizers m"); ax.set_ylabel("Recall@10"); ax2.set_ylabel("Retrieval latency (ms)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=3, frameon=False)
    save(fig, "fig05.png")

if __name__ == "__main__":
    main()
