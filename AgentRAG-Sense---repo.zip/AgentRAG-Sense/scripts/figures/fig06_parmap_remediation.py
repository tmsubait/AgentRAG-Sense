"""Regenerates Figure 06 from results/tables/table7_mttr_by_slices.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/tables/table7_mttr_by_slices.csv"

def main():
    apply()
    df = pd.read_csv("results/raw/parmap_vs_sequential.csv")   # columns: n_slices, sequential_s, parallel_s
    fig, ax = plt.subplots(figsize=(3.5, 2.4))
    ax.plot(df["n_slices"], df["sequential_s"], ls="--", marker="o", mfc="none", label="Sequential")
    ax.plot(df["n_slices"], df["parallel_s"], marker="s", label="Parallel (ParMap)")
    ax.set_xlabel("Number of affected slices |J_t|"); ax.set_ylabel("Execution time until restored (s)")
    legend_below(ax, 2); save(fig, "fig06.png")

if __name__ == "__main__":
    main()
