"""Regenerates Figure 12 from results/tables/table8_ablation.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/tables/table8_ablation.csv"

def main():
    apply()
    df = pd.read_csv(SRC); full = df[df["variant"] == "full"].iloc[0]
    d = df[df["variant"] != "full"].copy(); d["dF1"] = 100 * (d["F1"] - full["F1"])
    fig, ax = plt.subplots(figsize=(3.5, 2.3))
    ax.barh(d["variant"], d["dF1"], color="C0"); ax.axvline(0, color="k", lw=0.6)
    ax.set_xlabel("Change in F1 versus full system (pp)"); save(fig, "fig12.png")

if __name__ == "__main__":
    main()
