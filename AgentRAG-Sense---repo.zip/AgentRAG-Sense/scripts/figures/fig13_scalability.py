"""Regenerates Figure 13 from results/raw/throughput_lambda.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/raw/throughput_lambda.csv"

def main():
    apply()
    df = pd.read_csv(SRC)
    fig, ax = plt.subplots(figsize=(3.5, 2.3))
    for pf, g in df.groupby("prefetch"):
        ax.plot(g["lambda"], g["mttr_s"], marker="o" if pf else "s", label="with shadow-CRA" if pf else "without shadow-CRA")
    ax.axhline(60, ls="--", color="C3", lw=0.8)
    ax.set_xlabel("Anomaly arrival rate (events/s)"); ax.set_ylabel("MTTR (s)"); legend_below(ax, 2); save(fig, "fig13.png")

if __name__ == "__main__":
    main()
