"""Regenerates Figure 10 from results/raw/throughput_lambda.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/raw/throughput_lambda.csv"

def main():
    apply()
    df = pd.read_csv(SRC); df = df[df["prefetch"] == 0]
    fig, ax = plt.subplots(figsize=(3.5, 2.4)); ax2 = ax.twinx()
    ax.plot(df["lambda"], df["mttr_s"], marker="o", label="MTTR")
    ax2.plot(df["lambda"], df["throughput"], marker="s", color="C1", label="Throughput")
    ax.set_xlabel("Anomaly arrival rate (events/s)"); ax.set_ylabel("MTTR (s)"); ax2.set_ylabel("Throughput (events/s)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2, frameon=False)
    save(fig, "fig10.png")

if __name__ == "__main__":
    main()
