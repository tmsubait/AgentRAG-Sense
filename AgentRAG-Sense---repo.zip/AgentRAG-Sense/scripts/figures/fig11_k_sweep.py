"""Regenerates Figure 11 from results/raw/k_sweep.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/raw/k_sweep.csv"

def main():
    apply()
    df = pd.read_csv(SRC)
    fig, ax = plt.subplots(figsize=(3.5, 2.3)); ax2 = ax.twinx()
    ax.plot(df["k"], df["F1"], marker="o", label="F1"); ax2.plot(df["k"], df["EA"], marker="s", color="C1", label="EA (%)")
    ax.set_xlabel("Retrieved neighbours k"); ax.set_ylabel("F1"); ax2.set_ylabel("EA (%)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2, frameon=False)
    save(fig, "fig11.png")

if __name__ == "__main__":
    main()
