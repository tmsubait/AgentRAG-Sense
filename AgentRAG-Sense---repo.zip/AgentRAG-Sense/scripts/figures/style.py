"""IEEE-style settings shared by all figure scripts: Times New Roman, Tableau Colorblind 10, 600 dpi."""
import pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def apply():
    plt.style.use("tableau-colorblind10")
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
                         "font.size": 9, "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
                         "ytick.labelsize": 8, "savefig.dpi": 600, "savefig.transparent": True,
                         "savefig.bbox": "tight", "axes.grid": True, "grid.alpha": 0.3})

def save(fig, name):
    out = pathlib.Path("figures"); out.mkdir(exist_ok=True)
    fig.savefig(out / name); print(out / name)

def legend_below(ax, ncol=3):
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=ncol, frameon=False)
