"""Regenerates Figure 08 from results/tables/table6_comparison.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/tables/table6_comparison.csv"

def main():
    apply()
    df = pd.read_csv(SRC).dropna(subset=["F1"])
    piv = df.pivot_table(index="method", columns="dataset", values="F1")[["swat", "batadal", "wadi"]]
    fig, ax = plt.subplots(figsize=(3.5, 2.4)); x = np.arange(len(piv)); w = 0.27
    for i, ds in enumerate(piv.columns):
        ax.bar(x + (i - 1) * w, piv[ds].values, w, label=ds.upper())
    ax.set_xticks(x); ax.set_xticklabels(piv.index, rotation=35, ha="right"); ax.set_ylabel("F1 (final alert)")
    ax.set_ylim(0.7, 1.0); legend_below(ax, 3); save(fig, "fig08.png")

if __name__ == "__main__":
    main()
