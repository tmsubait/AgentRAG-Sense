"""Regenerates Figure 09 from results/tables/hitl_summary.csv."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from style import apply, save, legend_below

SRC = "results/tables/hitl_summary.csv"

def main():
    apply()
    h = pd.read_csv(SRC).set_index("metric")["value"]
    sdn = pd.read_csv("results/raw/sdn_slice_sec_mttr.csv")["mttr_s"].mean()
    vals = [h["AgentRAG-Sense MTTR to acknowledgement (s)"], sdn, 60 * h["HITL mean (min)"]]
    fig, ax = plt.subplots(figsize=(3.5, 2.2))
    ax.bar(["AgentRAG-Sense", "SDN-Slice-Sec", "HITL"], vals, color=["C0", "C1", "C2"])
    ax.set_yscale("log"); ax.set_ylabel("MTTR (s, log scale)"); save(fig, "fig09.png")

if __name__ == "__main__":
    main()
