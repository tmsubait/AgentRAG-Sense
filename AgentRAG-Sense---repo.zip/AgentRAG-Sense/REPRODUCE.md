# Table and figure reproduction map

Tolerances refer to the five-seed protocol (Section 8.1). Runtimes are for one Jetson AGX Orin 32 GB unless noted.

| Paper item | Command | Output | Runtime | Tolerance |
|---|---|---|---|---|
| Table 3 (dataset statistics) | `python -m experiments.dataset_stats` | `results/tables/table3_datasets.csv` | 5 min | exact |
| Table 5 (small LM comparison) | `python -m experiments.slm_comparison` | `results/tables/table5_slm.csv` | 6 h | latency ±5% |
| Table 6 (comparison) | `python -m experiments.detection_table6` | `results/tables/table6_comparison.csv` | 10 h | F1 ±0.007 |
| Table 7 (MTTR decomposition) | `python -m experiments.mttr_decomposition` | `results/tables/table7_mttr.csv` | 3 h | ±3 s total |
| Table 8 (ablation) | `python -m experiments.ablation_tables8_9 --table 8` | `results/tables/table8_ablation.csv` | 8 h | F1 ±0.007 |
| Table 9 (cumulative contribution) | `python -m experiments.ablation_tables8_9 --table 9` | `results/tables/table9_cumulative.csv` | shared with Table 8 | F1 ±0.007 |
| Table 10 (rule vs expert labels) | `python -m experiments.rule_vs_expert` | `results/tables/table10_rule_vs_expert.csv` | 1 min | exact |
| Table 11 (hold-out) | `python -m experiments.holdout_cross_dataset && python -m experiments.holdout_category` | `results/tables/table11_holdout.csv` | 4 h | EA ±0.6 pp |
| Table 12 (sensitivity) | `python -m experiments.sensitivity_kappa_delta` | `results/tables/table12_sensitivity.csv` | 2 h | ±0.6 pp |
| EA Wilson CIs (Section 7.2) | `python -m experiments.ea_evaluation.wilson_ci` | `results/tables/ea_wilson_ci.csv` | seconds | exact |
| HITL statistics (Section 7.7) | `python -m experiments.hitl_baseline.summarize_hitl` | `results/tables/hitl_summary.csv` | seconds | exact |
| Seed-123 robustness (Section 8.1) | `python -m experiments.seeds_runner --seeds 123` | `results/raw/seed_123/` | 10 h | see Section 8.1 |
| Figure 5 | `python scripts/figures/fig05_ivfpq_recall_latency.py` | `figures/fig05.png` | seconds | n/a |
| Figure 6 | `python scripts/figures/fig06_parmap_remediation.py` | `figures/fig06.png` | seconds | n/a |
| Figure 8 | `python scripts/figures/fig08_f1_comparison.py` | `figures/fig08.png` | seconds | n/a |
| Figure 9 | `python scripts/figures/fig09_mttr_comparison.py` | `figures/fig09.png` | seconds | n/a |
| Figure 10 | `python scripts/figures/fig10_latency_throughput.py` | `figures/fig10.png` | seconds | n/a |
| Figure 11 | `python scripts/figures/fig11_k_sweep.py` | `figures/fig11.png` | seconds | n/a |
| Figure 12 | `python scripts/figures/fig12_ablation_waterfall.py` | `figures/fig12.png` | seconds | n/a |
| Figure 13 | `python scripts/figures/fig13_scalability.py` | `figures/fig13.png` | seconds | n/a |
| Figure 14 | `python scripts/figures/fig14_kb_growth.py` | `figures/fig14.png` | seconds | n/a |

Figures 1 to 4 and 7 are conceptual diagrams and have no data script.
