# S2. Sensitivity of kappa_min and delta_p

Scan on the SWaT validation split (chronologically disjoint from test): kappa_min in {0.50, 0.55, 0.60, 0.65, 0.70, 0.75},
delta_p in {0.10, 0.20, 0.30, 0.40, 0.50}. Category 14 membership is rule-based and does not depend on kappa_t.
Table: `results/tables/table12_sensitivity.csv` (`experiments/sensitivity_kappa_delta.py`).
