# S4. MTTR decomposition

MTTR_t = tau_det + tau_eff + tau_queue(J_t) + tau_exec(J_t) + tau_ack (Eq. 10). Per-event terms are logged by
`simulation/ns3/replay/fault_replay.py`; `experiments/mttr_decomposition.py` writes the means (Table 7), the
residual check (total minus the sum of terms) and the MTTR by number of affected slices.
The HITL clock stops at API issuance; `experiments/hitl_baseline/summarize_hitl.py` reports the end-point-matched
AgentRAG-Sense time to API issuance next to the HITL mean, standard deviation, median and IQR.
