# S3. Rating scale and rater guidelines

See `experiments/ea_evaluation/rating_scale.md` for the 1 to 5 scale. Raters work independently on the raw sensor
traces and the symptom descriptor, record their score, and only then see the system explanation. Disagreements are
resolved by structured discussion; unresolved cases (under 3%) take the lower score. Rater identities are removed
from all sheets. EA intervals are 95% Wilson intervals (`experiments/ea_evaluation/wilson_ci.py`).
