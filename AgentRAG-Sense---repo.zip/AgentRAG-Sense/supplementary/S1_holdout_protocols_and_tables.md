# S1. Hold-out protocols, rule versus expert consistency

## S1.1 Cross-dataset hold-out
K is rebuilt from SWaT records only (`kb_construction.build_kb --only_datasets swat --tag _swat_only`). The system is
evaluated on the same 500 WADI evaluation events used for in-domain EA and rated with the blinded protocol of S3.

## S1.2 Category hold-out
All records with categories 9 to 12 are removed from K (`--exclude_categories 9,10,11,12`); category 13 records are
retained. EA is computed on test events whose consensus label is in 9 to 12, overall and per category.

## S1.3 Rule-label versus expert-label consistency
The deterministic rules (`agentrag/kb/taxonomy.py`) are applied to the 2,000 expert-labelled descriptors without
access to the consensus labels. Agreement, Cohen's kappa per category group and the 14 x 14 confusion matrix are
written by `experiments/rule_vs_expert.py`.

Tables: `results/tables/table10_rule_vs_expert.csv`, `table10_confusion_14x14.csv`, `table11_holdout_*.csv`.
