# AgentRAG-Sense

**Multi-Agent Retrieval-Augmented Generation for Self-Healing 6G IIoT Fog Networks**

> Paper details (title/venue/year) are as given in the shared manuscript; the
> document does not list author names or a finalized venue/DOI (it references
> its own code at an anonymized review link, `anonymous.4open.science`),
> consistent with a paper currently under double-blind review. Update this
> section once the camera-ready citation is available.

## Abstract (summary)

6G fog nodes need to detect, explain, and remediate IIoT anomalies in
near real time, but existing systems either give context-free alerts or
require cloud-scale LLMs. AgentRAG-Sense is a four-agent pipeline — Fault
Detector, Context Retriever, Explanation Generator, Self-Healing
Orchestrator — that runs entirely on a 16 GB fog node, retrieves similar
historical faults from a compressed FAISS index, grounds a frozen
INT4 Phi-3-mini in that context to explain root causes, and dispatches
SDN/NFV remediation automatically. On SWaT, BATADAL, and WADI it cuts
MTTR from ~14.3 minutes to ~34 seconds and improves F1 by up to 10.8 pp
over six baselines, with 97.4% expert-rated explanation accuracy.

## Architecture

| Agent | Role | Implementation |
|---|---|---|
| **FDA** — Fault Detector Agent | Detects anomalies from multivariate sensor windows | Dilated TCN (`model.py::TCNFaultDetector`), the only *trained* component |
| **CRA** — Context Retriever Agent | Retrieves top-k similar historical faults | FAISS IVFPQ index (`model.py::FAISSRetriever`) |
| **EGA** — Explanation Generator Agent | Generates root-cause explanation + JSON playbook | Frozen Phi-3-mini, INT4, via llama.cpp (`model.py::ExplanationGenerator`) |
| **SHOA** — Self-Healing Orchestrator Agent | Translates playbook to SDN/NFV actions | ONOS REST API translator (`model.py::SelfHealingOrchestrator`) |

![System architecture](figures/fig02_system_architecture.png)
![Agent communication protocol](figures/fig03_agent_communication_protocol.png)
![End-to-end workflow](figures/fig07_workflow_pipeline.png)

See `figures/` for all 14 figures extracted from the paper (HD PNGs).

## Dataset

| Dataset | Samples | Features | Anomaly % | Access |
|---|---|---|---|---|
| SWaT | 495,000 | 51 | 12.1% | Request form — [iTrust Centre, SUTD](https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/) |
| BATADAL | 87,600 | 43 | 14.6% | Direct download — [batadal.net/data.html](https://www.batadal.net/data.html) |
| WADI | 1,048,571 | 127 | 5.8% | Request form — [iTrust Centre, SUTD](https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/) |

SWaT and WADI are gated behind a free academic data-use agreement (no
anonymous direct link exists — this is by the data owner's design, not
an omission here). BATADAL is fetched automatically by the download
script. See `dataset.py` module docstring for exact instructions.

**Folder layout after download:**
```
data/
├── download_data.py
├── swat/SWaT_dataset.csv        (place manually after iTrust approval)
├── batadal/BATADAL_dataset.csv  (auto-downloaded)
└── wadi/WADI_dataset.csv        (place manually after iTrust approval)
```

Splits are **chronological** (70/10/20 train/val/test), not random, to
avoid look-ahead bias (Section 6.1 of the paper).

## Installation

```bash
pip install -r requirements.txt
```

`faiss-cpu` and `llama-cpp-python` are optional at import time — the
code falls back to a numpy flat-search retriever and a deterministic
offline explanation generator, respectively, so you can run the FDA
training/evaluation pipeline without either installed. Install both for
a full reproduction (real FAISS IVFPQ latency, real Phi-3-mini INT4
explanations via a GGUF file — see `config.py::EGA_CONFIG` for the
HuggingFace repo/filename).

## How to train

```bash
python data/download_data.py         # fetch BATADAL; prints instructions for SWaT/WADI
python train.py --dataset batadal --epochs 80
```

Trains the FDA TCN (Eq. 15–18 of the paper) with AdamW, lr=1e-4,
weight_decay=0.01, batch_size=256, up to 80 epochs with early stopping
(patience 10), seed 42 — exactly Table 4's configuration. Saves
`checkpoints/fda_<dataset>_best.pt` and `..._last.pt`, and logs to
TensorBoard (`runs/<dataset>/`).

## How to evaluate

```bash
python evaluate.py --dataset batadal
```

Prints Precision / Recall / F1 / AUC-ROC on the test split, saves
`results/confusion_matrix_<dataset>.png`, `results/roc_curve_<dataset>.png`,
and `results/metrics_<dataset>.json`. Explanation Accuracy, MTTR, and
Throughput additionally require the live EGA (LLM) + SHOA (SDN/NS-3)
loop — see `inference.py` — since they're closed-loop, not offline,
metrics in the paper.

## How to run inference

```bash
python inference.py --dataset batadal --index 1000 --gguf /path/to/Phi-3-mini-4k-instruct-q4.gguf
```

Runs the full Algorithm 1 loop (FDA → CRA → EGA → SHOA) on one sensor
window, saves a plot of the window + anomaly score and a JSON of the
explanation/playbook/dispatched actions to `results/`. Omit `--gguf` to
use the deterministic offline explanation fallback.

## Results (as reported in the paper, Table 6)

| Method | SWaT F1 | BATADAL F1 | WADI F1 | Explanation Acc. |
|---|---|---|---|---|
| LSTM-AE | 0.812 | 0.829 | 0.752 | n/a |
| GATformer | 0.865 | 0.872 | 0.804 | n/a |
| RAGLog | 0.852 | 0.861 | 0.793 | 79.2% |
| LLM-EI | 0.876 | 0.884 | 0.830 | n/a |
| LLMRCA | 0.889 | – | – | – |
| SDN-Slice-Sec | 0.898 | 0.832 | 0.825 | 84.3% |
| **AgentRAG-Sense (paper)** | **0.954** | **0.960** | **0.938** | **97.4%** |

These are the numbers *reported in the paper* for context — your
reproduced F1 from `evaluate.py` measures only the FDA sub-component
(detection), which is one part of the full pipeline's score; matching
the paper's exact figures additionally depends on the full 50,000-record
knowledge base, the real Phi-3-mini INT4 model, and the NS-3/ONOS
closed loop, none of which are fully specified/released in the shared
manuscript (it points to an anonymized repo, `anonymous.4open.science`,
not accessible from here).

## Folder structure

```
AgentRAG-Sense_Implementation/
├── figures/                  14 HD figures extracted from the paper
├── data/
│   └── download_data.py
├── checkpoints/               (populated by train.py)
├── results/                   (populated by evaluate.py / inference.py)
├── notebooks/
│   └── demo.ipynb
├── config.py
├── dataset.py
├── model.py
├── train.py
├── evaluate.py
├── inference.py
├── utils.py
├── requirements.txt
└── README.md
```

## Honesty note on reproduction fidelity

This repo faithfully implements everything the paper specifies
numerically (TCN window/hidden-dim/dilations, FAISS IVFPQ parameters,
AdamW/batch/epoch/seed config, the 14-category fault taxonomy, the
fault-category → SDN-action mapping, the MTTR/queueing equations). Two
things it cannot fully reproduce from the paper text alone: (1) the
paper's own code/data/NS-3 scripts live in an anonymized review
repository not reachable from here, and (2) SWaT/WADI require a signed
data-use agreement, so this code ships the real download flow but not
the data itself. Where the paper doesn't specify a low-level detail
(TCN kernel size, dropout), that's called out explicitly in `config.py`
as a reasonable default rather than a value copied from the paper.
