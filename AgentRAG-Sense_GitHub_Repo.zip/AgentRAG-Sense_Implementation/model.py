"""
model.py — AgentRAG-Sense architecture (Section 5)

Four agents:
  FDA  (Fault Detector Agent)        -> TCNFaultDetector      (Eq. 15-18, trainable)
  CRA  (Context Retriever Agent)     -> FAISSRetriever         (Eq. 19-20)
  EGA  (Explanation Generator Agent) -> ExplanationGenerator   (Eq. 21-23, frozen INT4 LLM)
  SHOA (Self-Healing Orchestrator)   -> SelfHealingOrchestrator (Eq. 24-26, 29-32)

Only the FDA (a TCN) is a conventionally *trained* neural network — this
matches the paper: Phi-3-mini is used frozen/quantized (Theta is "frozen
INT4-quantized weights", Section 3.4), and CRA/SHOA are algorithmic
(FAISS search / rule-based translation), not learned.
"""
import json
import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import (FDA_CONFIG, CRA_CONFIG, EGA_CONFIG, SHOA_CONFIG,
                     FAULT_TAXONOMY, FAULT_CATEGORY_TO_ACTIONS)

# ══════════════════════════════════════════════════════════════════════
# FDA — Fault Detector Agent: dilated Temporal Convolutional Network
# Section 5.1, Eq. (15)-(18); design rationale for TCN over LSTM in Fig. 4
# ══════════════════════════════════════════════════════════════════════
class Chomp1d(nn.Module):
    """Removes the extra right-padding introduced by causal dilated convs."""
    def __init__(self, chomp_size):
        super().__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size].contiguous() if self.chomp_size > 0 else x


class TemporalBlock(nn.Module):
    """One dilated causal-conv residual block (a single entry of dilations={1,2,4,8,16})."""
    def __init__(self, in_ch, out_ch, kernel_size, dilation, dropout):
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.conv1 = nn.utils.weight_norm(
            nn.Conv1d(in_ch, out_ch, kernel_size, padding=padding, dilation=dilation))
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU()
        self.drop1 = nn.Dropout(dropout)

        self.conv2 = nn.utils.weight_norm(
            nn.Conv1d(out_ch, out_ch, kernel_size, padding=padding, dilation=dilation))
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU()
        self.drop2 = nn.Dropout(dropout)

        self.downsample = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else None
        self.relu_out = nn.ReLU()

    def forward(self, x):
        out = self.drop1(self.relu1(self.chomp1(self.conv1(x))))
        out = self.drop2(self.relu2(self.chomp2(self.conv2(out))))
        res = x if self.downsample is None else self.downsample(x)
        return self.relu_out(out + res)


class TCNFaultDetector(nn.Module):
    """
    FDA backbone: sliding-window TCN with dilations {1,2,4,8,16} (Eq. 15),
    look-back window W=60, hidden dim h=128.

    h_t = TCN(X_{t-W:t}; Phi_FDA)   -- Eq. 15
    a_t = sigmoid(w^T h_t + b)      -- Eq. 16 (anomaly score in [0,1])
    """
    def __init__(self, n_features, hidden_dim=FDA_CONFIG["hidden_dim"],
                 dilations=tuple(FDA_CONFIG["dilations"]),
                 kernel_size=FDA_CONFIG["kernel_size"],
                 dropout=FDA_CONFIG["dropout"]):
        super().__init__()
        layers = []
        in_ch = n_features
        for d in dilations:
            layers.append(TemporalBlock(in_ch, hidden_dim, kernel_size, d, dropout))
            in_ch = hidden_dim
        self.tcn = nn.Sequential(*layers)
        self.score_head = nn.Linear(hidden_dim, 1)   # w^T h_t + b, Eq. 16

    def forward(self, x):
        # x: (batch, n_features, W)
        h = self.tcn(x)                 # (batch, hidden_dim, W)
        h_t = h[:, :, -1]                # representation at final timestep t, Eq. 15
        logit = self.score_head(h_t).squeeze(-1)
        a_t = torch.sigmoid(logit)       # Eq. 16
        return a_t, h_t

    @staticmethod
    def loss_fn(a_t, y_t):
        """Eq. (18): binary cross-entropy over the anomaly score."""
        return F.binary_cross_entropy(a_t, y_t)


# ══════════════════════════════════════════════════════════════════════
# CRA — Context Retriever Agent: FAISS IVFPQ retrieval
# Section 5.2, Eq. (19)-(20)
# ══════════════════════════════════════════════════════════════════════
class FAISSRetriever:
    """
    Wraps a FAISS IndexIVFPQ (nlist=256, m=64 subquantizers -> Eq. 19) for
    top-k cosine-similarity retrieval (Eq. 5) over the knowledge base K.

    Falls back to a pure-numpy flat search if `faiss` isn't installed, so
    the rest of the pipeline is runnable without the compiled dependency
    (useful for CPU-only dev machines); production/edge runs should use
    real FAISS for the reported <8ms retrieval latency (Fig. 5).
    """
    def __init__(self, embedding_dim=CRA_CONFIG["embedding_dim"],
                 n_list=CRA_CONFIG["n_list"], n_subquantizers=CRA_CONFIG["n_subquantizers"],
                 n_probe=CRA_CONFIG["n_probe"]):
        self.d = embedding_dim
        self.n_list = n_list
        self.m = n_subquantizers
        self.n_probe = n_probe
        self.records: List[Dict] = []
        self._faiss = None
        self._index = None
        self._flat_embeddings = None
        try:
            import faiss
            self._faiss = faiss
        except ImportError:
            print("[CRA] faiss not installed — using numpy flat-search fallback "
                  "(see requirements.txt: faiss-cpu). Retrieval latency will not "
                  "match Fig. 5 without real FAISS IVFPQ.")

    def build(self, embeddings: np.ndarray, records: List[Dict]):
        """Algorithm 2: train IVFPQ centroids + PQ codebooks, build inverted lists."""
        assert embeddings.shape[1] == self.d
        self.records = records
        embeddings = embeddings.astype("float32")
        # L2-normalize so inner product == cosine similarity (Eq. 5, 20).
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings = embeddings / np.clip(norms, 1e-8, None)

        if self._faiss is not None:
            quantizer = self._faiss.IndexFlatIP(self.d)
            index = self._faiss.IndexIVFPQ(quantizer, self.d, self.n_list, self.m, 8)
            index.train(embeddings)
            index.add(embeddings)
            index.nprobe = self.n_probe
            self._index = index
        else:
            self._flat_embeddings = embeddings
        return self

    def search(self, query_embedding: np.ndarray, k=CRA_CONFIG["top_k"]):
        """Eq. (5): R_k = arg top-k cos(q, e_i)."""
        q = query_embedding.astype("float32").reshape(1, -1)
        q = q / np.clip(np.linalg.norm(q), 1e-8, None)

        if self._index is not None:
            sims, idxs = self._index.search(q, k)
            sims, idxs = sims[0], idxs[0]
        else:
            sims_all = (self._flat_embeddings @ q.T).squeeze(-1)
            idxs = np.argsort(-sims_all)[:k]
            sims = sims_all[idxs]

        results = [self.records[i] for i in idxs if i != -1 and i < len(self.records)]
        confidence = float(np.mean(sims[: len(results)])) if len(results) else 0.0
        return results, confidence  # confidence == kappa_t, Eq. 22


# ══════════════════════════════════════════════════════════════════════
# EGA — Explanation Generator Agent: Phi-3-mini (INT4, frozen) via llama.cpp
# Section 5.3, Eq. (21)-(23)
# ══════════════════════════════════════════════════════════════════════
PLAYBOOK_JSON_SCHEMA = {
    "type": "object",
    "required": ["root_cause", "confidence", "playbook"],
    "properties": {
        "root_cause": {"type": "string"},
        "fault_category": {"type": "integer", "minimum": 1, "maximum": 14},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "playbook": {
            "type": "array",
            "items": {"enum": SHOA_CONFIG["actions"]},
        },
    },
}


class ExplanationGenerator:
    """
    Wraps a frozen INT4 Phi-3-mini model (via llama-cpp-python) and builds
    the fixed structured prompt (Eq. 7). Constrained/CoT decoding under the
    JSON grammar G (Eq. 21) is approximated with a JSON-schema grammar file
    passed to llama.cpp (grammars/playbook.gbnf, generated below).
    """
    def __init__(self, gguf_path: Optional[str] = None, n_ctx=4096, n_gpu_layers=-1):
        self.system_prompt = EGA_CONFIG["system_prompt"]
        self.max_tokens = EGA_CONFIG["max_gen_tokens"]
        self._llm = None
        if gguf_path:
            try:
                from llama_cpp import Llama
                self._llm = Llama(model_path=gguf_path, n_ctx=n_ctx,
                                   n_gpu_layers=n_gpu_layers, verbose=False)
            except ImportError:
                print("[EGA] llama-cpp-python not installed; call `.generate()` "
                      "will raise until you `pip install llama-cpp-python` and "
                      "download the GGUF weights (see EGA_CONFIG in config.py).")

    @staticmethod
    def build_prompt(symptom_text: str, retrieved: List[Dict]) -> str:
        """Eq. (7): prompt_t = [SYS] || s_hat_t || [CTX] || R_k || [INSTRUCT]."""
        ctx_lines = "\n".join(
            f"- symptom: {r['symptom_text']} | root_cause: {r.get('root_cause','?')} "
            f"| playbook: {r.get('playbook', [])}"
            for r in retrieved
        )
        return (
            f"[SYS] {EGA_CONFIG['system_prompt']}\n"
            f"[QUERY] {symptom_text}\n"
            f"[CTX]\n{ctx_lines}\n"
            f"[INSTRUCT] Respond ONLY with JSON matching "
            f"{{root_cause, fault_category, confidence, playbook}}."
        )

    def generate(self, symptom_text: str, retrieved: List[Dict], confidence: float) -> Dict:
        """Eq. (21)-(23): decode c_hat_t, attach review_flag if kappa_t < kappa_min."""
        prompt = self.build_prompt(symptom_text, retrieved)

        if self._llm is not None:
            out = self._llm(prompt, max_tokens=self.max_tokens, temperature=0.0)
            text = out["choices"][0]["text"]
            try:
                explanation = json.loads(text)
            except json.JSONDecodeError:
                explanation = {"root_cause": "parse_error", "fault_category": 14,
                               "confidence": confidence, "playbook": ["isolate_slice"]}
        else:
            # Deterministic offline fallback so the pipeline is runnable without
            # the (large) LLM weights: majority-vote the retrieved records.
            explanation = self._fallback_explanation(retrieved, confidence)

        if confidence < CRA_CONFIG["confidence_floor"]:          # Eq. (23)
            explanation["review_flag"] = True
        return explanation

    @staticmethod
    def _fallback_explanation(retrieved: List[Dict], confidence: float) -> Dict:
        if not retrieved:
            return {"root_cause": "unknown or novel anomaly", "fault_category": 14,
                     "confidence": confidence, "playbook": ["isolate_slice"]}
        cats = [r.get("fault_category", 14) for r in retrieved]
        top_cat = max(set(cats), key=cats.count)
        return {
            "root_cause": FAULT_TAXONOMY.get(top_cat, "unknown"),
            "fault_category": top_cat,
            "confidence": confidence,
            "playbook": FAULT_CATEGORY_TO_ACTIONS.get(top_cat, ["isolate_slice"]),
        }


# ══════════════════════════════════════════════════════════════════════
# SHOA — Self-Healing Orchestrator Agent
# Section 5.4 / Section 7, Eq. (24)-(26), (29)-(32)
# ══════════════════════════════════════════════════════════════════════
@dataclass
class SliceState:
    slice_id: str
    state: str = "normal"   # {normal, degraded, isolated, restored}


class SelfHealingOrchestrator:
    """
    Validates the EGA's JSON playbook (Eq. 29), maps actions to ONOS REST
    calls (Eq. 24), executes them in parallel across affected slices
    (Eq. 25), and applies the knowledge-base quality gate (Eq. 26).
    """
    def __init__(self, onos_base_url=SHOA_CONFIG["onos_rest_base_url"],
                 max_workers=SHOA_CONFIG["max_parallel_agents"]):
        self.onos_base_url = onos_base_url
        self.max_workers = max_workers

    @staticmethod
    def validate_playbook(playbook: Dict) -> bool:
        """Eq. (29): schema + action-vocabulary validation."""
        if not isinstance(playbook.get("playbook"), list) or not playbook["playbook"]:
            return False
        return all(a in SHOA_CONFIG["actions"] for a in playbook["playbook"])

    def translate_to_onos(self, action: str, slice_id: str) -> Dict:
        """Eq. (24): pi(p_hat_t, s_j) -> ONOS.REST(s_j, action)."""
        endpoint_map = {
            "isolate_slice": f"{self.onos_base_url}/slices/{slice_id}/isolate",
            "reroute_flow": f"{self.onos_base_url}/flows/{slice_id}/reroute",
            "scale_vnf": f"{self.onos_base_url}/vnfs/{slice_id}/scale",
            "restore_slice": f"{self.onos_base_url}/slices/{slice_id}/restore",
        }
        return {"method": "POST", "url": endpoint_map[action], "slice_id": slice_id, "action": action}

    def execute(self, explanation: Dict, affected_slices: List[str], dry_run=True):
        """
        Eq. (25): {Delta_j}_{j in J_t} = ParMap(pi(p_hat_t, .), J_t)
        Runs the playbook against every affected slice, in parallel
        (ThreadPoolExecutor, up to max_workers = M_max).
        """
        from concurrent.futures import ThreadPoolExecutor

        if not self.validate_playbook(explanation):
            # Eq. (30): conservative default action on invalid playbook.
            explanation = {"playbook": ["isolate_slice"], "fault_category": 14,
                            "root_cause": "invalid_playbook_fallback"}

        def run_one(slice_id):
            calls = [self.translate_to_onos(a, slice_id) for a in explanation["playbook"]]
            if not dry_run:
                import requests
                for call in calls:
                    requests.post(call["url"], json={"action": call["action"]}, timeout=2)
            return {"slice_id": slice_id, "calls": calls, "final_state": "restored"}

        with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            results = list(ex.map(run_one, affected_slices))
        return results

    @staticmethod
    def poison_score(new_embedding, existing_embeddings, new_playbook, existing_playbooks):
        """Eq. (35): poison_score = max cos(e_new, e_i) - Sem(p_new, p_i)."""
        if len(existing_embeddings) == 0:
            return 0.0
        sims = existing_embeddings @ new_embedding / (
            np.linalg.norm(existing_embeddings, axis=1) * np.linalg.norm(new_embedding) + 1e-8)
        best_idx = int(np.argmax(sims))
        # Sem(): exact-match token overlap between action lists (Section 7.3).
        p_new, p_ref = set(new_playbook), set(existing_playbooks[best_idx])
        sem = len(p_new & p_ref) / max(1, len(p_new | p_ref))
        return float(sims[best_idx] - sem)

    @classmethod
    def quality_gate(cls, poison_score_value, playbook_valid,
                      delta_p=SHOA_CONFIG["poison_score_threshold"]):
        """Eq. (36): admit new record to K iff poison_score <= delta_p and playbook valid."""
        return (poison_score_value <= delta_p) and playbook_valid


# ══════════════════════════════════════════════════════════════════════
# Full pipeline wrapper (Algorithm 1)
# ══════════════════════════════════════════════════════════════════════
class AgentRAGSense(nn.Module):
    """Ties FDA + CRA + EGA + SHOA together per Algorithm 1."""
    def __init__(self, n_features, gguf_path=None):
        super().__init__()
        self.fda = TCNFaultDetector(n_features)
        self.cra = FAISSRetriever()
        self.ega = ExplanationGenerator(gguf_path=gguf_path)
        self.shoa = SelfHealingOrchestrator()

    def infer_step(self, x_window, symptom_text, query_embedding, affected_slices, dry_run=True):
        """One pass of Algorithm 1 (inference-time, not the training forward())."""
        with torch.no_grad():
            a_t, _ = self.fda(x_window)
        if a_t.item() < FDA_CONFIG["detection_threshold"]:
            return {"anomaly": False}
        retrieved, kappa_t = self.cra.search(query_embedding)
        explanation = self.ega.generate(symptom_text, retrieved, kappa_t)
        actions = self.shoa.execute(explanation, affected_slices, dry_run=dry_run)
        return {"anomaly": True, "score": a_t.item(), "confidence": kappa_t,
                "explanation": explanation, "actions": actions}
