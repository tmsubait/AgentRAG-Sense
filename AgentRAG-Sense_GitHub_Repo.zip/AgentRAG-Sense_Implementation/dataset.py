"""
dataset.py — Data acquisition and preprocessing for AgentRAG-Sense
Section 6.1 (Datasets) and Section 5, "Knowledge Base Construction Process".

Datasets used in the paper (Table 3):
  - SWaT     : 495,000 samples, 51 features, 12.1% anomalous
  - BATADAL  : 87,600 samples, 43 features, 14.6% anomalous
  - WADI     : 1,048,571 samples, 127 features, 5.8% anomalous

Real download sources
----------------------
  SWaT / WADI : iTrust Centre, SUTD. These datasets require you to submit a
                data-request form (free, academic use) — SUTD does not allow
                direct/anonymous public links by design:
                https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/
                Once you receive the emailed OneDrive link, put the raw
                .csv/.xlsx files at data/swat/ and data/wadi/ respectively
                (see LOCAL FILES section below) and re-run this script.

  BATADAL     : Openly downloadable, no request form:
                https://www.batadal.net/data.html
                This script downloads dataset03.csv (training, attacks
                labeled) and dataset04.csv (test, attacks labeled) directly.
"""
import os
import io
import zipfile
import numpy as np
import pandas as pd
import requests
import torch
from torch.utils.data import Dataset, DataLoader

from config import DATASETS, FDA_CONFIG, TRAIN_SPLIT, VAL_SPLIT, TEST_SPLIT, EVAL_CONFIG

# ──────────────────────────────────────────────────────────────────────
# DOWNLOAD
# ──────────────────────────────────────────────────────────────────────
BATADAL_FILES = {
    # BATADAL challenge dataset files (public, direct download)
    "dataset03.csv": "https://www.batadal.net/data/dataset03.csv",
    "dataset04.csv": "https://www.batadal.net/data/dataset04.csv",
}


def download_batadal(dest_dir):
    """Download the BATADAL CSVs directly (no auth required)."""
    os.makedirs(dest_dir, exist_ok=True)
    for fname, url in BATADAL_FILES.items():
        out_path = os.path.join(dest_dir, fname)
        if os.path.exists(out_path):
            print(f"[BATADAL] {fname} already present, skipping.")
            continue
        print(f"[BATADAL] downloading {url} ...")
        r = requests.get(url, timeout=60)
        r.raise_for_status()
        with open(out_path, "wb") as f:
            f.write(r.content)
    # Merge the two into the single csv config.py expects.
    frames = [pd.read_csv(os.path.join(dest_dir, f)) for f in BATADAL_FILES]
    merged = pd.concat(frames, ignore_index=True)
    merged_path = DATASETS["batadal"]["local_path"]
    os.makedirs(os.path.dirname(merged_path), exist_ok=True)
    merged.to_csv(merged_path, index=False)
    print(f"[BATADAL] merged -> {merged_path} ({len(merged)} rows)")


def instructions_for_gated_dataset(key):
    cfg = DATASETS[key]
    print(
        f"[{key.upper()}] This dataset is distributed under a data-use "
        f"agreement and has no anonymous direct-download URL.\n"
        f"  1. Request access at: {cfg['request_portal']}\n"
        f"  2. iTrust will email you a link to the raw files.\n"
        f"  3. Place the raw CSV/XLSX file(s) at: {os.path.dirname(cfg['local_path'])}/\n"
        f"  4. Re-run this script — it will pick up the local file automatically."
    )


def download_all():
    os.makedirs(os.path.dirname(DATASETS["batadal"]["local_path"]), exist_ok=True)
    if not os.path.exists(DATASETS["batadal"]["local_path"]):
        download_batadal(os.path.dirname(DATASETS["batadal"]["local_path"]))
    for key in ("swat", "wadi"):
        if not os.path.exists(DATASETS[key]["local_path"]):
            instructions_for_gated_dataset(key)


# ──────────────────────────────────────────────────────────────────────
# PREPROCESSING  (Section 5, "Knowledge Base Construction Process", Step 1)
# ──────────────────────────────────────────────────────────────────────
def compute_zscore_anomalies(df, feature_cols, window=EVAL_CONFIG["z_score_window"],
                              z_thresh=EVAL_CONFIG["z_score_threshold"]):
    """
    Rolling z-score per sensor channel against the preceding `window` samples.
    A channel is flagged anomalous when |z| > z_thresh (Section 5, Step 1).
    Returns a boolean DataFrame (same shape as df[feature_cols]) of flags
    and the per-timestep max |z| magnitude (used for the symptom text).
    """
    roll_mean = df[feature_cols].rolling(window=window, min_periods=window // 2).mean()
    roll_std = df[feature_cols].rolling(window=window, min_periods=window // 2).std().replace(0, np.nan)
    z = (df[feature_cols] - roll_mean) / roll_std
    flags = z.abs() > z_thresh
    return flags.fillna(False), z.fillna(0.0)


def format_symptom_descriptor(t, channel_list, magnitude_list, slice_id):
    """
    Eq. (17): deterministic natural-language symptom template used as the
    RAG query, exactly as specified in Section 5:
    'Anomaly detected at timestamp {t}: sensors [{channel_list}] deviated by
    [{magnitude_list}] sigma above normal; associated network slice: {slice_id}.'
    """
    ch = ", ".join(channel_list)
    mag = ", ".join(f"{m:.2f}" for m in magnitude_list)
    return (f"Anomaly detected at timestamp {t}: sensors [{ch}] deviated by "
            f"[{mag}] sigma above normal; associated network slice: {slice_id}.")


def build_symptom_descriptors(df, feature_cols, label_col="label", n_slices=10):
    """Turn flagged anomaly windows into structured symptom strings (Step 1)."""
    flags, z = compute_zscore_anomalies(df, feature_cols)
    records = []
    for t in df.index[df[label_col] == 1] if label_col in df else df.index[flags.any(axis=1)]:
        row_flags = flags.loc[t]
        flagged_channels = list(row_flags[row_flags].index)
        if not flagged_channels:
            continue
        magnitudes = [abs(z.loc[t, c]) for c in flagged_channels]
        slice_id = f"slice-{int(t) % n_slices}"
        text = format_symptom_descriptor(t, flagged_channels, magnitudes, slice_id)
        records.append({"timestamp": t, "symptom_text": text,
                         "channels": flagged_channels, "magnitudes": magnitudes,
                         "slice_id": slice_id})
    return pd.DataFrame(records)


def chronological_split(df, train=TRAIN_SPLIT, val=VAL_SPLIT, test=TEST_SPLIT):
    """Section 6.1: chronological (not random) split to avoid look-ahead bias."""
    assert abs(train + val + test - 1.0) < 1e-6
    n = len(df)
    i_train = int(n * train)
    i_val = i_train + int(n * val)
    return df.iloc[:i_train].copy(), df.iloc[i_train:i_val].copy(), df.iloc[i_val:].copy()


def load_and_preprocess(dataset_key):
    """
    Load the raw CSV for `dataset_key` in {'swat','batadal','wadi'}, infer
    feature/label columns, z-normalize features using train-split statistics
    only (no leakage), and return chronologically split DataFrames.
    """
    cfg = DATASETS[dataset_key]
    path = cfg["local_path"]
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Run `python dataset.py --download` first "
            f"(see dataset.py module docstring for access instructions)."
        )
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]

    # Heuristic label-column detection across the three datasets' known schemas.
    label_candidates = [c for c in df.columns if c.lower() in
                         ("label", "normal/attack", "attack", "y")]
    label_col = label_candidates[0] if label_candidates else df.columns[-1]
    df = df.rename(columns={label_col: "label"})
    df["label"] = (
        df["label"].astype(str).str.strip().str.lower()
        .map(lambda v: 0 if v in ("normal", "0", "0.0", "false") else 1)
    )

    feature_cols = [c for c in df.columns if c != "label" and pd.api.types.is_numeric_dtype(df[c])]
    train_df, val_df, test_df = chronological_split(df)

    mu, sigma = train_df[feature_cols].mean(), train_df[feature_cols].std().replace(0, 1.0)
    for split_df in (train_df, val_df, test_df):
        split_df[feature_cols] = (split_df[feature_cols] - mu) / sigma

    return {"train": train_df, "val": val_df, "test": test_df,
            "feature_cols": feature_cols, "mu": mu, "sigma": sigma}


# ──────────────────────────────────────────────────────────────────────
# PYTORCH DATASET / DATALOADER
# ──────────────────────────────────────────────────────────────────────
class SlidingWindowICSDataset(Dataset):
    """
    Produces (X_{t-W:t}, y_t) pairs for the FDA TCN (Eq. 15), with
    window W taken from FDA_CONFIG.
    """
    def __init__(self, df, feature_cols, window=FDA_CONFIG["window_size"]):
        self.window = window
        self.X = df[feature_cols].values.astype(np.float32)
        self.y = df["label"].values.astype(np.float32)

    def __len__(self):
        return max(0, len(self.X) - self.window)

    def __getitem__(self, idx):
        x_win = self.X[idx: idx + self.window]           # (W, D)
        y_t = self.y[idx + self.window]                   # label at time t
        # TCN expects (channels, length) -> transpose to (D, W)
        x_win = torch.from_numpy(x_win.T)
        return x_win, torch.tensor(y_t, dtype=torch.float32)


def get_dataloaders(dataset_key, batch_size, num_workers=2):
    data = load_and_preprocess(dataset_key)
    loaders = {}
    for split in ("train", "val", "test"):
        ds = SlidingWindowICSDataset(data[split], data["feature_cols"])
        loaders[split] = DataLoader(
            ds, batch_size=batch_size, shuffle=(split == "train"),
            num_workers=num_workers, drop_last=(split == "train"),
        )
    loaders["feature_cols"] = data["feature_cols"]
    return loaders


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--download", action="store_true")
    p.add_argument("--dataset", default="batadal", choices=list(DATASETS.keys()))
    args = p.parse_args()

    if args.download:
        download_all()
    else:
        loaders = get_dataloaders(args.dataset, batch_size=256)
        xb, yb = next(iter(loaders["train"]))
        print(f"Batch X shape: {tuple(xb.shape)}  Batch y shape: {tuple(yb.shape)}")
