"""
data/download_data.py — convenience wrapper around dataset.py's download logic.

Usage:
    python data/download_data.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dataset import download_all

if __name__ == "__main__":
    download_all()
