"""
config.py — Central configuration for AgentRAG-Sense
Reproduction of: "AgentRAG-Sense: Multi-Agent Retrieval-Augmented Generation
for Self-Healing 6G IIoT Fog Networks"

NOTE ON FIDELITY: Values below (Section 6, Table 3, Table 4) are copied
directly from the paper wherever the paper reports them. Values the paper
does not fully specify (e.g. exact TCN conv channel widths inside the
5 dilation blocks, dropout rate) are reasonable, clearly-marked defaults
you should tune — the paper reports *behavior* (window, hidden dim,
dilations, loss) but not every low-level layer hyperparameter.
"""
import os

# ──────────────────────────────────────────────────────────────────────
# PATHS
# ──────────────────────────────────────────────────────────────────────
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, "data")
CHECKPOINT_DIR = os.path.join(ROOT_DIR, "checkpoints")
RESULTS_DIR = os.path.join(ROOT_DIR, "results")
FIGURES_DIR = os.path.join(ROOT_DIR, "figures")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# ──────────────────────────────────────────────────────────────────────
# DATASETS  (Section 6.1 / Table 3)
# ──────────────────────────────────────────────────────────────────────
# NOTE: SWaT and WADI require a signed data-request agreement with the
# iTrust Centre (SUTD) before a download link is emailed to you — there is
# no direct/anonymous public URL, by the dataset owner's design. BATADAL
# is openly downloadable. dataset.py handles both cases.
DATASETS = {
    "swat": {
        "name": "SWaT (Secure Water Treatment)",
        "request_portal": "https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/",
        "local_path": os.path.join(DATA_DIR, "swat", "SWaT_dataset.csv"),
        "n_samples": 495_000,
        "n_features": 51,
        "anomaly_pct": 0.121,
    },
    "batadal": {
        "name": "BATADAL (BATtle of the Attack Detection ALgorithms)",
        "download_url": "https://www.batadal.net/data.html",
        # BATADAL publishes dataset1.csv (training, normal), dataset2.csv
        # (training, with attacks) and dataset3.csv / test dataset (no labels
        # released) — see download_data.py for the exact files fetched.
        "local_path": os.path.join(DATA_DIR, "batadal", "BATADAL_dataset.csv"),
        "n_samples": 87_600,
        "n_features": 43,
        "anomaly_pct": 0.146,
    },
    "wadi": {
        "name": "WADI (Water Distribution)",
        "request_portal": "https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/",
        "local_path": os.path.join(DATA_DIR, "wadi", "WADI_dataset.csv"),
        "n_samples": 1_048_571,
        "n_features": 127,
        "anomaly_pct": 0.058,
    },
}

# Chronological (temporal) split — Section 6.1: "partitioning ... is
# chronological rather than random ... to avoid look-ahead bias."
TRAIN_SPLIT = 0.70
VAL_SPLIT = 0.10
TEST_SPLIT = 0.20

# ──────────────────────────────────────────────────────────────────────
# FAULT DETECTOR AGENT (FDA) — Section 5.1, Eq. (15)-(18)
# ──────────────────────────────────────────────────────────────────────
FDA_CONFIG = {
    "window_size": 60,          # W = 60 time steps (Eq. 15)
    "hidden_dim": 128,          # h = 128 (Eq. 15)
    "dilations": [1, 2, 4, 8, 16],   # 5 dilation levels (Section 5.1)
    "kernel_size": 3,           # not specified in paper; standard TCN default
    "dropout": 0.2,             # not specified in paper; standard default
    "detection_threshold": 0.5,  # theta, tuned on validation set (Eq. 16)
}

# ──────────────────────────────────────────────────────────────────────
# CONTEXT RETRIEVER AGENT (CRA) — Section 5.2, Eq. (19)-(20)
# ──────────────────────────────────────────────────────────────────────
CRA_CONFIG = {
    "embedding_dim": 384,       # d_e, Phi-3-mini embedding head (Eq. 4)
    "faiss_index_type": "IVFPQ",
    "n_list": 256,               # inverted lists (Section 5.2)
    "n_subquantizers": 64,       # m = 64 (Eq. 19)
    "n_probe": 16,                # n_probe (Section 5.2)
    "top_k": 10,                  # k neighbors retrieved (default; paper sweeps k in Fig. 11)
    "knowledge_base_size": 50_000,  # L = 50,000 records (Section 5, Algorithm 2)
    "confidence_floor": 0.65,    # kappa_min (Eq. 23)
}

# ──────────────────────────────────────────────────────────────────────
# EXPLANATION GENERATOR AGENT (EGA) — Section 5.3, Eq. (21)-(23)
# ──────────────────────────────────────────────────────────────────────
EGA_CONFIG = {
    "llm_name": "Phi-3-mini",
    "llm_params_b": 3.8,
    "quantization": "INT4",
    "backend": "llama.cpp",
    # HuggingFace GGUF INT4 build commonly used with llama.cpp:
    "hf_repo": "microsoft/Phi-3-mini-4k-instruct-gguf",
    "gguf_filename": "Phi-3-mini-4k-instruct-q4.gguf",
    "max_gen_tokens": 512,       # T_max = 512 (Section 5.3, Eq. 21)
    "gen_latency_budget_ms": 60,  # tau_gen <= 60ms (Section 5.3)
    "cra_ega_budget_ms": 90,     # combined CRA+EGA budget (Section 5.3)
    "system_prompt": (
        "You are an industrial control system security analyst. Based on "
        "the anomaly description and the retrieved fault-resolution "
        "records below, determine the root cause, assign a fault category "
        "from the fault taxonomy and provide a structured output JSON "
        "remediation playbook."
    ),
}

# 14 fault categories (Section 5, Algorithm 2 / Step 2)
FAULT_TAXONOMY = {
    1: "sensor threshold crossing (high or low)",
    2: "correlated deviation of multiple sensors",
    3: "pump actuator fault",
    4: "valve actuator fault",
    5: "manipulation of flow-rate",
    6: "pressure anomaly (over or under)",
    7: "manipulation of tank level",
    8: "chemical dosing interference",
    9: "network-layer replay attack",
    10: "network-layer false data injection",
    11: "denial-of-service on SCADA channel",
    12: "man-in-the-middle attack on sensor bus",
    13: "multi-stage coordinated attack",
    14: "unknown or novel anomaly (low retrieval confidence, kappa < 0.65)",
}

# ──────────────────────────────────────────────────────────────────────
# SELF-HEALING ORCHESTRATOR AGENT (SHOA) — Section 5.4 / Section 7
# ──────────────────────────────────────────────────────────────────────
SHOA_CONFIG = {
    "onos_version": "2.7",
    "onos_rest_base_url": os.environ.get("ONOS_URL", "http://localhost:8181/onos/v1"),
    "onos_api_latency_budget_ms": 6,     # tau_API <= 6ms (Eq. 9)
    "per_slice_latency_budget_ms": 2,    # tau_slice <= 2ms (Eq. 9)
    "max_parallel_agents": 4,            # M_max = 4 (Eq. 14)
    "actions": ["isolate_slice", "reroute_flow", "scale_vnf", "restore_slice"],
    "poison_score_threshold": 0.3,       # delta_p (Eq. 35-36)
}

# fault category -> ordered remediation action sequence (Section 5, Step 3)
FAULT_CATEGORY_TO_ACTIONS = {
    1: ["scale_vnf", "restore_slice"],
    2: ["scale_vnf", "restore_slice"],
    3: ["scale_vnf", "restore_slice"],
    4: ["reroute_flow", "restore_slice"],
    5: ["reroute_flow", "restore_slice"],
    6: ["reroute_flow", "restore_slice"],
    7: ["isolate_slice", "restore_slice"],
    8: ["isolate_slice", "restore_slice"],
    9: ["isolate_slice", "reroute_flow", "scale_vnf"],   # awaits expert confirmation before restore_slice
    10: ["isolate_slice", "reroute_flow", "scale_vnf"],
    11: ["isolate_slice", "reroute_flow", "scale_vnf"],
    12: ["isolate_slice", "reroute_flow", "scale_vnf"],
    13: ["isolate_slice", "reroute_flow", "scale_vnf"],  # awaits expert confirmation before restore_slice
    14: ["isolate_slice", "reroute_flow", "scale_vnf"],
}

# ──────────────────────────────────────────────────────────────────────
# TRAINING (Table 4 — Implementation and Training Configuration)
# ──────────────────────────────────────────────────────────────────────
TRAIN_CONFIG = {
    "optimizer": "AdamW",
    "learning_rate": 1e-4,
    "weight_decay": 0.01,
    "batch_size": 256,
    "epochs": 80,
    "early_stopping_patience": 10,
    "random_seed": 42,
    "mixed_precision": True,
    "device": "cuda",   # falls back to "cpu" automatically in train.py if unavailable
    "log_dir": os.path.join(ROOT_DIR, "runs"),
}

# ──────────────────────────────────────────────────────────────────────
# EVALUATION
# ──────────────────────────────────────────────────────────────────────
EVAL_CONFIG = {
    "z_score_threshold": 3.0,       # |z| > 3.0 marks a sensor channel anomalous (Section 5, Step 1)
    "z_score_window": 300,          # 300-sample rolling window
    "explanation_eval_sample_size": 500,  # stratified sample per dataset (Section 6.2)
    "cohens_kappa_interrater": 0.83,
}

# ──────────────────────────────────────────────────────────────────────
# 6G / NS-3 SIMULATION (Table 4)
# ──────────────────────────────────────────────────────────────────────
NS3_CONFIG = {
    "ns3_version": "3.42",
    "channel_model": "3GPP TR 38.901 UMa",
    "carrier_ghz": 28,
    "bandwidth_mhz": 100,
    "delay_profile": "CDL-C",
    "rms_delay_spread_ns": 100,
    "n_fog_nodes": 10,
    "topology": "star",
    "inter_node_latency_ms": [2, 8],
    "path_loss_alpha": 3.5,
    "shadowing_std_db": 4,
}

RANDOM_SEEDS = [42, 123]
