"""
train.py — Trains the FDA (TCN) on the FDA binary-detection objective
(Eq. 18). CRA/EGA/SHOA are not trained (FAISS index + frozen quantized LLM
+ rule-based translator — see model.py docstring), so this is the only
learned component and the only one with a training loop, matching the
paper's Table 4 training configuration (AdamW, lr=1e-4, batch=256,
80 epochs, patience 10, seed 42).
"""
import argparse
import os
import time

import numpy as np
import torch
from torch.cuda.amp import autocast, GradScaler
from torch.utils.tensorboard import SummaryWriter

from config import TRAIN_CONFIG, CHECKPOINT_DIR, DATASETS
from dataset import get_dataloaders
from model import TCNFaultDetector
from utils import set_seed, compute_binary_metrics


def evaluate_split(model, loader, device):
    model.eval()
    all_scores, all_labels = [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            a_t, _ = model(xb)
            all_scores.append(a_t.cpu().numpy())
            all_labels.append(yb.numpy())
    scores = np.concatenate(all_scores)
    labels = np.concatenate(all_labels)
    metrics = compute_binary_metrics(labels, scores)
    loss = float(np.mean(-(labels * np.log(scores + 1e-8) +
                           (1 - labels) * np.log(1 - scores + 1e-8))))
    metrics["loss"] = loss
    return metrics


def train(dataset_key="batadal", epochs=None, batch_size=None):
    cfg = TRAIN_CONFIG
    set_seed(cfg["random_seed"])

    device = torch.device(cfg["device"] if torch.cuda.is_available() else "cpu")
    print(f"[train] device = {device}")

    epochs = epochs or cfg["epochs"]
    batch_size = batch_size or cfg["batch_size"]

    loaders = get_dataloaders(dataset_key, batch_size=batch_size)
    n_features = len(loaders["feature_cols"])

    model = TCNFaultDetector(n_features=n_features).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["learning_rate"],
                                   weight_decay=cfg["weight_decay"])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=3)
    scaler = GradScaler(enabled=(cfg["mixed_precision"] and device.type == "cuda"))

    writer = SummaryWriter(log_dir=os.path.join(cfg["log_dir"], dataset_key))

    best_val_loss = float("inf")
    patience_left = cfg["early_stopping_patience"]
    best_ckpt_path = os.path.join(CHECKPOINT_DIR, f"fda_{dataset_key}_best.pt")
    last_ckpt_path = os.path.join(CHECKPOINT_DIR, f"fda_{dataset_key}_last.pt")

    for epoch in range(1, epochs + 1):
        model.train()
        t0 = time.time()
        running_loss, n_batches = 0.0, 0

        for xb, yb in loaders["train"]:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad(set_to_none=True)

            with autocast(enabled=(cfg["mixed_precision"] and device.type == "cuda")):
                a_t, _ = model(xb)
                loss = TCNFaultDetector.loss_fn(a_t, yb)      # Eq. (18)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            n_batches += 1

        train_loss = running_loss / max(1, n_batches)
        val_metrics = evaluate_split(model, loaders["val"], device)
        scheduler.step(val_metrics["loss"])

        dt = time.time() - t0
        print(f"[epoch {epoch:03d}/{epochs}] train_loss={train_loss:.4f} "
              f"val_loss={val_metrics['loss']:.4f} val_f1={val_metrics['f1']:.4f} "
              f"val_acc={val_metrics['accuracy']:.4f} ({dt:.1f}s)")

        writer.add_scalar("loss/train", train_loss, epoch)
        writer.add_scalar("loss/val", val_metrics["loss"], epoch)
        writer.add_scalar("metrics/val_f1", val_metrics["f1"], epoch)
        writer.add_scalar("metrics/val_precision", val_metrics["precision"], epoch)
        writer.add_scalar("metrics/val_recall", val_metrics["recall"], epoch)

        torch.save({"model_state": model.state_dict(), "epoch": epoch,
                    "n_features": n_features, "val_metrics": val_metrics},
                   last_ckpt_path)

        if val_metrics["loss"] < best_val_loss:
            best_val_loss = val_metrics["loss"]
            patience_left = cfg["early_stopping_patience"]
            torch.save({"model_state": model.state_dict(), "epoch": epoch,
                        "n_features": n_features, "val_metrics": val_metrics},
                       best_ckpt_path)
            print(f"  -> new best model saved ({best_ckpt_path})")
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"[train] early stopping at epoch {epoch} "
                      f"(patience={cfg['early_stopping_patience']})")
                break

    writer.close()
    print(f"[train] done. best_val_loss={best_val_loss:.4f}")
    return best_ckpt_path


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="batadal", choices=list(DATASETS.keys()))
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--batch_size", type=int, default=None)
    args = p.parse_args()
    train(dataset_key=args.dataset, epochs=args.epochs, batch_size=args.batch_size)
