"""
utils.py — Helper functions shared across train/evaluate/inference:
reproducibility seeding, metric computation, a lightweight text-embedding
stand-in for Phi-3-mini's encoder head (Eq. 4), and small plotting helpers.
"""
import hashlib
import random

import numpy as np
import torch
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score


def set_seed(seed):
    """Random seed = 42 per Table 4."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def compute_binary_metrics(labels, scores, threshold=0.5):
    """Precision/Recall/F1/Accuracy (Section 6.2 metric definitions)."""
    preds = (np.asarray(scores) >= threshold).astype(int)
    labels = np.asarray(labels).astype(int)
    return {
        "precision": float(precision_score(labels, preds, zero_division=0)),
        "recall": float(recall_score(labels, preds, zero_division=0)),
        "f1": float(f1_score(labels, preds, zero_division=0)),
        "accuracy": float(accuracy_score(labels, preds)),
    }


def text_to_embedding(text: str, dim=384, seed=None):
    """
    Deterministic hash-based text embedding used as a stand-in for
    Phi-3-mini's sentence-encoder head phi(.) (Eq. 4, d_e=384) when the
    real LLM isn't loaded. Swap this for a real sentence-transformers /
    Phi-3-mini embedding call for production/reproduction runs — this
    stub only guarantees the *shape* and determinism needed to exercise
    the FAISS retrieval pipeline end-to-end offline.
    """
    h = hashlib.sha256(text.encode("utf-8")).digest()
    rng = np.random.RandomState(int.from_bytes(h[:4], "little"))
    v = rng.normal(size=dim).astype(np.float32)
    return v / (np.linalg.norm(v) + 1e-8)


def augment_sensor_window(x, noise_std=0.01, seed=None):
    """
    Light Gaussian-noise augmentation for sensor windows. The paper does
    not report a specific augmentation pipeline for the FDA (Section 5.1
    describes only the TCN architecture and BCE loss), so this is an
    optional, clearly-labeled utility rather than a paper-mandated step —
    disabled by default in dataset.py.
    """
    rng = np.random.RandomState(seed)
    return x + rng.normal(0, noise_std, size=x.shape).astype(x.dtype)


def mttr_breakdown(tau_det, tau_ret, tau_gen, tau_rem, n_slices=1, tau_queue=0.0):
    """
    Eq. (10): MTTR_t = tau_det + (tau_ret + tau_gen + tau_rem)^eff
    single-slice (10a): sum of the three stages.
    multi-slice  (10b): max(tau_ret, tau_gen, tau_rem) + tau_queue(J_t).
    """
    if n_slices <= 1:
        eff = tau_ret + tau_gen + tau_rem
    else:
        eff = max(tau_ret, tau_gen, tau_rem) + tau_queue
    return tau_det + eff


def erlang_c_queue_delay(lam, mu, M):
    """
    Eq. (33)-(34): M/M/M queueing delay used to model SHOA load under
    burst anomaly-arrival rates.
    """
    rho = lam / (M * mu)
    if rho >= 1:
        return float("inf")
    # Erlang-C P0
    terms = sum((M * rho) ** k / np.math.factorial(k) for k in range(M))
    last_term = (M * rho) ** M / (np.math.factorial(M) * (1 - rho))
    p0 = 1.0 / (terms + last_term)
    p_wait = last_term * p0
    return p_wait / (M * mu * (1 - rho))
