"""
inference.py — Runs the full AgentRAG-Sense closed loop (Algorithm 1) on
a single sensor window: FDA detect -> CRA retrieve -> EGA explain -> SHOA
remediate. Visualizes the sensor window + anomaly score and saves the
JSON explanation/playbook.

Usage:
    python inference.py --dataset batadal --index 12345
"""
import argparse
import json
import os

import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import CHECKPOINT_DIR, RESULTS_DIR, CRA_CONFIG
from dataset import load_and_preprocess, format_symptom_descriptor
from model import TCNFaultDetector, FAISSRetriever, ExplanationGenerator, SelfHealingOrchestrator
from utils import text_to_embedding


def build_demo_knowledge_base(retriever: FAISSRetriever, n=200, seed=42):
    """
    Populates a small synthetic knowledge base of (symptom, root_cause,
    playbook) records so inference.py is runnable end-to-end without the
    full 50,000-record K described in the paper. Swap in the real K
    (built via dataset.py's `build_symptom_descriptors` + a real text
    encoder) for production/reproduction runs.
    """
    from config import FAULT_TAXONOMY, FAULT_CATEGORY_TO_ACTIONS
    rng = np.random.RandomState(seed)
    records, embeddings = [], []
    for i in range(n):
        cat = rng.randint(1, 15)
        rec = {
            "id": i,
            "symptom_text": f"synthetic historical fault #{i}, category {cat}",
            "root_cause": FAULT_TAXONOMY[cat],
            "fault_category": cat,
            "playbook": FAULT_CATEGORY_TO_ACTIONS[cat],
        }
        records.append(rec)
        embeddings.append(text_to_embedding(rec["symptom_text"], dim=CRA_CONFIG["embedding_dim"]))
    retriever.build(np.stack(embeddings), records)
    return retriever


def run_single(dataset_key, index, ckpt_path=None, gguf_path=None, dry_run=True):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt_path = ckpt_path or os.path.join(CHECKPOINT_DIR, f"fda_{dataset_key}_best.pt")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"No checkpoint at {ckpt_path}. Run train.py first.")

    ckpt = torch.load(ckpt_path, map_location=device)
    fda = TCNFaultDetector(n_features=ckpt["n_features"]).to(device)
    fda.load_state_dict(ckpt["model_state"])
    fda.eval()

    data = load_and_preprocess(dataset_key)
    feature_cols = data["feature_cols"]
    test_df = data["test"].reset_index(drop=True)

    from config import FDA_CONFIG
    W = FDA_CONFIG["window_size"]
    index = min(index, len(test_df) - W - 1)
    window = test_df[feature_cols].iloc[index: index + W].values.astype(np.float32)
    x = torch.from_numpy(window.T).unsqueeze(0).to(device)   # (1, D, W)

    with torch.no_grad():
        a_t, _ = fda(x)
    a_t = a_t.item()

    result = {"dataset": dataset_key, "index": index, "anomaly_score": a_t}

    if a_t >= FDA_CONFIG["detection_threshold"]:
        # Build symptom text from the most-deviated channels (Eq. 17 style).
        z = (window - window.mean(axis=0)) / (window.std(axis=0) + 1e-8)
        max_z = np.abs(z).max(axis=0)
        top_channels = [feature_cols[i] for i in np.argsort(-max_z)[:5]]
        magnitudes = [float(max_z[feature_cols.index(c)]) for c in top_channels]
        symptom_text = format_symptom_descriptor(index + W, top_channels, magnitudes, "slice-0")

        retriever = build_demo_knowledge_base(FAISSRetriever())
        query_emb = text_to_embedding(symptom_text, dim=CRA_CONFIG["embedding_dim"])
        retrieved, kappa_t = retriever.search(query_emb)

        ega = ExplanationGenerator(gguf_path=gguf_path)
        explanation = ega.generate(symptom_text, retrieved, kappa_t)

        shoa = SelfHealingOrchestrator()
        actions = shoa.execute(explanation, affected_slices=["slice-0"], dry_run=dry_run)

        result.update({"symptom_text": symptom_text, "confidence": kappa_t,
                        "explanation": explanation, "actions": actions})
    else:
        result["explanation"] = None

    # Visualize the input window + anomaly score.
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(window[:, :min(5, window.shape[1])])
    ax.set_title(f"{dataset_key.upper()} window @ idx={index} | a_t={a_t:.3f} "
                 f"({'ANOMALY' if a_t >= FDA_CONFIG['detection_threshold'] else 'normal'})")
    ax.set_xlabel("timestep"); ax.set_ylabel("normalized sensor value (first 5 channels)")
    fig.tight_layout()
    fig_path = os.path.join(RESULTS_DIR, f"inference_{dataset_key}_{index}.png")
    fig.savefig(fig_path, dpi=150)
    plt.close(fig)

    json_path = os.path.join(RESULTS_DIR, f"inference_{dataset_key}_{index}.json")
    with open(json_path, "w") as f:
        json.dump(result, f, indent=2, default=str)

    print(json.dumps(result, indent=2, default=str))
    print(f"\nSaved plot -> {fig_path}\nSaved result -> {json_path}")
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="batadal")
    p.add_argument("--index", type=int, default=1000)
    p.add_argument("--ckpt", default=None)
    p.add_argument("--gguf", default=None, help="Path to Phi-3-mini INT4 GGUF weights")
    args = p.parse_args()
    run_single(args.dataset, args.index, ckpt_path=args.ckpt, gguf_path=args.gguf)
