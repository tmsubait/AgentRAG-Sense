"""
download_data.py — Dataset download script for AgentRAG-Sense
Run: python data/download_data.py --dataset batadal
"""
import sys
import argparse
sys.path.insert(0, "..")
from dataset import download_dataset

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="batadal",
                   choices=["swat", "batadal", "wadi"])
    args = p.parse_args()
    download_dataset(args.dataset)
