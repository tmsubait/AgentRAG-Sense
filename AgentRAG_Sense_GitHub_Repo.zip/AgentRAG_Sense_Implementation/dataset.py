"""
dataset.py — AgentRAG-Sense Dataset Loading & Preprocessing
Paper Section VI-A: SWaT, BATADAL, WADI datasets.
Splits are CHRONOLOGICAL (70/10/20) to avoid look-ahead bias on time-series.

Dataset URLs:
  SWaT / WADI : https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/
  BATADAL     : https://www.batadal.net/data.html
"""

import os
import json
import random
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Tuple, List, Dict, Optional

import torch
from torch.utils.data import Dataset, DataLoader

from config import DATASETS, ACTIVE_DATASET, TRAIN, FDA, CRA


# ─────────────────────────────────────────────────────────────
# 1.  Download helpers
# ─────────────────────────────────────────────────────────────

def download_swat(dest: Path) -> None:
    """
    SWaT requires iTrust account registration.
    Visit: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/
    Download 'SWaT.A1 & A2_Dec 2015' and place:
        data/swat/SWaT_Dataset_Normal_v1.csv
        data/swat/SWaT_Dataset_Attack_v0.csv
    """
    dest.mkdir(parents=True, exist_ok=True)
    print("SWaT: Manual download required.")
    print("  URL: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/")
    print(f"  Place CSV files in: {dest}/")


def download_batadal(dest: Path) -> None:
    """
    BATADAL: direct CSV links from the challenge website.
    Training set (with labels) and test set.
    """
    import urllib.request
    dest.mkdir(parents=True, exist_ok=True)
    files = {
        "BATADAL_dataset03.csv": "https://www.batadal.net/data/BATADAL_dataset03.csv",
        "BATADAL_dataset04.csv": "https://www.batadal.net/data/BATADAL_dataset04.csv",
        "BATADAL_test_dataset.csv": "https://www.batadal.net/data/BATADAL_test_dataset.csv",
    }
    for name, url in files.items():
        fpath = dest / name
        if not fpath.exists():
            print(f"Downloading {name} ...")
            try:
                urllib.request.urlretrieve(url, fpath)
                print(f"  Saved: {fpath}")
            except Exception as e:
                print(f"  Failed ({e}). Download manually from {url}")


def download_wadi(dest: Path) -> None:
    """
    WADI requires iTrust account registration (same as SWaT).
    Visit: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/
    Download WADI.A1_9 Oct 2017 and place:
        data/wadi/WADI_14days_new.csv
        data/wadi/WADI_attackdataLABELS_new.csv
    """
    dest.mkdir(parents=True, exist_ok=True)
    print("WADI: Manual download required.")
    print("  URL: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/")
    print(f"  Place CSV files in: {dest}/")


def download_dataset(name: str = ACTIVE_DATASET) -> None:
    """Entry-point for dataset download."""
    cfg = DATASETS[name]
    dest = Path(cfg["local_path"])
    {"swat": download_swat, "batadal": download_batadal, "wadi": download_wadi}[name](dest)


# ─────────────────────────────────────────────────────────────
# 2.  Raw CSV → DataFrame loaders
# ─────────────────────────────────────────────────────────────

def _load_swat(root: Path) -> pd.DataFrame:
    """Load SWaT normal + attack CSVs, return unified DataFrame with 'label' column."""
    normal = pd.read_csv(root / "SWaT_Dataset_Normal_v1.csv",
                         skiprows=1, low_memory=False)
    attack = pd.read_csv(root / "SWaT_Dataset_Attack_v0.csv",
                         skiprows=1, low_memory=False)
    # Rename label column
    for df in (normal, attack):
        if "Normal/Attack" in df.columns:
            df.rename(columns={"Normal/Attack": "label"}, inplace=True)
        df["label"] = df["label"].apply(lambda x: 0 if str(x).strip() == "Normal" else 1)
    # Drop timestamp column
    for df in (normal, attack):
        df.drop(columns=[c for c in df.columns if "Timestamp" in c or "timestamp" in c],
                errors="ignore", inplace=True)
    df = pd.concat([normal, attack], ignore_index=True)
    return df


def _load_batadal(root: Path) -> pd.DataFrame:
    """Load BATADAL training data (dataset03 = labeled)."""
    df = pd.read_csv(root / "BATADAL_dataset03.csv", low_memory=False)
    # ATT_FLAG column: -999 = normal, 1 = attack
    if "ATT_FLAG" in df.columns:
        df.rename(columns={"ATT_FLAG": "label"}, inplace=True)
        df["label"] = df["label"].apply(lambda x: 0 if x == -999 else 1)
    if "DATETIME" in df.columns:
        df.drop(columns=["DATETIME"], inplace=True)
    return df


def _load_wadi(root: Path) -> pd.DataFrame:
    """Load WADI time-series with attack labels."""
    df = pd.read_csv(root / "WADI_14days_new.csv", skiprows=4, low_memory=False)
    labels = pd.read_csv(root / "WADI_attackdataLABELS_new.csv")
    # Merge on row index — WADI label file encodes attack windows
    df["label"] = 0
    for _, row in labels.iterrows():
        start, end = int(row.get("Start", 0)), int(row.get("End", 0))
        df.loc[start:end, "label"] = 1
    df.drop(columns=[c for c in df.columns if "Date" in c or "Time" in c],
            errors="ignore", inplace=True)
    return df


def load_raw(name: str = ACTIVE_DATASET) -> pd.DataFrame:
    cfg  = DATASETS[name]
    root = Path(cfg["local_path"])
    return {"swat": _load_swat, "batadal": _load_batadal, "wadi": _load_wadi}[name](root)


# ─────────────────────────────────────────────────────────────
# 3.  Preprocessing  (Section VI-A)
# ─────────────────────────────────────────────────────────────

def preprocess(df: pd.DataFrame, name: str = ACTIVE_DATASET):
    """
    Section VI-A: chronological 70/10/20 split, z-score normalization.
    Returns (X_train, y_train, X_val, y_val, X_test, y_test) as numpy arrays
    plus (mean, std) scaler parameters fitted only on train split.
    """
    # Ensure numeric
    feat_cols = [c for c in df.columns if c != "label"]
    df[feat_cols] = df[feat_cols].apply(pd.to_numeric, errors="coerce")
    df.dropna(inplace=True)
    df.reset_index(drop=True, inplace=True)

    X = df[feat_cols].values.astype(np.float32)
    y = df["label"].values.astype(np.int64)

    n       = len(X)
    tr, vl  = DATASETS[name]["split"][:2]
    n_tr    = int(n * tr)
    n_vl    = int(n * (tr + vl))

    X_tr, X_vl, X_te = X[:n_tr], X[n_tr:n_vl], X[n_vl:]
    y_tr, y_vl, y_te = y[:n_tr], y[n_tr:n_vl], y[n_vl:]

    # z-score — fit on train only
    mu  = X_tr.mean(axis=0, keepdims=True)
    std = X_tr.std(axis=0, keepdims=True) + 1e-8
    X_tr = (X_tr - mu) / std
    X_vl = (X_vl - mu) / std
    X_te = (X_te - mu) / std

    return X_tr, y_tr, X_vl, y_vl, X_te, y_te, mu, std


# ─────────────────────────────────────────────────────────────
# 4.  PyTorch Dataset — sliding-window TCN  (Section V-A, Eq. 15)
# ─────────────────────────────────────────────────────────────

class ICSWindowDataset(Dataset):
    """
    Sliding-window dataset for the TCN-based Fault Detector Agent.
    Window size W = 60 time steps (Section V-A).
    Label for window = label of the LAST time step.
    """
    def __init__(self, X: np.ndarray, y: np.ndarray, window: int = FDA["window_size"]):
        self.X = torch.from_numpy(X)       # [T, d]
        self.y = torch.from_numpy(y)       # [T]
        self.W = window

    def __len__(self):
        return max(0, len(self.X) - self.W + 1)

    def __getitem__(self, idx):
        # x shape: [W, d]  → model expects [d, W] (channels-first TCN)
        x = self.X[idx : idx + self.W].T   # [d, W]
        label = self.y[idx + self.W - 1]   # label of last timestep
        return x, label


def get_dataloaders(
    name: str      = ACTIVE_DATASET,
    batch_size: int = TRAIN["batch_size"],
    num_workers: int = 4,
    seed: int        = TRAIN["random_seed"],
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """Return (train_loader, val_loader, test_loader)."""
    torch.manual_seed(seed)
    random.seed(seed)
    np.random.seed(seed)

    df = load_raw(name)
    X_tr, y_tr, X_vl, y_vl, X_te, y_te, _, _ = preprocess(df, name)

    train_ds = ICSWindowDataset(X_tr, y_tr)
    val_ds   = ICSWindowDataset(X_vl, y_vl)
    test_ds  = ICSWindowDataset(X_te, y_te)

    kw = dict(num_workers=num_workers, pin_memory=True)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=False, **kw)
    val_loader   = DataLoader(val_ds,   batch_size=batch_size, shuffle=False, **kw)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size, shuffle=False, **kw)
    return train_loader, val_loader, test_loader


# ─────────────────────────────────────────────────────────────
# 5.  Knowledge-base record dataset  (Section IV-B)
# ─────────────────────────────────────────────────────────────

class KBRecord:
    """Single fault-resolution record r_i = (s_i, c_i, p_i)."""
    __slots__ = ("symptom", "root_cause", "playbook")

    def __init__(self, symptom: str, root_cause: str, playbook: Dict):
        self.symptom    = symptom
        self.root_cause = root_cause
        self.playbook   = playbook

    def to_dict(self) -> Dict:
        return {"symptom": self.symptom,
                "root_cause": self.root_cause,
                "playbook": self.playbook}

    @classmethod
    def from_dict(cls, d: Dict) -> "KBRecord":
        return cls(d["symptom"], d["root_cause"], d["playbook"])


def load_kb_records(path: Path) -> List[KBRecord]:
    records = []
    if path.exists():
        with open(path) as f:
            for line in f:
                records.append(KBRecord.from_dict(json.loads(line)))
    return records


def save_kb_records(records: List[KBRecord], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for r in records:
            f.write(json.dumps(r.to_dict()) + "\n")


# ─────────────────────────────────────────────────────────────
# 6.  Synthetic KB bootstrapping  (Section VI-A)
# ─────────────────────────────────────────────────────────────

SYMPTOM_TEMPLATES = [
    "Anomaly detected on sensor {sensor}: value {val:.3f} deviates {sigma:.1f}σ above mean.",
    "Multi-sensor spike on channels {sensor}: correlation pattern consistent with {attack_type}.",
    "Sustained deviation on {sensor} for {duration} seconds. Score: {score:.4f}.",
]

ATTACK_TYPES = [
    "replay attack", "command injection", "sensor spoofing",
    "DoS flood", "MITM manipulation", "physical actuator fault",
]

PLAYBOOK_TEMPLATES = [
    {"action": "isolate_slice", "target_slice": "slice_{sid}", "reason": "{reason}"},
    {"action": "reroute_flow",  "src": "node_{a}", "dst": "node_{b}", "reason": "{reason}"},
    {"action": "scale_vnf",     "vnf_id": "vnf_{vid}", "scale": 2,   "reason": "{reason}"},
    {"action": "restore_slice", "target_slice": "slice_{sid}",        "reason": "{reason}"},
]


def generate_synthetic_kb(n: int = 50_000, seed: int = 42) -> List[KBRecord]:
    """
    Generate n synthetic fault-resolution triplets to bootstrap the FAISS KB.
    In production, these would come from the NS-3 simulation mapping
    sensor-anomaly windows to network-layer fault events (Section VI-A).
    """
    rng = np.random.default_rng(seed)
    records = []
    sensors = [f"LIT{i:03d}" for i in range(1, 20)] + \
              [f"FIT{i:03d}" for i in range(1, 20)] + \
              [f"MV{i:03d}"  for i in range(1, 15)]

    for i in range(n):
        attack = rng.choice(ATTACK_TYPES)
        sensor = rng.choice(sensors)
        tmpl   = rng.choice(SYMPTOM_TEMPLATES)
        symptom = tmpl.format(
            sensor=sensor, val=rng.uniform(-5, 5),
            sigma=rng.uniform(2, 8), attack_type=attack,
            duration=int(rng.integers(5, 120)),
            score=rng.uniform(0.5, 1.0),
        )
        root_cause = (f"Root cause: {attack} targeting {sensor}. "
                      f"Detected pattern matches historical {attack} signature. "
                      f"Confidence: {rng.uniform(0.7, 1.0):.2f}.")
        pb_tmpl = rng.choice(PLAYBOOK_TEMPLATES).copy()
        playbook = {k: str(v).format(
            sid=rng.integers(1, 10), a=rng.integers(1, 20),
            b=rng.integers(1, 20), vid=rng.integers(1, 5),
            reason=f"Mitigate {attack} on {sensor}",
        ) for k, v in pb_tmpl.items()}
        records.append(KBRecord(symptom, root_cause, playbook))
    return records


if __name__ == "__main__":
    import sys
    ds = sys.argv[1] if len(sys.argv) > 1 else ACTIVE_DATASET
    print(f"Downloading dataset: {ds}")
    download_dataset(ds)
