"""
config.py — AgentRAG-Sense Configuration
Paper: "AgentRAG-Sense: A Multi-Agent Retrieval-Augmented Generation Framework
        for Context-Aware Anomaly Explanation and Self-Healing in 6G IIoT Fog Networks"
All hyperparameters match exactly those reported in Tables 3, 4, and Section V.
"""

import os
from pathlib import Path

# ─────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent
DATA_DIR        = BASE_DIR / "data"
CHECKPOINTS_DIR = BASE_DIR / "checkpoints"
RESULTS_DIR     = BASE_DIR / "results"
FIGURES_DIR     = BASE_DIR / "figures"
NOTEBOOKS_DIR   = BASE_DIR / "notebooks"

# ─────────────────────────────────────────────
# Dataset settings  (Table 3 + Section VI-A)
# ─────────────────────────────────────────────
DATASETS = {
    "swat": {
        "name":        "SWaT (Secure Water Treatment)",
        "url":         "https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/",
        "local_path":  DATA_DIR / "swat",
        "n_samples":   495_000,
        "n_features":  51,
        "anomaly_pct": 0.121,
        "split":       (0.70, 0.10, 0.20),   # train / val / test (chronological)
    },
    "batadal": {
        "name":        "BATADAL",
        "url":         "https://www.batadal.net/data.html",
        "local_path":  DATA_DIR / "batadal",
        "n_samples":   87_600,
        "n_features":  43,
        "anomaly_pct": 0.146,
        "split":       (0.70, 0.10, 0.20),
    },
    "wadi": {
        "name":        "WADI (Water Distribution)",
        "url":         "https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/",
        "local_path":  DATA_DIR / "wadi",
        "n_samples":   1_048_571,
        "n_features":  127,
        "anomaly_pct": 0.058,
        "split":       (0.70, 0.10, 0.20),
    },
}

ACTIVE_DATASET = "swat"   # change to "batadal" or "wadi" as needed

# ─────────────────────────────────────────────
# FDA — Fault Detector Agent  (Section V-A, Eq. 15–18)
# ─────────────────────────────────────────────
FDA = dict(
    # Section V-A: TCN with dilation factors {1,2,4,8,16}
    backbone        = "TCN",
    window_size     = 60,          # W = 60 time steps at 1 s resolution
    hidden_dim      = 128,         # h = 128
    dilation_factors= [1, 2, 4, 8, 16],   # P = 5 levels
    anomaly_threshold= 0.5,        # θ — tuned on validation set
    detection_latency_budget_ms = 30,      # τ_det ≤ 30 ms
)

# ─────────────────────────────────────────────
# CRA — Context Retriever Agent  (Section V-B, Eq. 19–20)
# ─────────────────────────────────────────────
CRA = dict(
    embedding_dim   = 384,         # d_e = 384 (Phi-3-mini encoder head)
    faiss_index_type= "IVFPQ",
    nlist           = 256,         # number of inverted lists
    m               = 64,          # number of PQ sub-quantizers (m=64 → 64 bytes/record)
    nprobe          = 16,          # probed lists at query time
    top_k           = 5,           # k = 5 (Fig. 11: plateau at k ≥ 5)
    kb_size         = 50_000,      # L = 50,000 records
    kb_memory_mb    = 3.2,         # 3.2 MB after INT8 PQ64 compression
    retrieval_latency_budget_ms = 10,       # τ_ret < 8 ms (budget 10 ms)
)

# ─────────────────────────────────────────────
# EGA — Explanation Generator Agent  (Section V-C, Eq. 21–23)
# ─────────────────────────────────────────────
EGA = dict(
    llm_model       = "microsoft/Phi-3-mini-4k-instruct",
    llm_params_B    = 3.8,         # 3.8 B parameters
    quantization    = "int4",      # INT4 (llama.cpp)
    vram_gb         = 2.4,         # ~2.4 GB VRAM after INT4
    max_new_tokens  = 512,         # T_max = 512
    prompt_tokens   = 256,         # T_p = 256 (prompt length)
    confidence_floor= 0.65,        # κ_min = 0.65 (Eq. 23)
    generation_latency_budget_ms = 90,       # τ_gen ≤ 90 ms (measured 54 ms)
    output_schema   = ["root_cause", "confidence", "playbook"],
)

# ─────────────────────────────────────────────
# SHOA — Self-Healing Orchestrator Agent  (Section V-D, Eq. 24–26)
# ─────────────────────────────────────────────
SHOA = dict(
    valid_actions   = ["isolate_slice", "reroute_flow", "scale_vnf", "restore_slice"],
    onos_url        = "http://localhost:8181/onos/v1",
    onos_user       = "onos",
    onos_password   = "rocks",
    api_latency_ms  = 5,           # τ_API ≤ 5 ms
    per_slice_latency_ms = 2,      # τ_slice ≤ 2 ms
    poison_threshold= 0.3,         # δ_p = 0.3 (Eq. 36)
    max_agents      = 4,           # M_max = 4 (Eq. 14)
)

# ─────────────────────────────────────────────
# Inter-Agent Communication Protocol  (Section V-E, Eq. 27–28)
# ─────────────────────────────────────────────
IAP = dict(
    queue_capacity  = 64,          # Q = 64
    bus_latency_ms  = 0.5,         # τ_bus ≤ 0.5 ms
    priority_levels = 3,
)

# ─────────────────────────────────────────────
# Training  (Table 4)
# ─────────────────────────────────────────────
TRAIN = dict(
    framework       = "PyTorch 2.2",
    optimizer       = "AdamW",
    lr              = 1e-4,        # lr = 1×10⁻⁴
    weight_decay    = 0.01,
    batch_size      = 256,
    epochs          = 80,
    early_stopping_patience = 10,
    random_seed     = 42,
    mixed_precision = True,        # use AMP on GPU
    scheduler       = "cosine",    # cosine annealing
    grad_clip       = 1.0,
)

# ─────────────────────────────────────────────
# System constraints  (Section IV, Eq. 11–14)
# ─────────────────────────────────────────────
SYSTEM = dict(
    min_explanation_accuracy = 0.95,    # α = 0.95
    fog_memory_budget_gb     = 16,      # B_fog = 16 GB
    max_parallel_agents      = 4,       # M_max = 4
    shadow_cra_threshold     = 0.80,    # ρ > 0.80 → activate shadow CRA
    hardware                 = "NVIDIA Jetson AGX Orin 32 GB",
    power_mode               = "15W",
)

# ─────────────────────────────────────────────
# Checkpoint & logging paths
# ─────────────────────────────────────────────
CKPT_BEST   = CHECKPOINTS_DIR / "best_fda.pt"
CKPT_LAST   = CHECKPOINTS_DIR / "last_fda.pt"
KB_INDEX    = CHECKPOINTS_DIR / "faiss_ivfpq.index"
KB_RECORDS  = CHECKPOINTS_DIR / "kb_records.jsonl"
LOG_DIR     = RESULTS_DIR / "tensorboard"
EVAL_OUT    = RESULTS_DIR / "eval_results.json"
