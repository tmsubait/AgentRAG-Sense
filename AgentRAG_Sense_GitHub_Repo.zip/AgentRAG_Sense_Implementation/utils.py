"""
utils.py — AgentRAG-Sense Utility Functions
Covers: metrics (Section VI-B), visualisation, early stopping, seeding.
"""

import random
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve
)

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# 1.  Reproducibility
# ──────────────────────────────────────────────────────────────

def set_seed(seed: int = 42) -> None:
    """Section VI-D: random seed = 42 for all datasets."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark     = False


# ──────────────────────────────────────────────────────────────
# 2.  Metrics  (Section VI-B)
# ──────────────────────────────────────────────────────────────

def compute_metrics(labels: np.ndarray, probs: np.ndarray,
                    threshold: float = 0.5) -> Dict[str, float]:
    """
    Section VI-B: Precision, Recall, F1, AUC-ROC.
    Explanation Accuracy (EA) requires domain-expert rating; placeholder returned as -1.
    """
    preds = (probs >= threshold).astype(int)

    # Guard: at least two classes present
    unique = np.unique(labels)
    if len(unique) < 2:
        logger.warning("Only one class in labels; metrics may be undefined.")

    metrics = {
        "precision": round(float(precision_score(labels, preds, zero_division=0)), 4),
        "recall":    round(float(recall_score(labels, preds, zero_division=0)), 4),
        "f1":        round(float(f1_score(labels, preds, zero_division=0)), 4),
    }
    try:
        metrics["roc_auc"] = round(float(roc_auc_score(labels, probs)), 4)
    except ValueError:
        metrics["roc_auc"] = -1.0
    return metrics


# ──────────────────────────────────────────────────────────────
# 3.  Early Stopping
# ──────────────────────────────────────────────────────────────

class EarlyStopper:
    """Table 4: early stopping, patience = 10."""
    def __init__(self, patience: int = 10, min_delta: float = 1e-4):
        self.patience   = patience
        self.min_delta  = min_delta
        self.best_score = -np.inf
        self.counter    = 0

    def __call__(self, score: float) -> bool:
        """Returns True if training should stop."""
        if score > self.best_score + self.min_delta:
            self.best_score = score
            self.counter    = 0
        else:
            self.counter += 1
        return self.counter >= self.patience


# ──────────────────────────────────────────────────────────────
# 4.  Visualisation helpers
# ──────────────────────────────────────────────────────────────

def plot_training_curves(history: List[Dict], out_path: Path) -> None:
    """Plot train/val loss and F1 curves."""
    epochs  = [h["epoch"] for h in history]
    tr_loss = [h["tr_loss"] for h in history]
    vl_loss = [h["vl_loss"] for h in history]
    tr_f1   = [h["tr_f1"]   for h in history]
    vl_f1   = [h["vl_f1"]   for h in history]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    ax1.plot(epochs, tr_loss, label="Train")
    ax1.plot(epochs, vl_loss, label="Val")
    ax1.set(title="Loss", xlabel="Epoch", ylabel="BCE Loss")
    ax1.legend()

    ax2.plot(epochs, tr_f1, label="Train")
    ax2.plot(epochs, vl_f1, label="Val")
    ax2.set(title="F1 Score", xlabel="Epoch", ylabel="F1")
    ax2.legend()

    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_f1_comparison(results: Dict[str, Dict], out_path: Path) -> None:
    """
    Fig. 8: F1 comparison across methods/datasets.
    `results` format: {method_name: {dataset: f1, …}}
    """
    datasets = ["SWaT", "BATADAL", "WADI"]
    methods  = list(results.keys())
    x        = np.arange(len(datasets))
    width    = 0.12
    fig, ax  = plt.subplots(figsize=(10, 5))

    colors = plt.cm.tab10(np.linspace(0, 1, len(methods)))
    for i, (method, ds_f1) in enumerate(results.items()):
        vals   = [ds_f1.get(ds.lower(), 0) for ds in datasets]
        offset = (i - len(methods) / 2) * width + width / 2
        bars   = ax.bar(x + offset, vals, width, label=method,
                        color=colors[i],
                        edgecolor="white" if "ours" not in method.lower() else "red",
                        linewidth=1.5 if "ours" in method.lower() else 0.5)

    ax.set_xticks(x)
    ax.set_xticklabels(datasets)
    ax.set_ylim(0.70, 1.0)
    ax.set_ylabel("F1 Score")
    ax.set_title("Fig. 8 — F1 Comparison (AgentRAG-Sense vs. Baselines)")
    ax.legend(fontsize=7, ncol=3)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_mttr_comparison(out_path: Path) -> None:
    """Fig. 9: MTTR comparison."""
    methods = ["Human-in-loop", "SDN-Slice-Sec", "AgentRAG-Sense"]
    values  = [14.3 * 60, 3.7 * 60, 34]   # in seconds
    colors  = ["#d62728", "#ff7f0e", "#2ca02c"]

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar(methods, values, color=colors, edgecolor="k", linewidth=0.6)
    for bar, val in zip(bars, values):
        label = f"{val:.0f}s" if val < 120 else f"{val/60:.1f}min"
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                label, ha="center", va="bottom", fontsize=10, fontweight="bold")

    ax.axhline(y=60, color="red", linestyle="--", lw=1.5, label="6G SLA (60s)")
    ax.set_ylabel("MTTR (seconds)")
    ax.set_title("Fig. 9 — Mean Time-To-Remediation")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_rag_k_ablation(out_path: Path) -> None:
    """Fig. 11: F1 and EA vs retrieval neighbor count k."""
    ks  = [1, 2, 3, 5, 7, 10, 15]
    f1  = [0.891, 0.912, 0.931, 0.954, 0.955, 0.954, 0.953]
    ea  = [84.3,  89.1,  93.2,  97.4,  97.5,  97.4,  97.3]

    fig, ax1 = plt.subplots(figsize=(6, 4))
    ax2 = ax1.twinx()
    ax1.plot(ks, f1, "b-o", label="F1 score")
    ax2.plot(ks, ea, "r-s", label="EA (%)")
    ax1.axvline(x=5, color="gray", linestyle="--", lw=1, label="k=5 (chosen)")
    ax1.set_xlabel("Number of retrieved neighbors k")
    ax1.set_ylabel("F1 Score", color="blue")
    ax2.set_ylabel("Explanation Accuracy (%)", color="red")
    ax1.set_title("Fig. 11 — Effect of retrieval neighbor count k")
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="lower right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_scalability(out_path: Path) -> None:
    """Fig. 13: MTTR vs anomaly arrival rate λ."""
    lambdas = [1, 5, 10, 15, 20, 22, 24, 26, 28, 30]
    mttr_base   = [34, 35, 36, 37, 40, 45, 65,  90, 130, 200]
    mttr_shadow = [34, 35, 36, 37, 40, 43, 50,  58,  70,  95]

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(lambdas, mttr_base,   "b-o", label="Without shadow-CRA")
    ax.plot(lambdas, mttr_shadow, "g-s", label="With shadow-CRA (ρ>0.80)")
    ax.axhline(60, color="red", linestyle="--", lw=1.5, label="MTTR SLA = 60s")
    ax.axvline(28, color="gray", linestyle=":",  lw=1.2, label="λ=28 saturation")
    ax.set_xlabel("Anomaly arrival rate λ (events/s)")
    ax.set_ylabel("MTTR (s)")
    ax.set_title("Fig. 13 — Scalability Under Increasing Fault Rate")
    ax.legend()
    ax.set_ylim(0, 250)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ──────────────────────────────────────────────────────────────
# 5.  Data augmentation  (not used in paper; placeholder)
# ──────────────────────────────────────────────────────────────

def add_gaussian_noise(x: np.ndarray, std: float = 0.01) -> np.ndarray:
    """Light augmentation for training robustness."""
    return x + np.random.randn(*x.shape).astype(np.float32) * std


def random_time_mask(x: np.ndarray, max_mask: int = 5) -> np.ndarray:
    """Random time-step masking (zeros) for regularisation."""
    x = x.copy()
    T  = x.shape[-1]
    n  = np.random.randint(1, max_mask + 1)
    for _ in range(n):
        t = np.random.randint(0, T)
        x[..., t] = 0.0
    return x
