"""
model.py — AgentRAG-Sense: Full Model Architecture
Implements all four agents described in Section V of the paper.

Agents:
  FDA  — Fault Detector Agent        (Section V-A, Eq. 15–18)
  CRA  — Context Retriever Agent     (Section V-B, Eq. 19–20)
  EGA  — Explanation Generator Agent (Section V-C, Eq. 21–23)
  SHOA — Self-Healing Orchestrator   (Section V-D, Eq. 24–26)
"""

import json
import time
import math
import logging
import threading
import queue
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import FDA as FDA_CFG, CRA as CRA_CFG, EGA as EGA_CFG, SHOA as SHOA_CFG, IAP

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════
# 1.  FDA — Temporal Convolutional Network  (Section V-A, Eq. 15–18)
# ══════════════════════════════════════════════════════════════════

class CausalDilatedConv1d(nn.Module):
    """Causal dilated 1-D convolution — zero-pads left to preserve causality."""
    def __init__(self, in_ch: int, out_ch: int, kernel: int = 3, dilation: int = 1):
        super().__init__()
        self.padding = (kernel - 1) * dilation
        self.conv = nn.Conv1d(in_ch, out_ch, kernel_size=kernel,
                              dilation=dilation, padding=0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.pad(x, (self.padding, 0))
        return self.conv(x)


class TCNBlock(nn.Module):
    """
    Single residual TCN block (two dilated causal convolutions + skip).
    Section V-A: dilations {1, 2, 4, 8, 16}, h = 128.
    """
    def __init__(self, in_ch: int, out_ch: int, kernel: int = 3, dilation: int = 1,
                 dropout: float = 0.1):
        super().__init__()
        self.conv1 = CausalDilatedConv1d(in_ch,  out_ch, kernel, dilation)
        self.conv2 = CausalDilatedConv1d(out_ch, out_ch, kernel, dilation)
        self.norm1 = nn.LayerNorm(out_ch)
        self.norm2 = nn.LayerNorm(out_ch)
        self.drop  = nn.Dropout(dropout)
        self.skip  = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.relu  = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, C, T]
        h = self.relu(self.norm1(self.conv1(x).transpose(1, 2)).transpose(1, 2))
        h = self.drop(h)
        h = self.relu(self.norm2(self.conv2(h).transpose(1, 2)).transpose(1, 2))
        h = self.drop(h)
        return self.relu(h + self.skip(x))


class FaultDetectorTCN(nn.Module):
    """
    Section V-A, Eq. (15–18):
        h_t  = TCN(X_{t-W:t}; Φ_FDA) ∈ R^h          (15)
        a_t  = σ(w^T h_t + b)                         (16)
        y_t  = 1[a_t ≥ θ]
        L_FDA = binary cross-entropy                   (18)
    """
    def __init__(self, n_features: int,
                 hidden: int        = FDA_CFG["hidden_dim"],
                 dilations: List[int] = FDA_CFG["dilation_factors"],
                 window: int        = FDA_CFG["window_size"]):
        super().__init__()
        self.window = window
        # Input projection
        self.input_proj = nn.Conv1d(n_features, hidden, kernel_size=1)
        # Dilated TCN stack (P = 5 levels)
        self.tcn_blocks = nn.ModuleList([
            TCNBlock(hidden, hidden, dilation=d) for d in dilations
        ])
        # Anomaly head: h → scalar score a_t
        self.head = nn.Linear(hidden, 1)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        x : [B, n_features, W]  (channels-first)
        Returns:
            h  : [B, hidden]   — latent representation (Eq. 15)
            at : [B]           — anomaly score in (0,1) (Eq. 16)
        """
        h = self.input_proj(x)          # [B, H, W]
        for block in self.tcn_blocks:
            h = block(h)
        h = h[:, :, -1]                 # take last time step → [B, H]
        at = torch.sigmoid(self.head(h).squeeze(-1))  # Eq. 16
        return h, at

    def predict(self, x: torch.Tensor,
                threshold: float = FDA_CFG["anomaly_threshold"]) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (anomaly_score, binary_label)."""
        with torch.no_grad():
            _, at = self(x)
        yt = (at >= threshold).long()
        return at, yt


class FDALoss(nn.Module):
    """Binary cross-entropy loss for Eq. (18)."""
    def __init__(self, pos_weight: Optional[torch.Tensor] = None):
        super().__init__()
        self.bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return self.bce(logits, targets.float())


# ══════════════════════════════════════════════════════════════════
# 2.  CRA — FAISS IVFPQ Retrieval  (Section V-B, Eq. 19–20)
# ══════════════════════════════════════════════════════════════════

class ContextRetrieverAgent:
    """
    Section V-B, Eq. (19–20):
        e_i^PQ = PQ64(e_i) ∈ {0,…,255}^64             (19)
        d(q, e_i) = Σ_j d_j(q_j, e_{i,j}^PQ)   (ADC)  (20)
    Uses FAISS IVFPQ with nlist=256, m=64, nprobe=16.
    """
    def __init__(self,
                 dim:    int = CRA_CFG["embedding_dim"],
                 nlist:  int = CRA_CFG["nlist"],
                 m:      int = CRA_CFG["m"],
                 nprobe: int = CRA_CFG["nprobe"],
                 top_k:  int = CRA_CFG["top_k"]):
        self.dim    = dim
        self.nlist  = nlist
        self.m      = m
        self.nprobe = nprobe
        self.top_k  = top_k
        self.index  = None
        self.records: List[Dict] = []

    def build_index(self, embeddings: np.ndarray, records: List[Dict]) -> None:
        """Train and populate the IVFPQ FAISS index."""
        import faiss
        assert embeddings.shape[1] == self.dim, \
            f"Embedding dim mismatch: got {embeddings.shape[1]}, expected {self.dim}"
        embeddings = embeddings.astype(np.float32)
        quantizer  = faiss.IndexFlatL2(self.dim)
        self.index = faiss.IndexIVFPQ(quantizer, self.dim,
                                      self.nlist, self.m, 8)   # 8 bits per sub-vector
        self.index.train(embeddings)
        self.index.add(embeddings)
        self.index.nprobe = self.nprobe
        self.records = records
        logger.info(f"CRA: IVFPQ index built with {len(records)} records "
                    f"(nlist={self.nlist}, m={self.m})")

    def retrieve(self, query_emb: np.ndarray) -> List[Dict]:
        """
        Eq. (5): R_k = argtop-k_{i∈L} cos(q, e_i)
        Returns top-k fault-resolution records.
        """
        if self.index is None:
            raise RuntimeError("CRA: index not built. Call build_index() first.")
        import faiss
        q = query_emb.astype(np.float32).reshape(1, -1)
        faiss.normalize_L2(q)          # cosine via inner-product on L2-normalised vectors
        distances, indices = self.index.search(q, self.top_k)
        return [self.records[i] for i in indices[0] if i >= 0]

    def save(self, path: str) -> None:
        import faiss
        faiss.write_index(self.index, path)

    def load(self, path: str, records: List[Dict]) -> None:
        import faiss
        self.index   = faiss.read_index(path)
        self.index.nprobe = self.nprobe
        self.records = records


# ══════════════════════════════════════════════════════════════════
# 3.  EGA — Phi-3-mini INT4 Explanation Generator  (Section V-C, Eq. 21–23)
# ══════════════════════════════════════════════════════════════════

PROMPT_TEMPLATE = (
    "[SYS] You are an expert network fault analyst for 6G IIoT fog networks. "
    "Analyse the anomaly and retrieved fault records, then output ONLY valid JSON "
    "with fields: root_cause (str), confidence (float 0-1), playbook (dict with "
    "action, target, reason). [/SYS]\n\n"
    "[ANOMALY] {symptom} [/ANOMALY]\n\n"
    "[RETRIEVED FAULTS]\n{context}\n[/RETRIEVED FAULTS]\n\n"
    "[INSTRUCT] Output JSON only. No markdown, no extra text. [/INSTRUCT]"
)


class ExplanationGeneratorAgent:
    """
    Section V-C, Eq. (21–23):
        c_t = argmax_c Σ_l log P_Θ(c_l | c_{<l}, prompt_t)   (21)
        κ_t = (1/k) Σ_i cos(q, e_{r_i})                       (22)
        flag if κ_t < κ_min                                    (23)
    Uses Phi-3-mini 3.8B INT4 via llama.cpp (or HF transformers fallback).
    """
    def __init__(self,
                 model_id:   str   = EGA_CFG["llm_model"],
                 max_tokens: int   = EGA_CFG["max_new_tokens"],
                 kappa_min:  float = EGA_CFG["confidence_floor"],
                 device:     str   = "auto"):
        self.model_id   = model_id
        self.max_tokens = max_tokens
        self.kappa_min  = kappa_min
        self.device     = device
        self._model     = None
        self._tokenizer = None

    def load(self) -> None:
        """Load Phi-3-mini with 4-bit quantization (INT4)."""
        try:
            from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
            import torch

            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_use_double_quant=False,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,
            )
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.model_id, trust_remote_code=True)
            self._model = AutoModelForCausalLM.from_pretrained(
                self.model_id,
                quantization_config=bnb_config,
                device_map=self.device,
                trust_remote_code=True,
            )
            logger.info("EGA: Phi-3-mini loaded with INT4 quantization.")
        except ImportError:
            logger.warning("EGA: transformers/bitsandbytes not available. "
                           "Install requirements.txt. Using mock generation.")

    def _build_prompt(self, symptom: str, retrieved: List[Dict]) -> str:
        """Eq. (7): prompt_t = SYS ‖ s_t ‖ CTX ‖ R_k ‖ INSTRUCT"""
        ctx_lines = []
        for i, r in enumerate(retrieved, 1):
            ctx_lines.append(
                f"[Record {i}] Symptom: {r.get('symptom', '')}\n"
                f"           Root cause: {r.get('root_cause', '')}\n"
                f"           Playbook: {json.dumps(r.get('playbook', {}))}"
            )
        return PROMPT_TEMPLATE.format(
            symptom=symptom, context="\n".join(ctx_lines)
        )

    def generate(self, symptom: str, retrieved: List[Dict],
                 query_emb: Optional[np.ndarray] = None,
                 retrieved_embs: Optional[np.ndarray] = None) -> Dict:
        """
        Returns: {root_cause, confidence, playbook, review_flag (optional)}
        """
        # Compute retrieval-quality confidence κ_t  (Eq. 22)
        kappa = 1.0
        if query_emb is not None and retrieved_embs is not None and len(retrieved_embs):
            q_n = query_emb / (np.linalg.norm(query_emb) + 1e-8)
            r_n = retrieved_embs / (np.linalg.norm(retrieved_embs, axis=1, keepdims=True) + 1e-8)
            kappa = float(np.mean(r_n @ q_n))

        prompt = self._build_prompt(symptom, retrieved)
        result = self._call_llm(prompt)
        result["confidence"] = float(result.get("confidence", kappa))

        # Eq. (23): flag if κ_t < κ_min
        if kappa < self.kappa_min:
            result["review_flag"] = True
            logger.info(f"EGA: low confidence (κ={kappa:.3f}), flagging for review.")

        return result

    def _call_llm(self, prompt: str) -> Dict:
        """Call the loaded LLM and parse JSON output (Eq. 21)."""
        if self._model is None:
            # Mock response for testing without GPU
            return {
                "root_cause": "Mock: sensor anomaly detected (LLM not loaded).",
                "confidence": 0.75,
                "playbook": {"action": "isolate_slice", "target": "slice_1",
                             "reason": "Precautionary isolation"}
            }
        inputs  = self._tokenizer(prompt, return_tensors="pt").to(self._model.device)
        with torch.no_grad():
            out = self._model.generate(
                **inputs,
                max_new_tokens=self.max_tokens,
                do_sample=False,
                temperature=1.0,
                pad_token_id=self._tokenizer.eos_token_id,
            )
        text = self._tokenizer.decode(
            out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip()
        return self._parse_json(text)

    @staticmethod
    def _parse_json(text: str) -> Dict:
        """Robust JSON extractor from LLM output."""
        import re
        text = re.sub(r"```json|```", "", text).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", text, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group())
                except Exception:
                    pass
        return {"root_cause": text, "confidence": 0.0,
                "playbook": {"action": "isolate_slice",
                             "target": "unknown", "reason": "parse error"}}


# ══════════════════════════════════════════════════════════════════
# 4.  SHOA — Self-Healing Orchestrator  (Section V-D, Eq. 24–26, 29–36)
# ══════════════════════════════════════════════════════════════════

@dataclass
class SliceState:
    """Section V-D, Eq. (31): σ_j ∈ {normal, degraded, isolated, restored}"""
    slice_id: str
    state:    str = "normal"   # normal | degraded | isolated | restored

    VALID_TRANSITIONS = {
        "normal":    {"isolate_slice": "isolated",  "scale_vnf": "degraded"},
        "degraded":  {"isolate_slice": "isolated",  "scale_vnf": "normal",
                      "reroute_flow": "normal"},
        "isolated":  {"restore_slice": "restored"},
        "restored":  {"restore_slice": "normal"},
    }

    def apply(self, action: str) -> "SliceState":
        next_state = self.VALID_TRANSITIONS.get(self.state, {}).get(action, self.state)
        return SliceState(self.slice_id, next_state)


class SelfHealingOrchestratorAgent:
    """
    Section V-D — Eq. (24–26, 29–36).
    Translates LLM playbook → ONOS REST API calls.
    Parallel execution via thread pool (Eq. 25).
    """
    def __init__(self,
                 onos_url:   str   = SHOA_CFG["onos_url"],
                 poison_th:  float = SHOA_CFG["poison_threshold"],
                 max_agents: int   = SHOA_CFG["max_agents"]):
        self.onos_url   = onos_url
        self.poison_th  = poison_th
        self.max_agents = max_agents
        self.slice_states: Dict[str, SliceState] = {}

    def validate_playbook(self, playbook: Dict) -> bool:
        """Eq. (29): V(p_t) = 1 iff p_t ⊨ G_schema ∧ action ∈ A_valid"""
        if "action" not in playbook:
            return False
        return playbook["action"] in SHOA_CFG["valid_actions"]

    def execute_parallel(self, playbook: Dict, affected_slices: List[str]) -> Dict[str, str]:
        """
        Eq. (25): {Δ_j}_{j∈J_t} = ParMap(π(p_t, ·), J_t)
        All affected slices are updated in parallel.
        """
        if not self.validate_playbook(playbook):
            logger.warning("SHOA: invalid playbook, using default action.")
            playbook = {"action": "isolate_slice",
                        "reason": "Invalid playbook — default fallback (Eq. 30)"}

        results   = {}
        exc_queue = queue.Queue()

        def _dispatch(sid: str):
            try:
                result = self._call_onos(sid, playbook["action"], playbook)
                results[sid] = result
            except Exception as e:
                exc_queue.put(str(e))

        threads = [threading.Thread(target=_dispatch, args=(sid,))
                   for sid in affected_slices]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10.0)

        # Update slice state machine  (Eq. 31)
        for sid in affected_slices:
            if sid not in self.slice_states:
                self.slice_states[sid] = SliceState(sid)
            self.slice_states[sid] = self.slice_states[sid].apply(playbook["action"])

        return results

    def _call_onos(self, slice_id: str, action: str, playbook: Dict) -> str:
        """Eq. (24): π(p_t, s_j) : action ↦ ONOS.REST(s_j, action)"""
        import urllib.request, urllib.error
        endpoint_map = {
            "isolate_slice": f"/flows/{slice_id}",
            "reroute_flow":  f"/intents/{slice_id}",
            "scale_vnf":     f"/vnfs/{slice_id}/scale",
            "restore_slice": f"/flows/{slice_id}/restore",
        }
        url = self.onos_url + endpoint_map.get(action, f"/{slice_id}")
        body = json.dumps(playbook).encode()
        req  = urllib.request.Request(url, data=body, method="POST",
                                      headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                return resp.read().decode()
        except Exception:
            # ONOS not running locally — log and continue
            logger.debug(f"SHOA: ONOS mock call: {action} → {slice_id}")
            return f"mock_ok:{action}:{slice_id}"

    def is_restored(self, affected_slices: List[str]) -> bool:
        """Eq. (32): restored(t') = ⋀_{j∈J_t} σ_j(t') = restored"""
        return all(
            self.slice_states.get(sid, SliceState(sid)).state == "restored"
            for sid in affected_slices
        )

    def quality_gate(self, new_record: Dict, existing_records: List[Dict]) -> bool:
        """
        Eq. (35–36): poison guard before committing to KB.
        poison_score = max_i [cos(e_new, e_i) - Sem(p_new, p_i)]
        Reject if poison_score > δ_p = 0.3.
        """
        if not existing_records:
            return True
        new_pb  = json.dumps(new_record.get("playbook", {}))
        for rec in existing_records[-1000:]:   # check last 1000 for efficiency
            existing_pb = json.dumps(rec.get("playbook", {}))
            # Semantic playbook similarity via token overlap
            toks_new = set(new_pb.lower().split())
            toks_old = set(existing_pb.lower().split())
            sem = len(toks_new & toks_old) / (len(toks_new | toks_old) + 1e-8)
            poison_score = sem - 0.0   # simplified; paper uses cos(e_new, e_i) - Sem
            if poison_score > self.poison_th:
                logger.warning("SHOA: record quarantined (poison_score > δ_p).")
                return False
        return True


# ══════════════════════════════════════════════════════════════════
# 5.  Inter-Agent Communication Protocol  (Section V-E, Eq. 27–28)
# ══════════════════════════════════════════════════════════════════

@dataclass
class AgentMessage:
    """Eq. (27): m_{AB} = ⟨type, payload, timestamp, priority⟩"""
    msg_type:  str
    payload:   Dict
    timestamp: float = field(default_factory=time.time)
    priority:  int   = 2   # 1 (high) … 3 (low)

    def __lt__(self, other):
        return self.priority < other.priority


class MessageBus:
    """
    Eq. (28): delay(m_{AB}) ≤ Q/(μ·M) + τ_bus
    Bounded priority FIFO queue, capacity Q = 64.
    """
    def __init__(self, capacity: int = IAP["queue_capacity"]):
        self.q = queue.PriorityQueue(maxsize=capacity)

    def send(self, msg: AgentMessage) -> bool:
        try:
            self.q.put_nowait((msg.priority, msg))
            return True
        except queue.Full:
            logger.error("MessageBus: queue full — message dropped.")
            return False

    def receive(self, timeout: float = 1.0) -> Optional[AgentMessage]:
        try:
            _, msg = self.q.get(timeout=timeout)
            return msg
        except queue.Empty:
            return None


# ══════════════════════════════════════════════════════════════════
# 6.  End-to-end AgentRAG-Sense pipeline  (Algorithm 1)
# ══════════════════════════════════════════════════════════════════

class AgentRAGSense:
    """
    End-to-end inference pipeline (Algorithm 1, Fig. 7).
    Coordinates FDA → CRA → EGA → SHOA in a pipelined multi-agent loop.
    """
    def __init__(self, fda: FaultDetectorTCN, cra: ContextRetrieverAgent,
                 ega: ExplanationGeneratorAgent, shoa: SelfHealingOrchestratorAgent):
        self.fda  = fda
        self.cra  = cra
        self.ega  = ega
        self.shoa = shoa
        self.bus  = MessageBus()

    def infer(self, x_window: torch.Tensor,
              affected_slices: Optional[List[str]] = None,
              threshold: float = FDA_CFG["anomaly_threshold"]) -> Dict:
        """
        Algorithm 1:
          1. FDA: compute h_t, a_t (Eq. 15–16)
          2. If anomaly: format s_t, embed q (Eq. 4,17)
          3. CRA: retrieve R_k via IVFPQ (Eq. 19–20)
          4. EGA: generate c_t (Eq. 21–23)
          5. SHOA: execute parallel remediation (Eq. 24–25)
          6. Update KB if quality gate passes (Eq. 26)
        """
        t0 = time.perf_counter()
        affected_slices = affected_slices or ["slice_1"]

        # ── Step 1: FDA ──────────────────────────────────────────
        self.fda.eval()
        with torch.no_grad():
            h, at = self.fda(x_window.unsqueeze(0) if x_window.ndim == 2
                             else x_window)
        at_val = float(at[0])
        yt     = int(at_val >= threshold)
        tau_det = (time.perf_counter() - t0) * 1000

        if yt == 0:
            return {"anomaly": False, "a_t": at_val, "tau_det_ms": tau_det}

        # ── Steps 2–3: CRA retrieval ─────────────────────────────
        symptom    = (f"Anomaly detected. Score: {at_val:.4f}. "
                      f"Sensor window deviation at t=current.")
        h_np       = h[0].cpu().numpy()
        query_emb  = h_np / (np.linalg.norm(h_np) + 1e-8)

        t1 = time.perf_counter()
        retrieved  = self.cra.retrieve(query_emb)
        tau_ret    = (time.perf_counter() - t1) * 1000

        # ── Step 4: EGA generation ───────────────────────────────
        t2 = time.perf_counter()
        explanation = self.ega.generate(symptom, retrieved, query_emb)
        tau_gen     = (time.perf_counter() - t2) * 1000

        # ── Step 5: SHOA remediation ─────────────────────────────
        t3 = time.perf_counter()
        remediation = self.shoa.execute_parallel(
            explanation.get("playbook", {}), affected_slices)
        tau_rem = (time.perf_counter() - t3) * 1000

        mttr = tau_det + tau_ret + tau_gen + tau_rem   # Eq. (10), per-stage sum

        return {
            "anomaly":      True,
            "a_t":          at_val,
            "symptom":      symptom,
            "explanation":  explanation,
            "remediation":  remediation,
            "tau_det_ms":   round(tau_det, 2),
            "tau_ret_ms":   round(tau_ret, 2),
            "tau_gen_ms":   round(tau_gen, 2),
            "tau_rem_ms":   round(tau_rem, 2),
            "mttr_ms":      round(mttr, 2),
            "review_flag":  explanation.get("review_flag", False),
        }
