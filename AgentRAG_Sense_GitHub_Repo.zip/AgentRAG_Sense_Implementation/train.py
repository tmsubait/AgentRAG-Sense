"""
train.py — AgentRAG-Sense Training Script
Trains the FDA (Fault Detector Agent) TCN backbone.
Paper Table 4: AdamW lr=1e-4, batch=256, epochs=80, early-stop patience=10.
"""

import os
import json
import time
import logging
import argparse
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.cuda.amp import GradScaler, autocast
from torch.utils.tensorboard import SummaryWriter

from config import TRAIN, FDA as FDA_CFG, DATASETS, ACTIVE_DATASET, CKPT_BEST, CKPT_LAST, LOG_DIR
from dataset import get_dataloaders, load_raw, preprocess
from model import FaultDetectorTCN, FDALoss
from utils import set_seed, compute_metrics, EarlyStopper

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="Train AgentRAG-Sense FDA")
    p.add_argument("--dataset",    default=ACTIVE_DATASET, choices=list(DATASETS))
    p.add_argument("--epochs",     type=int,   default=TRAIN["epochs"])
    p.add_argument("--lr",         type=float, default=TRAIN["lr"])
    p.add_argument("--batch_size", type=int,   default=TRAIN["batch_size"])
    p.add_argument("--seed",       type=int,   default=TRAIN["random_seed"])
    p.add_argument("--device",     default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--amp",        action="store_true", default=TRAIN["mixed_precision"])
    return p.parse_args()


def train_one_epoch(model, loader, optimizer, loss_fn, scaler, device, amp):
    """Single training epoch with optional mixed-precision (AMP)."""
    model.train()
    total_loss = 0.0
    all_probs, all_labels = [], []

    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)

        with autocast(enabled=amp):
            h, at = model(x)
            # Use raw logits for numerically stable BCE  (re-derive from sigmoid output)
            logits = torch.logit(at.clamp(1e-6, 1 - 1e-6))
            loss   = loss_fn(logits, y)

        if amp:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), TRAIN["grad_clip"])
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), TRAIN["grad_clip"])
            optimizer.step()

        total_loss += loss.item() * len(y)
        all_probs.append(at.detach().cpu().numpy())
        all_labels.append(y.cpu().numpy())

    all_probs  = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)
    metrics    = compute_metrics(all_labels, all_probs, threshold=FDA_CFG["anomaly_threshold"])
    metrics["loss"] = total_loss / len(loader.dataset)
    return metrics


@torch.no_grad()
def validate(model, loader, loss_fn, device, amp):
    """Validation loop — returns metric dict."""
    model.eval()
    total_loss = 0.0
    all_probs, all_labels = [], []

    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        with autocast(enabled=amp):
            h, at = model(x)
            logits = torch.logit(at.clamp(1e-6, 1 - 1e-6))
            loss   = loss_fn(logits, y)
        total_loss += loss.item() * len(y)
        all_probs.append(at.cpu().numpy())
        all_labels.append(y.cpu().numpy())

    all_probs  = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)
    metrics    = compute_metrics(all_labels, all_probs, threshold=FDA_CFG["anomaly_threshold"])
    metrics["loss"] = total_loss / len(loader.dataset)
    return metrics


def main():
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device)
    logger.info(f"Device: {device}  |  Dataset: {args.dataset}  |  AMP: {args.amp}")

    # ── Data ─────────────────────────────────────────────────────
    train_loader, val_loader, _ = get_dataloaders(
        args.dataset, args.batch_size, seed=args.seed)

    n_features = DATASETS[args.dataset]["n_features"]
    logger.info(f"Features: {n_features}  |  Train batches: {len(train_loader)}")

    # ── Model ────────────────────────────────────────────────────
    model = FaultDetectorTCN(n_features=n_features).to(device)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"FDA parameters: {total_params:,}")

    # Class-imbalance weight  (anomaly_pct from Table 3)
    anomaly_pct = DATASETS[args.dataset]["anomaly_pct"]
    pos_weight  = torch.tensor([(1 - anomaly_pct) / anomaly_pct], device=device)
    loss_fn     = FDALoss(pos_weight=pos_weight)

    # ── Optimizer & Scheduler  (Table 4) ─────────────────────────
    optimizer = AdamW(model.parameters(),
                      lr=args.lr,
                      weight_decay=TRAIN["weight_decay"])
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
    scaler    = GradScaler(enabled=args.amp)
    stopper   = EarlyStopper(patience=TRAIN["early_stopping_patience"])

    # ── Logging ───────────────────────────────────────────────────
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    CKPT_BEST.parent.mkdir(parents=True, exist_ok=True)
    writer    = SummaryWriter(log_dir=str(LOG_DIR))
    best_f1   = -1.0
    history   = []

    logger.info("=" * 60)
    logger.info("Starting training (paper: AdamW lr=1e-4, epochs=80)")
    logger.info("=" * 60)

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        tr  = train_one_epoch(model, train_loader, optimizer, loss_fn, scaler, device, args.amp)
        vl  = validate(model, val_loader, loss_fn, device, args.amp)
        scheduler.step()

        elapsed = time.time() - t0
        row = dict(epoch=epoch, **{f"tr_{k}": v for k, v in tr.items()},
                   **{f"vl_{k}": v for k, v in vl.items()})
        history.append(row)

        # TensorBoard
        for tag, val in tr.items():
            writer.add_scalar(f"train/{tag}", val, epoch)
        for tag, val in vl.items():
            writer.add_scalar(f"val/{tag}", val, epoch)
        writer.add_scalar("lr", optimizer.param_groups[0]["lr"], epoch)

        # Console log
        logger.info(
            f"Epoch {epoch:3d}/{args.epochs}  "
            f"loss tr={tr['loss']:.4f} vl={vl['loss']:.4f}  "
            f"F1 tr={tr['f1']:.4f} vl={vl['f1']:.4f}  "
            f"({elapsed:.1f}s)"
        )

        # Save best
        if vl["f1"] > best_f1:
            best_f1 = vl["f1"]
            torch.save({"epoch": epoch, "model": model.state_dict(),
                        "optimizer": optimizer.state_dict(),
                        "val_f1": best_f1, "n_features": n_features},
                       CKPT_BEST)
            logger.info(f"  ✓ Best model saved (val F1={best_f1:.4f})")

        # Save last
        torch.save({"epoch": epoch, "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "n_features": n_features},
                   CKPT_LAST)

        # Early stopping
        if stopper(vl["f1"]):
            logger.info(f"Early stopping at epoch {epoch}")
            break

    writer.close()

    # Save training history
    hist_path = Path("results") / f"train_history_{args.dataset}.json"
    hist_path.parent.mkdir(exist_ok=True)
    with open(hist_path, "w") as f:
        json.dump(history, f, indent=2)
    logger.info(f"Training complete. Best val F1 = {best_f1:.4f}")
    logger.info(f"Best checkpoint: {CKPT_BEST}")


if __name__ == "__main__":
    main()
