"""
inference.py — AgentRAG-Sense Single-Event Inference
Algorithm 1: load model → accept sensor window → run full pipeline → visualize.
"""

import json
import argparse
import logging
import time
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import (DATASETS, ACTIVE_DATASET, CKPT_BEST, RESULTS_DIR,
                    FDA as FDA_CFG, CRA as CRA_CFG)
from dataset import generate_synthetic_kb, load_kb_records
from model import (FaultDetectorTCN, ContextRetrieverAgent,
                   ExplanationGeneratorAgent, SelfHealingOrchestratorAgent,
                   AgentRAGSense)
from utils import set_seed

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="AgentRAG-Sense Inference")
    p.add_argument("--dataset",     default=ACTIVE_DATASET, choices=list(DATASETS))
    p.add_argument("--checkpoint",  default=str(CKPT_BEST))
    p.add_argument("--kb_path",     default="checkpoints/faiss_ivfpq.index")
    p.add_argument("--records_path",default="checkpoints/kb_records.jsonl")
    p.add_argument("--device",      default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--visualize",   action="store_true", default=True)
    p.add_argument("--synthetic",   action="store_true", default=True,
                   help="Use synthetic sensor window (no real data needed)")
    return p.parse_args()


def generate_synthetic_window(n_features: int, window: int = FDA_CFG["window_size"],
                               anomaly: bool = True) -> torch.Tensor:
    """
    Generate a synthetic multivariate sensor window for demonstration.
    If anomaly=True, injects a spike pattern consistent with an attack.
    """
    rng = np.random.default_rng(42)
    x   = rng.normal(0, 1, size=(n_features, window)).astype(np.float32)
    if anomaly:
        # Inject a simulated sensor spike on the last 10 steps
        attack_channels = rng.choice(n_features, size=n_features // 5, replace=False)
        x[attack_channels, -10:] += rng.uniform(3, 6, size=(len(attack_channels), 10))
    return torch.from_numpy(x).unsqueeze(0)  # [1, d, W]


def build_pipeline(args, n_features: int) -> AgentRAGSense:
    """Instantiate and load all four agents."""
    device = torch.device(args.device)

    # ── FDA ──────────────────────────────────────────────────────
    fda = FaultDetectorTCN(n_features=n_features).to(device)
    ckpt_path = Path(args.checkpoint)
    if ckpt_path.exists():
        ckpt = torch.load(ckpt_path, map_location=device)
        fda.load_state_dict(ckpt["model"])
        logger.info(f"FDA loaded from {ckpt_path}")
    else:
        logger.warning("No checkpoint found — using randomly initialized FDA.")
    fda.eval()

    # ── CRA ──────────────────────────────────────────────────────
    cra     = ContextRetrieverAgent()
    kb_path = Path(args.kb_path)
    rec_path= Path(args.records_path)

    if kb_path.exists() and rec_path.exists():
        records = [json.loads(l) for l in open(rec_path)]
        cra.load(str(kb_path), records)
        logger.info(f"CRA: loaded {len(records)} records from {kb_path}")
    else:
        logger.info("CRA: building synthetic KB (L=1,000 records for demo) …")
        records = generate_synthetic_kb(n=1_000, seed=42)
        embeddings = np.random.randn(len(records), CRA_CFG["embedding_dim"]).astype(np.float32)
        # Normalise (mimic sentence-encoder output)
        embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-8
        cra.build_index(embeddings, [r.to_dict() for r in records])

    # ── EGA ──────────────────────────────────────────────────────
    ega = ExplanationGeneratorAgent()
    # EGA.load() loads Phi-3-mini INT4 — skip if no GPU/model files
    logger.info("EGA: using mock LLM (run ega.load() for Phi-3-mini INT4).")

    # ── SHOA ─────────────────────────────────────────────────────
    shoa = SelfHealingOrchestratorAgent()

    return AgentRAGSense(fda, cra, ega, shoa)


def visualize_result(result: dict, x_window: torch.Tensor,
                     n_features: int, out_path: Path):
    """Save a figure visualising the anomaly window and explanation."""
    fig, axes = plt.subplots(2, 1, figsize=(12, 6))

    # Top: sensor heatmap (first 20 channels)
    data = x_window[0, :min(20, n_features), :].cpu().numpy()
    im   = axes[0].imshow(data, aspect="auto", cmap="RdYlGn_r",
                           interpolation="nearest")
    axes[0].set_title("Sensor Window (first 20 channels) — anomaly injected at t≥50")
    axes[0].set_xlabel("Time step")
    axes[0].set_ylabel("Sensor channel")
    plt.colorbar(im, ax=axes[0])

    # Bottom: text summary
    axes[1].axis("off")
    expl = result.get("explanation", {})
    text = (
        f"Anomaly Score : {result.get('a_t', 0):.4f}\n"
        f"Root Cause    : {expl.get('root_cause', 'N/A')}\n"
        f"Confidence    : {expl.get('confidence', 0):.3f}\n"
        f"Playbook      : {json.dumps(expl.get('playbook', {}), indent=2)}\n"
        f"Review Flag   : {result.get('review_flag', False)}\n"
        f"τ_det={result.get('tau_det_ms', 0):.1f}ms  "
        f"τ_ret={result.get('tau_ret_ms', 0):.1f}ms  "
        f"τ_gen={result.get('tau_gen_ms', 0):.1f}ms  "
        f"τ_rem={result.get('tau_rem_ms', 0):.1f}ms  "
        f"MTTR={result.get('mttr_ms', 0):.1f}ms"
    )
    axes[1].text(0.01, 0.95, text, transform=axes[1].transAxes,
                 fontsize=9, verticalalignment="top", fontfamily="monospace",
                 bbox=dict(boxstyle="round", facecolor="lightyellow", alpha=0.8))

    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info(f"Visualisation saved: {out_path}")


def main():
    args       = parse_args()
    device     = torch.device(args.device)
    n_features = DATASETS[args.dataset]["n_features"]
    set_seed(42)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    pipeline = build_pipeline(args, n_features)

    # ── Input ─────────────────────────────────────────────────────
    if args.synthetic:
        logger.info("Using synthetic anomaly window (57 sensor channels, W=60).")
        x_window = generate_synthetic_window(n_features, anomaly=True).to(device)
    else:
        # Real data: load test set and take first window
        from dataset import get_dataloaders
        _, _, test_loader = get_dataloaders(args.dataset, batch_size=1)
        x_window, _ = next(iter(test_loader))
        x_window = x_window.to(device)

    # ── Run pipeline (Algorithm 1) ────────────────────────────────
    logger.info("Running AgentRAG-Sense inference pipeline …")
    result = pipeline.infer(x_window, affected_slices=["slice_1", "slice_2"])

    # ── Output ────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  AgentRAG-Sense Inference Result")
    print("=" * 60)
    print(json.dumps(result, indent=2, default=str))

    if args.visualize:
        out_path = RESULTS_DIR / f"inference_result_{args.dataset}.png"
        visualize_result(result, x_window, n_features, out_path)


if __name__ == "__main__":
    main()
