# AgentRAG-Sense

## Multi-Agent Retrieval-Augmented Generation for Context-Aware Anomaly Explanation and Self-Healing in 6G Industrial IoT Fog Networks

**Paper:** AgentRAG-Sense: A Multi-Agent Retrieval-Augmented Generation Framework for Context-Aware Anomaly Explanation and Self-Healing in 6G Industrial IoT Fog Networks  
**Year:** 2026  
**Code (paper link):** https://github.com/AgentRAG-Sense/TBA

---

## Abstract

AgentRAG-Sense is a four-agent RAG framework that autonomously detects anomalies, retrieves contextually similar historical fault records from a compressed FAISS knowledge base, generates human-readable root cause explanations using a quantized edge LLM (Phi-3-mini INT4), and translates playbooks into SDN/NFV control-plane API calls — all within fog-node memory and latency constraints. The system achieves 97.4% explanation accuracy and reduces MTTR from 14.3 minutes to 34 seconds on the SWaT, BATADAL, and WADI IIoT security benchmarks.

---

## Architecture

```
IIoT Sensor Stream (X_t)
         │
         ▼
┌─────────────────┐     ┌──────────────────────┐
│ Fault Detector  │────▶│ Context Retriever    │
│ Agent (FDA)     │ q   │ Agent (CRA)          │
│ TCN W=60, h=128 │     │ FAISS IVFPQ k=5      │
└─────────────────┘     └──────────┬───────────┘
         │  y_t=1                  │ R_k
         ▼                         ▼
         │              ┌──────────────────────┐
         └─────────────▶│ Explanation Generator│
                         │ Agent (EGA)          │
                         │ Phi-3-mini INT4      │
                         └──────────┬───────────┘
                                    │ c_t (playbook)
                                    ▼
                         ┌──────────────────────┐
                         │ Self-Healing Orch.   │
                         │ Agent (SHOA)         │
                         │ ONOS SDN REST API    │
                         └──────────────────────┘
```

**Four specialized agents (Section V):**
- **FDA** — TCN with dilated convolutions {1,2,4,8,16}, window W=60, hidden h=128
- **CRA** — FAISS IVFPQ index (nlist=256, m=64), top-k=5, τ_ret < 8ms
- **EGA** — Phi-3-mini 3.8B INT4 via llama.cpp, max 512 tokens, τ_gen = 54ms
- **SHOA** — Parallel slice remediation via ONOS northbound REST API

---

## Datasets

| Dataset | Samples | Features | Anomaly % | Download |
|---------|---------|----------|-----------|----------|
| SWaT    | 495,000 | 51 | 12.1% | [iTrust SUTD](https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/) |
| BATADAL | 87,600  | 43 | 14.6% | [batadal.net](https://www.batadal.net/data.html) |
| WADI    | 1,048,571 | 127 | 5.8% | [iTrust SUTD](https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/) |

All splits are **chronological** (70/10/20) to avoid look-ahead bias.

### Data placement
```
data/
  swat/
    SWaT_Dataset_Normal_v1.csv
    SWaT_Dataset_Attack_v0.csv
  batadal/
    BATADAL_dataset03.csv
    BATADAL_dataset04.csv
  wadi/
    WADI_14days_new.csv
    WADI_attackdataLABELS_new.csv
```

---

## Installation

```bash
git clone https://github.com/AgentRAG-Sense/TBA.git
cd AgentRAG-Sense_Implementation
pip install -r requirements.txt
```

**Jetson AGX Orin (paper hardware):** Use JetPack 6.0 PyTorch wheel and `faiss-gpu`.

**Containerised (recommended for reproducibility):**
```bash
docker build -t agentrag-sense .
docker run --gpus all agentrag-sense
```

---

## Usage

### Download data
```bash
python dataset.py --dataset swat      # prints iTrust registration URL
python dataset.py --dataset batadal   # auto-downloads from batadal.net
```

### Train FDA (Fault Detector Agent)
```bash
python train.py --dataset swat
# Options: --epochs 80  --lr 1e-4  --batch_size 256  --seed 42
```

### Evaluate
```bash
python evaluate.py --dataset swat
python evaluate.py --dataset batadal
python evaluate.py --dataset wadi
```

### Inference (single anomaly event)
```bash
python inference.py --dataset swat --synthetic   # no real data needed
python inference.py --dataset swat               # uses real test set
```

### Interactive demo
```bash
jupyter notebook notebooks/demo.ipynb
```

---

## Results (Table 6)

| Method | SWaT F1 | BATADAL F1 | WADI F1 | EA (%) |
|--------|---------|------------|---------|--------|
| LSTM-AE | 0.812 | 0.829 | 0.752 | n/a |
| GATformer | 0.865 | 0.872 | 0.804 | n/a |
| RAGLog | 0.852 | 0.861 | 0.793 | 79.2 |
| LLM-EI | 0.876 | 0.884 | 0.830 | n/a |
| LLMRCA | 0.889 | — | — | — |
| SDN-Slice-Sec | 0.898 | 0.832 | 0.825 | 84.3 |
| **AgentRAG-Sense** | **0.954** | **0.960** | **0.938** | **97.4** |

**MTTR:** 34s (vs 14.3 min human-in-loop, 3.7 min SDN-Slice-Sec)

---

## Folder Structure

```
AgentRAG_Sense_Implementation/
│
├── figures/                 ← All figures extracted from the paper (HD)
│   ├── fig01_motivation_explanation_action_gap.png
│   ├── fig02_system_overview.png
│   └── ...  (14 figures total)
│
├── data/                    ← Place dataset CSV files here
├── checkpoints/             ← Saved model checkpoints and FAISS index
├── results/                 ← Evaluation outputs, ROC curves, confusion matrices
│
├── notebooks/
│   └── demo.ipynb           ← Step-by-step walkthrough
│
├── config.py                ← All hyperparameters (Tables 3, 4)
├── dataset.py               ← Data loading, preprocessing, KB generation
├── model.py                 ← FDA, CRA, EGA, SHOA + AgentRAGSense pipeline
├── train.py                 ← Full training loop with TensorBoard logging
├── evaluate.py              ← Test-set evaluation, Tables 6 & 7
├── inference.py             ← Single-event inference + visualisation
├── utils.py                 ← Metrics, early stopping, plot helpers
└── requirements.txt         ← Python dependencies with exact versions
```

---

## Reproducibility

- Random seed: 42 (model init, data shuffling, NS-3 simulation)
- Chronological splits: no data leakage
- NS-3 6G simulation: `./waf --run "agentrag-sense --seed=42 --dataset=swat"`
- Full run variability: F1 = 0.954 ± 0.007, EA = 97.4 ± 0.6%, MTTR = 34 ± 3s
