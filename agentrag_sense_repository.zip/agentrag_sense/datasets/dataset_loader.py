"""
Dataset Loaders — SWaT, BATADAL, WADI
Chronological 70/10/20 splits (no random shuffle).
Public sources:
  SWaT/WADI: https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/
  BATADAL:   https://www.batadal.net/data.html
"""

import numpy as np
import pandas as pd
import os
from dataclasses import dataclass
from typing import Tuple, Optional
from sklearn.preprocessing import StandardScaler


@dataclass
class DatasetSplit:
    name: str
    X_train: np.ndarray
    X_val:   np.ndarray
    X_test:  np.ndarray
    y_train: np.ndarray
    y_val:   np.ndarray
    y_test:  np.ndarray
    n_features: int
    anomaly_rate: float
    scaler: StandardScaler


def _chronological_split(X: np.ndarray, y: np.ndarray,
                          train_ratio: float = 0.70,
                          val_ratio:   float = 0.10) -> Tuple:
    T = len(X)
    t1 = int(T * train_ratio)
    t2 = int(T * (train_ratio + val_ratio))
    return (X[:t1], X[t1:t2], X[t2:],
            y[:t1], y[t1:t2], y[t2:])


def load_swat(data_dir: str = "data/swat") -> Optional[DatasetSplit]:
    """
    SWaT: 51 channels, 495,000 samples, 12.1% anomaly.
    Expected files: SWaT_Dataset_Normal_v1.xlsx, SWaT_Dataset_Attack_v0.xlsx
    """
    normal_path = os.path.join(data_dir, "SWaT_Dataset_Normal_v1.xlsx")
    attack_path = os.path.join(data_dir, "SWaT_Dataset_Attack_v0.xlsx")

    if not os.path.exists(normal_path) or not os.path.exists(attack_path):
        print(f"[SWaT] Data files not found in {data_dir}. Generating synthetic data.")
        return _generate_synthetic("swat", n_samples=495000, n_features=51,
                                   anomaly_rate=0.121)
    normal = pd.read_excel(normal_path, skiprows=1)
    attack = pd.read_excel(attack_path, skiprows=1)
    feature_cols = [c for c in normal.columns if c not in ["Timestamp", "Normal/Attack"]]
    X_normal = normal[feature_cols].values.astype(np.float32)
    X_attack = attack[feature_cols].values.astype(np.float32)
    y_normal = np.zeros(len(X_normal), dtype=np.int32)
    label_col = "Normal/Attack" if "Normal/Attack" in attack.columns else attack.columns[-1]
    y_attack = (attack[label_col].str.strip() != "Normal").astype(np.int32).values
    X = np.concatenate([X_normal, X_attack], axis=0)
    y = np.concatenate([y_normal, y_attack], axis=0)
    return _prepare_split("swat", X, y)


def load_batadal(data_dir: str = "data/batadal") -> Optional[DatasetSplit]:
    """
    BATADAL: 43 channels, 87,600 samples, 14.6% anomaly.
    Expected files: BATADAL_dataset03.csv (training), BATADAL_dataset04.csv (test)
    """
    train_path = os.path.join(data_dir, "BATADAL_dataset03.csv")
    test_path  = os.path.join(data_dir, "BATADAL_dataset04.csv")

    if not os.path.exists(train_path):
        print(f"[BATADAL] Data files not found in {data_dir}. Generating synthetic data.")
        return _generate_synthetic("batadal", n_samples=87600, n_features=43,
                                   anomaly_rate=0.146)
    df_train = pd.read_csv(train_path, parse_dates=["DATETIME"])
    df_test  = pd.read_csv(test_path,  parse_dates=["DATETIME"])
    label_col   = "ATT_FLAG"
    exclude_cols = ["DATETIME", label_col]
    feature_cols = [c for c in df_train.columns if c not in exclude_cols]
    df_train[feature_cols] = df_train[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    df_test[feature_cols]  = df_test[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    X = pd.concat([df_train[feature_cols], df_test[feature_cols]]).values.astype(np.float32)
    y_train = (df_train[label_col] != -1).astype(np.int32).values
    y_test  = df_test[label_col].astype(np.int32).values
    y = np.concatenate([y_train, y_test])
    return _prepare_split("batadal", X, y)


def load_wadi(data_dir: str = "data/wadi") -> Optional[DatasetSplit]:
    """
    WADI: 127 channels, 1,048,571 samples, 5.8% anomaly.
    Expected files: WADI_attackdataLABELED_10.csv, WADI_14days_new.csv
    """
    normal_path = os.path.join(data_dir, "WADI_14days_new.csv")
    attack_path = os.path.join(data_dir, "WADI_attackdataLABELED_10.csv")

    if not os.path.exists(normal_path) or not os.path.exists(attack_path):
        print(f"[WADI] Data files not found in {data_dir}. Generating synthetic data.")
        return _generate_synthetic("wadi", n_samples=1048571, n_features=127,
                                   anomaly_rate=0.058)
    df_normal = pd.read_csv(normal_path, low_memory=False)
    df_attack = pd.read_csv(attack_path, low_memory=False)
    exclude   = ["Row", "Date", "Time", "Attack LABLE (1:No Attack, -1:Attack)"]
    feat_cols = [c for c in df_attack.columns if c not in exclude]
    label_col = "Attack LABLE (1:No Attack, -1:Attack)"
    df_normal[feat_cols] = df_normal[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    df_attack[feat_cols] = df_attack[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    X_normal = df_normal[feat_cols].values.astype(np.float32)
    X_attack = df_attack[feat_cols].values.astype(np.float32)
    y_normal = np.zeros(len(X_normal), dtype=np.int32)
    y_attack = (df_attack[label_col] == -1).astype(np.int32).values
    X = np.concatenate([X_normal, X_attack], axis=0)
    y = np.concatenate([y_normal, y_attack], axis=0)
    return _prepare_split("wadi", X, y)


def _prepare_split(name: str, X: np.ndarray, y: np.ndarray) -> DatasetSplit:
    scaler = StandardScaler()
    X_train, X_val, X_test, y_train, y_val, y_test = _chronological_split(X, y)
    X_train = scaler.fit_transform(X_train).astype(np.float32)
    X_val   = scaler.transform(X_val).astype(np.float32)
    X_test  = scaler.transform(X_test).astype(np.float32)
    anomaly_rate = float(y.mean())
    print(f"[{name.upper()}] {len(X)} samples | {X.shape[1]} features | "
          f"{anomaly_rate:.1%} anomaly | train/val/test: "
          f"{len(X_train)}/{len(X_val)}/{len(X_test)}")
    return DatasetSplit(
        name=name,
        X_train=X_train, X_val=X_val, X_test=X_test,
        y_train=y_train, y_val=y_val, y_test=y_test,
        n_features=X.shape[1],
        anomaly_rate=anomaly_rate,
        scaler=scaler
    )


def _generate_synthetic(name: str, n_samples: int, n_features: int,
                         anomaly_rate: float, seed: int = 42) -> DatasetSplit:
    """
    Generate synthetic data that matches dataset statistics.
    Used when real dataset files are not available.
    """
    np.random.seed(seed)
    print(f"[{name.upper()}] Generating {n_samples} synthetic samples, "
          f"{n_features} features, {anomaly_rate:.1%} anomaly rate")
    X = np.random.randn(n_samples, n_features).astype(np.float32)
    y = np.zeros(n_samples, dtype=np.int32)
    n_anomaly = int(n_samples * anomaly_rate)
    # Inject anomalies in contiguous blocks (realistic)
    block_sizes = np.random.randint(50, 500, size=n_anomaly // 100 + 1)
    start = int(n_samples * 0.3)
    placed = 0
    for bs in block_sizes:
        if placed >= n_anomaly:
            break
        end = min(start + bs, n_samples)
        y[start:end] = 1
        n_affected = np.random.randint(1, max(2, n_features // 10))
        channels = np.random.choice(n_features, n_affected, replace=False)
        X[start:end, channels] += np.random.uniform(3.5, 8.0, size=(end-start, n_affected))
        placed += (end - start)
        start = end + np.random.randint(100, 1000)
        if start >= n_samples:
            break
    return _prepare_split(name, X, y)
