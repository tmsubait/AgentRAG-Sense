"""
Context Retriever Agent (CRA) — AgentRAG-Sense
FAISS IVFPQ compressed retrieval, nlist=256, m=64 subquantizers.
Eq.(19)-(20) from paper.
"""

import numpy as np
import faiss
import json
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from sentence_transformers import SentenceTransformer


@dataclass
class RetrievedRecord:
    symptom: str
    root_cause: str
    playbook: Dict[str, Any]
    similarity: float
    record_id: int


@dataclass
class CRAMessage:
    query: str
    top_k_records: List[RetrievedRecord]
    retrieval_latency_ms: float
    confidence_score: float       # kappa_t Eq.(22)


class KnowledgeBase:
    """
    50,000-record FAISS IVFPQ index.
    PQ64 quantization: 4*de bytes -> 64 bytes per record.
    3.2 MB total memory footprint.
    """
    def __init__(self, embedding_dim: int = 384, nlist: int = 256,
                 m: int = 64, nprobe: int = 16):
        self.embedding_dim = embedding_dim
        self.nlist = nlist
        self.m = m
        self.nprobe = nprobe
        self.index = None
        self.records: List[Dict] = []
        self.encoder: Optional[SentenceTransformer] = None

    def build_index(self, records: List[Dict], encoder: SentenceTransformer):
        """
        Build IVFPQ index from records.
        Each record: {symptom, root_cause, playbook}
        """
        self.encoder = encoder
        self.records = records
        print(f"Encoding {len(records)} records...")
        symptoms = [r["symptom"] for r in records]
        embeddings = encoder.encode(symptoms, batch_size=256,
                                    show_progress_bar=True,
                                    normalize_embeddings=True)
        embeddings = np.array(embeddings, dtype=np.float32)
        quantizer = faiss.IndexFlatL2(self.embedding_dim)
        self.index = faiss.IndexIVFPQ(quantizer, self.embedding_dim,
                                       self.nlist, self.m, 8)
        print("Training IVFPQ index...")
        self.index.train(embeddings)
        self.index.add(embeddings)
        self.index.nprobe = self.nprobe
        print(f"Index built: {self.index.ntotal} vectors, "
              f"estimated size: {self.index.ntotal * self.m / (1024**2):.2f} MB")

    def save(self, index_path: str, records_path: str):
        faiss.write_index(self.index, index_path)
        with open(records_path, "w") as f:
            json.dump(self.records, f)
        print(f"Index saved to {index_path}")

    def load(self, index_path: str, records_path: str,
             encoder: SentenceTransformer):
        self.index = faiss.read_index(index_path)
        self.index.nprobe = self.nprobe
        with open(records_path) as f:
            self.records = json.load(f)
        self.encoder = encoder
        print(f"Loaded index with {self.index.ntotal} vectors")

    def add_record(self, record: Dict, embedding: Optional[np.ndarray] = None):
        """Continual growth: Eq.(26) quality-gated insertion."""
        if embedding is None:
            embedding = self.encoder.encode(
                [record["symptom"]], normalize_embeddings=True
            ).astype(np.float32)
        self.index.add(embedding)
        self.records.append(record)


class ContextRetrieverAgent:
    """
    CRA: FAISS IVFPQ retrieval with ADC (asymmetric distance computation).
    tau_ret < 8 ms at L=50,000.
    """
    def __init__(self, knowledge_base: KnowledgeBase, top_k: int = 5):
        self.kb = knowledge_base
        self.top_k = top_k

    def retrieve(self, query_text: str) -> CRAMessage:
        """
        Embed query, retrieve top-k records, compute confidence kappa_t Eq.(22).
        """
        t0 = time.perf_counter()
        query_emb = self.kb.encoder.encode(
            [query_text], normalize_embeddings=True
        ).astype(np.float32)
        distances, indices = self.kb.index.search(query_emb, self.top_k)
        latency_ms = (time.perf_counter() - t0) * 1000
        top_k_records = []
        for rank, (dist, idx) in enumerate(zip(distances[0], indices[0])):
            if idx < 0 or idx >= len(self.kb.records):
                continue
            rec = self.kb.records[idx]
            similarity = float(1.0 - dist / 2.0)   # cosine from L2 on normalized vectors
            top_k_records.append(RetrievedRecord(
                symptom=rec["symptom"],
                root_cause=rec["root_cause"],
                playbook=rec["playbook"],
                similarity=max(0.0, similarity),
                record_id=int(idx)
            ))
        # kappa_t: mean cosine similarity Eq.(22)
        kappa_t = float(np.mean([r.similarity for r in top_k_records])) if top_k_records else 0.0
        return CRAMessage(
            query=query_text,
            top_k_records=top_k_records,
            retrieval_latency_ms=latency_ms,
            confidence_score=kappa_t
        )
