"""
AgentRAG-Sense End-to-End Inference Pipeline
Coordinates FDA -> CRA -> EGA -> SHOA with inter-agent message passing.
Algorithm 1 from paper.
"""

import time
import numpy as np
import queue
import threading
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from agents.fault_detector_agent import FaultDetectorAgent, FDAMessage
from agents.context_retriever_agent import ContextRetrieverAgent, KnowledgeBase
from agents.explanation_generator_agent import ExplanationGeneratorAgent
from agents.self_healing_orchestrator import SelfHealingOrchestratorAgent, ONOSController


@dataclass
class AgentMessage:
    """Typed inter-agent message. Eq.(27)."""
    msg_type: str
    payload: Any
    timestamp: float = field(default_factory=time.time)
    priority: int = 2          # 1=high, 2=normal, 3=low


@dataclass
class PipelineResult:
    timestamp: int
    anomaly_detected: bool
    anomaly_score: float
    symptom: str
    root_cause: str
    confidence: float
    playbook: Dict
    review_flag: bool
    affected_slices: List[str]
    slices_restored: List[str]
    success: bool
    mttr_seconds: float
    latency_breakdown: Dict[str, float]


class MessageBus:
    """
    Bounded FIFO queue, capacity Q=64. Eq.(28).
    """
    def __init__(self, capacity: int = 64):
        self.capacity = capacity
        self._queue = queue.PriorityQueue(maxsize=capacity)

    def put(self, msg: AgentMessage) -> bool:
        try:
            self._queue.put_nowait((msg.priority, msg.timestamp, msg))
            return True
        except queue.Full:
            return False

    def get(self, timeout: float = 1.0) -> Optional[AgentMessage]:
        try:
            _, _, msg = self._queue.get(timeout=timeout)
            return msg
        except queue.Empty:
            return None


class AgentRAGSensePipeline:
    """
    Full AgentRAG-Sense inference pipeline.
    Algorithm 1: FDA -> CRA -> EGA -> SHOA.
    """
    def __init__(self,
                 fda: FaultDetectorAgent,
                 cra: ContextRetrieverAgent,
                 ega: ExplanationGeneratorAgent,
                 shoa: SelfHealingOrchestratorAgent,
                 top_k: int = 5,
                 kappa_min: float = 0.65,
                 num_fog_nodes: int = 10):
        self.fda = fda
        self.cra = cra
        self.ega = ega
        self.shoa = shoa
        self.top_k = top_k
        self.kappa_min = kappa_min
        self.num_fog_nodes = num_fog_nodes
        self.message_bus = MessageBus(capacity=64)
        self.results: List[PipelineResult] = []

    def _identify_affected_slices(self, symptom: str,
                                   anomaly_score: float) -> List[str]:
        """Identify network slices from symptom descriptor."""
        import re
        matches = re.findall(r'slice[:\s_](\w+)', symptom, re.IGNORECASE)
        if matches:
            return [f"slice_{m}" for m in matches]
        n_affected = max(1, int(anomaly_score * self.num_fog_nodes / 2))
        return [f"slice_{i}" for i in range(n_affected)]

    def run_single(self, xt_window: np.ndarray, timestamp: int,
                   slice_id: int = 0,
                   expert_label: Optional[str] = None) -> PipelineResult:
        """
        Algorithm 1: Single-event inference.
        Steps 1-11 from paper.
        """
        detection_start = time.perf_counter()

        # Step 1-2: FDA detection
        fda_msg = self.fda.detect(xt_window, timestamp, slice_id)
        tau_det = (time.perf_counter() - detection_start) * 1000

        if fda_msg.anomaly_flag == 0:
            return PipelineResult(
                timestamp=timestamp,
                anomaly_detected=False,
                anomaly_score=fda_msg.anomaly_score,
                symptom="",
                root_cause="no_anomaly",
                confidence=1.0,
                playbook={},
                review_flag=False,
                affected_slices=[],
                slices_restored=[],
                success=True,
                mttr_seconds=0.0,
                latency_breakdown={"tau_det": tau_det}
            )

        # Step 3: FDA emits symptom
        self.message_bus.put(AgentMessage("fda_out", fda_msg, priority=1))

        # Step 4: CRA retrieval
        retrieval_start = time.perf_counter()
        cra_msg = self.cra.retrieve(fda_msg.symptom_descriptor)
        tau_ret = (time.perf_counter() - retrieval_start) * 1000
        self.message_bus.put(AgentMessage("cra_out", cra_msg, priority=1))

        # Step 5-6: EGA generation with confidence
        gen_start = time.perf_counter()
        ega_msg = self.ega.generate(cra_msg, kappa_t=cra_msg.confidence_score)
        tau_gen = (time.perf_counter() - gen_start) * 1000
        self.message_bus.put(AgentMessage("ega_out", ega_msg, priority=1))

        # Step 7: SHOA parallel remediation
        affected_slices = self._identify_affected_slices(
            fda_msg.symptom_descriptor, fda_msg.anomaly_score
        )
        rem_start = time.perf_counter()
        shoa_msg = self.shoa.remediate(ega_msg, affected_slices, detection_start)
        tau_rem = (time.perf_counter() - rem_start) * 1000

        # Step 8: KB update (async)
        update_thread = threading.Thread(
            target=self.shoa.update_knowledge_base,
            args=(fda_msg.symptom_descriptor, ega_msg, expert_label, True),
            daemon=True
        )
        update_thread.start()

        result = PipelineResult(
            timestamp=timestamp,
            anomaly_detected=True,
            anomaly_score=fda_msg.anomaly_score,
            symptom=fda_msg.symptom_descriptor,
            root_cause=ega_msg.root_cause,
            confidence=ega_msg.confidence,
            playbook=ega_msg.playbook,
            review_flag=ega_msg.review_flag,
            affected_slices=affected_slices,
            slices_restored=shoa_msg.slices_restored,
            success=shoa_msg.success,
            mttr_seconds=shoa_msg.mttr_seconds,
            latency_breakdown={
                "tau_det": tau_det,
                "tau_ret": tau_ret,
                "tau_gen": tau_gen,
                "tau_rem": tau_rem,
                "total_ms": tau_det + tau_ret + tau_gen + tau_rem
            }
        )
        self.results.append(result)
        return result

    def run_stream(self, data_stream: np.ndarray,
                   labels: np.ndarray,
                   window: int = 60,
                   stride: int = 1) -> List[PipelineResult]:
        """
        Run inference over a full dataset stream.
        data_stream shape: (T, D)
        labels shape: (T,)
        """
        results = []
        T = data_stream.shape[0]
        for t in range(window, T, stride):
            window_data = data_stream[t-window:t].T   # (D, W)
            result = self.run_single(window_data, timestamp=t)
            results.append(result)
            if t % 1000 == 0:
                print(f"Processed {t}/{T} timesteps")
        self.results = results
        return results
