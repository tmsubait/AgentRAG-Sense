"""
Explanation Generator Agent (EGA) — AgentRAG-Sense
Phi-3-mini INT4 via llama.cpp with JSON schema-constrained CoT decoding.
Eq.(6),(7),(21)-(23) from paper.
"""

import json
import time
import re
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
from agents.context_retriever_agent import CRAMessage, RetrievedRecord


@dataclass
class EGAMessage:
    root_cause: str
    confidence: float
    playbook: Dict[str, Any]
    generation_latency_ms: float
    review_flag: bool             # True when kappa_t < kappa_min (Eq.23)
    raw_output: str


SYSTEM_PROMPT = """You are an expert industrial control system fault analyst embedded on a fog node.
Given an anomaly symptom and retrieved historical fault records, produce a JSON explanation.
Respond ONLY with valid JSON matching this schema:
{
  "root_cause": "<string: specific fault type from the 14-category taxonomy>",
  "confidence": <float: 0.0-1.0>,
  "playbook": {
    "actions": ["<action1>", "<action2>"],
    "priority": "<containment|restoration>",
    "target_slices": ["<slice_id>"]
  }
}
Valid actions: isolate_slice, reroute_flow, scale_vnf, restore_slice.
Priority ordering: isolate_slice > reroute_flow > scale_vnf > restore_slice."""

CONTEXT_TEMPLATE = """SYMPTOM:
{symptom}

RETRIEVED FAULT RECORDS (top-{k}):
{records}

INSTRUCTION:
Analyse the symptom against the retrieved records.
Identify the root cause, confidence, and remediation playbook.
Respond with JSON only."""


def build_prompt(symptom: str, records: List[RetrievedRecord]) -> str:
    record_strs = []
    for i, rec in enumerate(records):
        record_strs.append(
            f"[Record {i+1}] Similarity={rec.similarity:.3f}\n"
            f"  Symptom: {rec.symptom}\n"
            f"  Root cause: {rec.root_cause}\n"
            f"  Playbook: {json.dumps(rec.playbook)}"
        )
    context = CONTEXT_TEMPLATE.format(
        symptom=symptom,
        k=len(records),
        records="\n".join(record_strs)
    )
    return f"{SYSTEM_PROMPT}\n\n{context}"


class ExplanationGeneratorAgent:
    """
    EGA: Uses Phi-3-mini INT4 (llama.cpp backend) for generation.
    Falls back to rule-based explanation if llama.cpp unavailable.
    kappa_min=0.65 confidence floor for review flag (Eq.23).
    """
    def __init__(self, model_path: Optional[str] = None,
                 kappa_min: float = 0.65, max_tokens: int = 512,
                 use_llamacpp: bool = True):
        self.kappa_min = kappa_min
        self.max_tokens = max_tokens
        self.llm = None
        if use_llamacpp and model_path:
            self._load_llamacpp(model_path)

    def _load_llamacpp(self, model_path: str):
        try:
            from llama_cpp import Llama
            self.llm = Llama(
                model_path=model_path,
                n_ctx=2048,
                n_threads=4,
                verbose=False
            )
            print(f"Phi-3-mini INT4 loaded from {model_path}")
        except ImportError:
            print("llama_cpp not installed. Using rule-based fallback.")
        except Exception as e:
            print(f"LLM load failed: {e}. Using rule-based fallback.")

    def generate(self, cra_message: CRAMessage,
                 kappa_t: float) -> EGAMessage:
        """
        Generate root-cause explanation. Eq.(21).
        Apply review flag Eq.(23) when kappa_t < kappa_min.
        """
        prompt = build_prompt(cra_message.query, cra_message.top_k_records)
        t0 = time.perf_counter()
        if self.llm is not None:
            raw = self._generate_llamacpp(prompt)
        else:
            raw = self._generate_fallback(cra_message)
        latency_ms = (time.perf_counter() - t0) * 1000
        parsed = self._parse_output(raw, cra_message)
        review_flag = kappa_t < self.kappa_min
        return EGAMessage(
            root_cause=parsed["root_cause"],
            confidence=parsed["confidence"],
            playbook=parsed["playbook"],
            generation_latency_ms=latency_ms,
            review_flag=review_flag,
            raw_output=raw
        )

    def _generate_llamacpp(self, prompt: str) -> str:
        response = self.llm(
            prompt,
            max_tokens=self.max_tokens,
            temperature=0.1,
            stop=["}\n\n"],
            echo=False
        )
        return response["choices"][0]["text"].strip()

    def _generate_fallback(self, cra_message: CRAMessage) -> str:
        """Rule-based fallback when LLM unavailable."""
        if not cra_message.top_k_records:
            return json.dumps({
                "root_cause": "unknown_fault",
                "confidence": 0.3,
                "playbook": {
                    "actions": ["isolate_slice"],
                    "priority": "containment",
                    "target_slices": ["slice_0"]
                }
            })
        best = cra_message.top_k_records[0]
        playbook = best.playbook if isinstance(best.playbook, dict) else {
            "actions": ["isolate_slice", "restore_slice"],
            "priority": "containment",
            "target_slices": ["slice_0"]
        }
        return json.dumps({
            "root_cause": best.root_cause,
            "confidence": round(best.similarity, 3),
            "playbook": playbook
        })

    def _parse_output(self, raw: str,
                      cra_message: CRAMessage) -> Dict[str, Any]:
        """Parse and validate JSON output from LLM."""
        try:
            match = re.search(r'\{.*\}', raw, re.DOTALL)
            if match:
                parsed = json.loads(match.group())
                assert "root_cause" in parsed
                assert "confidence" in parsed
                assert "playbook" in parsed
                return parsed
        except Exception:
            pass
        return {
            "root_cause": "parse_error_fault",
            "confidence": 0.5,
            "playbook": {
                "actions": ["isolate_slice"],
                "priority": "containment",
                "target_slices": ["slice_0"]
            }
        }
