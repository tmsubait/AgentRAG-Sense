"""
Self-Healing Orchestrator Agent (SHOA) — AgentRAG-Sense
Playbook-to-SDN translation, parallel slice remediation, poisoning defense.
Eq.(24)-(36) from paper.
"""

import time
import json
import numpy as np
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set
from agents.explanation_generator_agent import EGAMessage
from agents.context_retriever_agent import KnowledgeBase


VALID_ACTIONS: Set[str] = {
    "isolate_slice", "reroute_flow", "scale_vnf", "restore_slice"
}
ACTION_PRIORITY = {
    "isolate_slice": 0,
    "reroute_flow": 1,
    "scale_vnf": 2,
    "restore_slice": 3
}

# Slice state machine valid transitions Eq.(31)
VALID_TRANSITIONS = {
    "normal":    {"isolate_slice": "isolated",  "reroute_flow": "degraded"},
    "degraded":  {"reroute_flow":  "normal",    "scale_vnf": "normal", "isolate_slice": "isolated"},
    "isolated":  {"restore_slice": "restored"},
    "restored":  {"isolate_slice": "isolated",  "reroute_flow": "degraded"}
}


@dataclass
class SliceState:
    slice_id: str
    state: str = "normal"
    last_action: str = ""
    remediation_time_ms: float = 0.0


@dataclass
class SHOAMessage:
    actions_dispatched: List[Dict[str, Any]]
    remediation_latency_ms: float
    slices_restored: List[str]
    success: bool
    mttr_seconds: float = 0.0


class ONOSController:
    """
    ONOS SDN northbound REST API interface.
    tau_API = 5 ms measured round-trip (Eq.9).
    """
    def __init__(self, host: str = "localhost", port: int = 8181,
                 username: str = "onos", password: str = "rocks",
                 simulate: bool = True):
        self.base_url = f"http://{host}:{port}/onos/v1"
        self.auth = (username, password)
        self.simulate = simulate
        self.slice_states: Dict[str, SliceState] = {}

    def _get_slice(self, slice_id: str) -> SliceState:
        if slice_id not in self.slice_states:
            self.slice_states[slice_id] = SliceState(slice_id=slice_id)
        return self.slice_states[slice_id]

    def isolate_slice(self, slice_id: str) -> Dict:
        state = self._get_slice(slice_id)
        if self.simulate:
            time.sleep(0.005)   # 5 ms simulated API round-trip
            new_state = VALID_TRANSITIONS.get(state.state, {}).get("isolate_slice", state.state)
            state.state = new_state
            state.last_action = "isolate_slice"
            return {"status": "ok", "slice_id": slice_id, "new_state": new_state}
        try:
            resp = requests.post(
                f"{self.base_url}/network/configuration/apps/org.onosproject.segmentrouting",
                json={"slice_id": slice_id, "action": "isolate"},
                auth=self.auth, timeout=0.1
            )
            return resp.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def reroute_flow(self, slice_id: str) -> Dict:
        state = self._get_slice(slice_id)
        if self.simulate:
            time.sleep(0.005)
            new_state = VALID_TRANSITIONS.get(state.state, {}).get("reroute_flow", state.state)
            state.state = new_state
            state.last_action = "reroute_flow"
            return {"status": "ok", "slice_id": slice_id, "new_state": new_state}
        try:
            resp = requests.post(
                f"{self.base_url}/flows",
                json={"slice_id": slice_id, "action": "reroute"},
                auth=self.auth, timeout=0.1
            )
            return resp.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def scale_vnf(self, slice_id: str) -> Dict:
        state = self._get_slice(slice_id)
        if self.simulate:
            time.sleep(0.005)
            new_state = VALID_TRANSITIONS.get(state.state, {}).get("scale_vnf", state.state)
            state.state = new_state
            state.last_action = "scale_vnf"
            return {"status": "ok", "slice_id": slice_id, "new_state": new_state}
        try:
            resp = requests.post(
                f"{self.base_url}/vnf/scale",
                json={"slice_id": slice_id},
                auth=self.auth, timeout=0.1
            )
            return resp.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def restore_slice(self, slice_id: str) -> Dict:
        state = self._get_slice(slice_id)
        if self.simulate:
            time.sleep(0.005)
            new_state = VALID_TRANSITIONS.get(state.state, {}).get("restore_slice", state.state)
            state.state = new_state
            state.last_action = "restore_slice"
            return {"status": "ok", "slice_id": slice_id, "new_state": new_state}
        try:
            resp = requests.post(
                f"{self.base_url}/flows/restore",
                json={"slice_id": slice_id},
                auth=self.auth, timeout=0.1
            )
            return resp.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def dispatch_action(self, slice_id: str, action: str) -> Dict:
        """Eq.(24): action |-> ONOS.REST(sj, action)"""
        dispatch_map = {
            "isolate_slice": self.isolate_slice,
            "reroute_flow":  self.reroute_flow,
            "scale_vnf":     self.scale_vnf,
            "restore_slice": self.restore_slice
        }
        if action not in dispatch_map:
            return {"status": "error", "message": f"Unknown action: {action}"}
        return dispatch_map[action](slice_id)

    def is_restored(self, slice_id: str) -> bool:
        """Eq.(32): check restored state."""
        state = self._get_slice(slice_id)
        return state.state == "restored"


class PoisoningDefense:
    """
    Knowledge base poisoning guard. Eq.(35)-(36).
    delta_p = 0.3 threshold.
    """
    def __init__(self, delta_p: float = 0.3):
        self.delta_p = delta_p

    def compute_poison_score(self, new_record: Dict,
                              existing_records: List[Dict],
                              new_embedding: np.ndarray,
                              existing_embeddings: np.ndarray) -> float:
        """Eq.(35): max_i [cos(e_new, e_i) - Sem(p_new, p_i)]"""
        if len(existing_embeddings) == 0:
            return 0.0
        cosine_sims = np.dot(existing_embeddings, new_embedding) / (
            np.linalg.norm(existing_embeddings, axis=1) * np.linalg.norm(new_embedding) + 1e-8
        )
        new_actions = set(new_record.get("playbook", {}).get("actions", []))
        sem_sims = []
        for rec in existing_records:
            existing_actions = set(rec.get("playbook", {}).get("actions", []))
            if len(new_actions | existing_actions) == 0:
                sem_sims.append(1.0)
            else:
                overlap = len(new_actions & existing_actions) / len(new_actions | existing_actions)
                sem_sims.append(overlap)
        sem_sims = np.array(sem_sims)
        poison_scores = cosine_sims - sem_sims
        return float(np.max(poison_scores))

    def is_safe(self, poison_score: float, playbook: Dict) -> bool:
        """Eq.(36): safe if poison_score <= delta_p AND valid playbook."""
        actions = playbook.get("actions", [])
        valid_playbook = all(a in VALID_ACTIONS for a in actions) and len(actions) > 0
        return poison_score <= self.delta_p and valid_playbook


class SelfHealingOrchestratorAgent:
    """
    SHOA: parallel slice remediation, playbook schema validation, poisoning defense.
    Eq.(24)-(36).
    M_max = 4 parallel threads.
    """
    def __init__(self, onos: ONOSController,
                 knowledge_base: Optional[KnowledgeBase] = None,
                 mmax: int = 4, delta_p: float = 0.3,
                 accuracy_threshold: float = 0.95):
        self.onos = onos
        self.kb = knowledge_base
        self.mmax = mmax
        self.accuracy_threshold = accuracy_threshold
        self.poisoning_defense = PoisoningDefense(delta_p)
        self.executor = ThreadPoolExecutor(max_workers=mmax)

    def validate_playbook(self, playbook: Dict) -> bool:
        """Eq.(29): schema validation."""
        if "actions" not in playbook:
            return False
        actions = playbook["actions"]
        if not isinstance(actions, list) or len(actions) == 0:
            return False
        return all(a in VALID_ACTIONS for a in actions)

    def resolve_conflicts(self, actions: List[str]) -> List[str]:
        """Priority ordering: isolate > reroute > scale > restore."""
        return sorted(set(actions), key=lambda a: ACTION_PRIORITY.get(a, 99))

    def _dispatch_single_slice(self, slice_id: str,
                                actions: List[str]) -> Dict:
        """Dispatch actions to one slice sequentially."""
        results = []
        for action in actions:
            result = self.onos.dispatch_action(slice_id, action)
            results.append({"action": action, "result": result})
        restored = self.onos.is_restored(slice_id)
        return {"slice_id": slice_id, "results": results, "restored": restored}

    def remediate(self, ega_message: EGAMessage,
                  affected_slices: List[str],
                  detection_time: float) -> SHOAMessage:
        """
        Eq.(25): ParMap parallel remediation over affected slices.
        """
        playbook = ega_message.playbook
        t0 = time.perf_counter()

        # Validate playbook; use default if invalid Eq.(30)
        if not self.validate_playbook(playbook):
            playbook = {
                "actions": ["isolate_slice"],
                "priority": "containment",
                "target_slices": affected_slices
            }

        actions = self.resolve_conflicts(playbook.get("actions", ["isolate_slice"]))

        # Parallel dispatch Eq.(25)
        futures = {
            self.executor.submit(self._dispatch_single_slice, sid, actions): sid
            for sid in affected_slices
        }
        all_results = []
        restored_slices = []
        for future in as_completed(futures):
            result = future.result()
            all_results.append(result)
            if result.get("restored"):
                restored_slices.append(result["slice_id"])

        remediation_latency_ms = (time.perf_counter() - t0) * 1000
        success = len(restored_slices) == len(affected_slices)

        # MTTR = tau_det + tau_ret + tau_gen + tau_rem (Eq.10)
        mttr_seconds = (time.perf_counter() - detection_time)

        return SHOAMessage(
            actions_dispatched=all_results,
            remediation_latency_ms=remediation_latency_ms,
            slices_restored=restored_slices,
            success=success,
            mttr_seconds=mttr_seconds
        )

    def update_knowledge_base(self, symptom: str, ega_message: EGAMessage,
                               expert_label: Optional[str] = None,
                               post_resolution_check: bool = True):
        """
        Eq.(26): quality-gated KB update.
        Runs asynchronously after remediation confirmation.
        """
        if self.kb is None:
            return
        if expert_label is None and not post_resolution_check:
            return
        verified_root_cause = expert_label if expert_label else ega_message.root_cause
        acc = ega_message.confidence
        if acc < self.accuracy_threshold:
            return
        new_record = {
            "symptom": symptom,
            "root_cause": verified_root_cause,
            "playbook": ega_message.playbook
        }
        # Poisoning defense Eq.(35)-(36)
        new_emb = self.kb.encoder.encode(
            [symptom], normalize_embeddings=True
        )[0].astype(np.float32) if self.kb.encoder else np.zeros(384, dtype=np.float32)

        n = min(len(self.kb.records), 1000)
        if n > 0:
            sample_records = self.kb.records[-n:]
            sample_symptoms = [r["symptom"] for r in sample_records]
            sample_embs = self.kb.encoder.encode(
                sample_symptoms, normalize_embeddings=True
            ).astype(np.float32)
            poison_score = self.poisoning_defense.compute_poison_score(
                new_record, sample_records, new_emb, sample_embs
            )
        else:
            poison_score = 0.0

        if self.poisoning_defense.is_safe(poison_score, ega_message.playbook):
            self.kb.add_record(new_record, new_emb[np.newaxis])
        else:
            print(f"[PoisonGuard] Record quarantined. Score={poison_score:.3f}")
