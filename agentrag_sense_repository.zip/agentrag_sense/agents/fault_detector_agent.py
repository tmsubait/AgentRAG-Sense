"""
Fault Detector Agent (FDA) — AgentRAG-Sense
TCN-based anomaly detection with symptom descriptor generation.
"""

import torch
import torch.nn as nn
import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional


@dataclass
class FDAMessage:
    anomaly_flag: int          # yt in {0,1}
    anomaly_score: float       # at in [0,1]
    symptom_descriptor: str    # st natural-language string
    timestamp: int
    query_embedding: Optional[np.ndarray] = None


class DilatedTCNBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, dilation: int, kernel_size: int = 3):
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size,
                               dilation=dilation, padding=padding)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size,
                               dilation=dilation, padding=padding)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)
        self.residual = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.norm1 = nn.BatchNorm1d(out_channels)
        self.norm2 = nn.BatchNorm1d(out_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.residual(x)
        out = self.relu(self.norm1(self.conv1(x)[..., :x.size(-1)]))
        out = self.dropout(out)
        out = self.norm2(self.conv2(out)[..., :x.size(-1)])
        return self.relu(out + residual)


class TCNDetector(nn.Module):
    """
    Temporal Convolutional Network with dilation factors {1,2,4,8,16}.
    Window W=60, hidden dimension h=128.
    Eq.(15)-(16) from paper.
    """
    def __init__(self, input_dim: int, hidden_dim: int = 128, window: int = 60):
        super().__init__()
        self.window = window
        dilations = [1, 2, 4, 8, 16]
        layers = []
        in_ch = input_dim
        for d in dilations:
            layers.append(DilatedTCNBlock(in_ch, hidden_dim, dilation=d))
            in_ch = hidden_dim
        self.tcn = nn.Sequential(*layers)
        self.classifier = nn.Linear(hidden_dim, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # x shape: (batch, input_dim, window)
        h = self.tcn(x)                        # (batch, hidden, window)
        h_last = h[:, :, -1]                   # (batch, hidden)
        score = self.sigmoid(self.classifier(h_last)).squeeze(-1)  # (batch,)
        return h_last, score


class FaultDetectorAgent:
    """
    FDA: monitors multivariate time series and produces anomaly flag + symptom descriptor.
    """
    def __init__(self, input_dim: int, threshold: float = 0.5,
                 hidden_dim: int = 128, window: int = 60, device: str = "cpu"):
        self.input_dim = input_dim
        self.threshold = threshold
        self.window = window
        self.device = device
        self.model = TCNDetector(input_dim, hidden_dim, window).to(device)
        self.model.eval()

    def load_weights(self, path: str):
        state = torch.load(path, map_location=self.device)
        self.model.load_state_dict(state)
        self.model.eval()

    def _format_symptom(self, xt: np.ndarray, score: float,
                         timestamp: int, slice_id: int = 0) -> str:
        """
        Eq.(17): deterministic symptom descriptor.
        Channels with z-score > 3.0 flagged as anomalous.
        """
        baseline = xt.mean(axis=1, keepdims=True)
        std = xt.std(axis=1, keepdims=True) + 1e-8
        z_scores = np.abs((xt[:, -1] - baseline[:, 0]) / std[:, 0])
        flagged = np.where(z_scores > 3.0)[0]
        if len(flagged) == 0:
            flagged = np.argsort(z_scores)[-3:]
        channel_list = flagged.tolist()
        magnitude_list = [round(float(z_scores[c]), 3) for c in channel_list]
        descriptor = (
            f"Anomaly detected at timestamp {timestamp}: "
            f"sensors {channel_list} deviated by {magnitude_list} sigma above normal; "
            f"associated network slice: {slice_id}."
        )
        return descriptor

    def detect(self, xt_window: np.ndarray, timestamp: int,
               slice_id: int = 0) -> FDAMessage:
        """
        Run detection on a window of shape (input_dim, window).
        Returns FDAMessage.
        """
        x_tensor = torch.FloatTensor(xt_window).unsqueeze(0).to(self.device)
        with torch.no_grad():
            h_last, score = self.model(x_tensor)
        score_val = float(score.item())
        flag = int(score_val >= self.threshold)
        descriptor = ""
        if flag == 1:
            descriptor = self._format_symptom(xt_window, score_val, timestamp, slice_id)
        return FDAMessage(
            anomaly_flag=flag,
            anomaly_score=score_val,
            symptom_descriptor=descriptor,
            timestamp=timestamp,
            query_embedding=h_last.cpu().numpy()[0] if flag == 1 else None
        )

    def train_model(self, train_loader, optimizer, epochs: int = 80,
                    patience: int = 10, val_loader=None):
        """
        Eq.(18): Binary cross-entropy training.
        """
        self.model.train()
        criterion = nn.BCELoss()
        best_val_loss = float('inf')
        patience_counter = 0
        for epoch in range(epochs):
            total_loss = 0.0
            for xb, yb in train_loader:
                xb = xb.to(self.device)
                yb = yb.float().to(self.device)
                optimizer.zero_grad()
                _, scores = self.model(xb)
                loss = criterion(scores, yb)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
            avg_loss = total_loss / len(train_loader)
            if val_loader is not None:
                val_loss = self._validate(val_loader, criterion)
                print(f"Epoch {epoch+1}/{epochs} | Train Loss: {avg_loss:.4f} | Val Loss: {val_loss:.4f}")
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                    torch.save(self.model.state_dict(), "best_fda.pt")
                else:
                    patience_counter += 1
                    if patience_counter >= patience:
                        print(f"Early stopping at epoch {epoch+1}")
                        break
            else:
                print(f"Epoch {epoch+1}/{epochs} | Train Loss: {avg_loss:.4f}")

    def _validate(self, val_loader, criterion) -> float:
        self.model.eval()
        total_loss = 0.0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(self.device)
                yb = yb.float().to(self.device)
                _, scores = self.model(xb)
                total_loss += criterion(scores, yb).item()
        self.model.train()
        return total_loss / len(val_loader)
