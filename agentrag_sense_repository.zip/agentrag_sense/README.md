# AgentRAG-Sense

**A Multi-Agent Retrieval-Augmented Generation Framework for Context-Aware Anomaly Explanation and Self-Healing in 6G Industrial IoT Fog Networks**

Published in: *Computers, Materials & Continua (CMC)*

---

## Overview

AgentRAG-Sense coordinates four specialized agents to achieve autonomous anomaly detection, root-cause explanation, and self-healing remediation in 6G IIoT fog networks:

| Agent | Role | Latency |
|---|---|---|
| Fault Detector Agent (FDA) | TCN-based anomaly detection + symptom generation | 22 ms |
| Context Retriever Agent (CRA) | FAISS IVFPQ top-k retrieval from knowledge base | 7 ms |
| Explanation Generator Agent (EGA) | Phi-3-mini INT4 root-cause explanation | 54 ms |
| Self-Healing Orchestrator Agent (SHOA) | Parallel ONOS SDN/NFV playbook execution | 8 ms |

---

## Repository Structure

```
agentrag_sense/
├── agents/
│   ├── fault_detector_agent.py         # FDA: TCN + symptom descriptor
│   ├── context_retriever_agent.py      # CRA: FAISS IVFPQ retrieval
│   ├── explanation_generator_agent.py  # EGA: Phi-3-mini INT4 + CoT
│   ├── self_healing_orchestrator.py    # SHOA: ONOS SDN + poison guard
│   └── agentrag_sense_pipeline.py      # End-to-end Algorithm 1
├── knowledge_base/
│   └── kb_construction.py             # Algorithm 2: 3-step KB pipeline
├── datasets/
│   └── dataset_loader.py              # SWaT / BATADAL / WADI loaders
├── ns3_sim/
│   └── ns3_6g_simulation.py           # 3GPP TR 38.901 UMa emulation
├── evaluation/
│   └── metrics.py                     # F1 / EA / MTTR / ablation
├── scripts/
│   ├── train_and_evaluate.py          # Full experiment pipeline
│   └── generate_figures.py            # Figures 8-14 (IEEE 600 dpi)
├── configs/
│   └── ns3_config.json                # NS-3 6G channel parameters
├── requirements.txt
└── README.md
```

---

## Installation

```bash
pip install -r requirements.txt
```

### Optional: Phi-3-mini INT4 (llama.cpp)

```bash
pip install llama-cpp-python
```

Download the GGUF model:
```
https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf
```

### Optional: NS-3.42

Download and build from https://www.nsnam.org/releases/ns-3-42/

---

## Datasets

Place datasets in the `data/` directory:

| Dataset | Source | Files needed |
|---|---|---|
| SWaT | https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/ | SWaT_Dataset_Normal_v1.xlsx, SWaT_Dataset_Attack_v0.xlsx |
| BATADAL | https://www.batadal.net/data.html | BATADAL_dataset03.csv, BATADAL_dataset04.csv |
| WADI | https://itrust.sutd.edu.sg/itrust-labs_datasets/dataset_info/ | WADI_14days_new.csv, WADI_attackdataLABELED_10.csv |

If dataset files are not present, the loaders automatically generate synthetic data that matches each dataset's statistical properties (samples, features, anomaly rate).

---

## Usage

### Train and evaluate on all datasets (seed=42):
```bash
python scripts/train_and_evaluate.py --dataset all --seed 42
```

### Train on a single dataset:
```bash
python scripts/train_and_evaluate.py --dataset swat --seed 42
```

### With Phi-3-mini INT4 LLM:
```bash
python scripts/train_and_evaluate.py \
  --dataset all \
  --seed 42 \
  --llm_path models/phi-3-mini-4k-instruct-q4.gguf
```

### Generate all paper figures (Figures 8-14):
```bash
python scripts/generate_figures.py
```

Output figures are saved to `outputs/figures/` at 600 dpi.

---

## Key Parameters (Table 4 from paper)

| Parameter | Value |
|---|---|
| Framework | PyTorch 2.2 + LangChain 0.2 |
| FDA backbone | TCN, W=60, h=128, dilations {1,2,4,8,16} |
| LLM | Phi-3-mini 3.8B, INT4 (llama.cpp) |
| Edge hardware | NVIDIA Jetson AGX Orin 32 GB |
| FAISS index | IVFPQ, nlist=256, m=64 |
| Knowledge base | 50,000 records, 3.2 MB |
| SDN controller | ONOS 2.7 (northbound REST API) |
| NS-3 | 3.42, 3GPP TR 38.901 UMa, 28 GHz, 100 MHz |
| Optimizer | AdamW, lr=1e-4, weight_decay=0.01 |
| Batch size | 256 |
| Epochs | 80 (early stopping, patience=10) |
| Random seed | 42 |

---

## NS-3 6G Channel Configuration

| Parameter | Value |
|---|---|
| Channel model | 3GPP TR 38.901 Urban Macro (UMa) |
| Carrier frequency | 28 GHz |
| Bandwidth | 100 MHz |
| Delay profile | CDL-C, RMS delay spread = 100 ns |
| Fog nodes | N=10, star topology |
| Inter-node latency | 2-8 ms (uniform) |
| tau_API | 5 ms (measured ONOS REST, not assumed) |
| Path loss exponent | alpha=3.5 |
| Shadowing std | 4 dB |

---

## Results (Table 6 from paper)

| Method | SWaT F1 | BATADAL F1 | WADI F1 | EA (%) |
|---|---|---|---|---|
| LSTM-AE | 0.812 | 0.829 | 0.752 | n/a |
| GATformer | 0.865 | 0.872 | 0.804 | n/a |
| RAGLog | 0.852 | 0.861 | 0.793 | 79.2 |
| LLM-EI | 0.876 | 0.884 | 0.830 | n/a |
| LLMRCA | 0.889 | - | - | n/a |
| SDN-Slice-Sec | 0.898 | 0.832 | 0.825 | 84.3 |
| **AgentRAG-Sense** | **0.954** | **0.960** | **0.938** | **97.4** |

MTTR: 34 s (vs 14.3 min human-in-the-loop baseline)

---

## Reproducibility

All experiments use `--seed 42`. Results are within:
- F1: ±0.007
- EA: ±0.6%
- MTTR: ±3 s

across five runs with different seeds (confirmed with seed=123 in paper).

---

## Citation

```
@article{agentrag_sense_2026,
  title   = {A Multi-Agent Retrieval-Augmented Generation Framework
             for Context-Aware Anomaly Explanation and Self-Healing
             in 6G Industrial IoT Fog Networks},
  journal = {Computers, Materials \& Continua},
  year    = {2026}
}
```
