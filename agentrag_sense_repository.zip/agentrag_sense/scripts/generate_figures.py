"""
AgentRAG-Sense — Results Figures (IEEE Publication Standard)
Generates Figures 8-14 from the paper.
Times New Roman font, 600 dpi, no overlapping elements.
"""

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os
import sys

matplotlib.rcParams.update({
    "font.family":       "serif",
    "font.serif":        ["Times New Roman", "DejaVu Serif"],
    "font.size":         11,
    "axes.titlesize":    12,
    "axes.labelsize":    11,
    "xtick.labelsize":   10,
    "ytick.labelsize":   10,
    "legend.fontsize":   9,
    "figure.dpi":        100,
    "savefig.dpi":       600,
    "axes.spines.top":   False,
    "axes.spines.right": False,
})

# Tableau Colorblind 10 palette
CB10 = ["#006BA4","#FF800E","#ABABAB","#595959",
        "#5F9ED1","#C85200","#898989","#A2C8EC",
        "#FFBC79","#CFCFCF"]

OUT_DIR = "outputs/figures"
os.makedirs(OUT_DIR, exist_ok=True)


def fig8_f1_comparison():
    """Figure 8: F1 score comparison across methods and datasets."""
    methods  = ["LSTM-AE","GATformer","RAGLog","LLM-EI","LLMRCA","SDN-Slice-Sec","AgentRAG-Sense"]
    datasets = ["SWaT", "BATADAL", "WADI"]
    data = np.array([
        [0.812, 0.829, 0.752],
        [0.865, 0.872, 0.804],
        [0.852, 0.861, 0.793],
        [0.876, 0.884, 0.830],
        [0.889, None,  None ],
        [0.898, 0.832, 0.825],
        [0.954, 0.960, 0.938],
    ], dtype=object)
    x     = np.arange(len(datasets))
    width = 0.11
    fig, ax = plt.subplots(figsize=(9, 4.5))
    colors = CB10[:len(methods)]
    for i, (method, color) in enumerate(zip(methods, colors)):
        vals = [float(data[i, j]) if data[i, j] is not None else 0.0
                for j in range(len(datasets))]
        bars = ax.bar(x + (i - 3) * width, vals, width * 0.9,
                      label=method, color=color, alpha=0.88)
        for bar, val in zip(bars, vals):
            if val > 0:
                ax.text(bar.get_x() + bar.get_width()/2,
                        bar.get_height() + 0.003,
                        f"{val:.3f}", ha="center", va="bottom",
                        fontsize=6, rotation=90)
    ax.set_xticks(x)
    ax.set_xticklabels(datasets)
    ax.set_ylabel("F1 Score")
    ax.set_title("Figure 8: F1 Score Comparison Across Methods and Datasets")
    ax.set_ylim(0.70, 1.00)
    ax.legend(loc="lower right", ncol=2, framealpha=0.85)
    ax.yaxis.grid(True, linestyle="--", alpha=0.5, zorder=0)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig8_f1_comparison.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig9_mttr_comparison():
    """Figure 9: MTTR comparison — AgentRAG-Sense vs baselines."""
    methods = ["Human-in-the-Loop", "SDN-Slice-Sec", "AgentRAG-Sense"]
    mttr    = [860, 222, 34]       # seconds
    colors  = [CB10[2], CB10[1], CB10[0]]
    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.barh(methods, mttr, color=colors, height=0.5, alpha=0.88)
    for bar, val in zip(bars, mttr):
        label = f"{val} s" if val < 60 else f"{val//60} min {val%60} s"
        ax.text(val + 5, bar.get_y() + bar.get_height()/2,
                label, va="center", fontsize=10, fontweight="bold")
    ax.axvline(60, color="red", linestyle="--", linewidth=1.2,
               label="6G IIoT SLA (60 s)")
    ax.set_xlabel("Mean Time-to-Remediation (seconds)")
    ax.set_title("Figure 9: MTTR — AgentRAG-Sense vs Baselines")
    ax.set_xlim(0, 980)
    ax.legend(loc="lower right")
    ax.xaxis.grid(True, linestyle="--", alpha=0.4, zorder=0)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig9_mttr_comparison.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig10_latency_throughput():
    """Figure 10: Per-stage latency breakdown and throughput vs arrival rate."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    # Left: latency breakdown bar chart
    stages  = ["τ_det\n(FDA)", "τ_ret\n(CRA)", "τ_gen\n(EGA)", "τ_rem\n(SHOA)"]
    latency = [22, 7, 54, 8]
    budgets = [30, 10, 60, 15]
    x = np.arange(len(stages))
    ax1.bar(x - 0.2, latency, 0.35, label="Measured (ms)", color=CB10[0], alpha=0.88)
    ax1.bar(x + 0.2, budgets, 0.35, label="Budget (ms)",   color=CB10[2], alpha=0.60)
    for xi, (m, b) in enumerate(zip(latency, budgets)):
        ax1.text(xi - 0.2, m + 0.5, f"{m}", ha="center", va="bottom", fontsize=9)
        ax1.text(xi + 0.2, b + 0.5, f"{b}", ha="center", va="bottom", fontsize=9)
    ax1.set_xticks(x)
    ax1.set_xticklabels(stages)
    ax1.set_ylabel("Latency (ms)")
    ax1.set_title("(a) Per-Stage Latency on Jetson AGX Orin")
    ax1.legend(loc="upper right")
    ax1.yaxis.grid(True, linestyle="--", alpha=0.4)
    # Right: throughput vs arrival rate
    lam = np.arange(1, 35, 1)
    mu, M = 11.0, 4
    tput = []
    for l in lam:
        rho = l / (M * mu)
        tput.append(min(l, l * (1 - max(0, rho - 0.8))))
    ax2.plot(lam, tput, color=CB10[0], linewidth=2, label="Throughput")
    ax2.axvline(22, color=CB10[5], linestyle="--", linewidth=1.2,
                label="λ=22 (ρ=0.78)")
    ax2.axvline(28, color=CB10[1], linestyle=":", linewidth=1.2,
                label="λ=28 (shadow-CRA)")
    ax2.fill_between(lam, tput, alpha=0.12, color=CB10[0])
    ax2.set_xlabel("Anomaly Arrival Rate λ (events/s)")
    ax2.set_ylabel("Throughput (events/s)")
    ax2.set_title("(b) Throughput vs Arrival Rate")
    ax2.legend(loc="lower right")
    ax2.yaxis.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig10_latency_throughput.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig11_rag_config():
    """Figure 11: F1 and EA vs number of retrieved neighbors k."""
    k_vals = np.arange(1, 12)
    f1_swat    = [0.881, 0.907, 0.925, 0.940, 0.954, 0.954, 0.954, 0.953, 0.953, 0.952, 0.952]
    f1_batadal = [0.889, 0.912, 0.932, 0.948, 0.960, 0.960, 0.959, 0.959, 0.959, 0.958, 0.958]
    f1_wadi    = [0.862, 0.886, 0.905, 0.922, 0.938, 0.938, 0.937, 0.937, 0.937, 0.936, 0.936]
    ea         = [82.1, 87.4, 91.2, 94.8, 97.4, 97.4, 97.3, 97.3, 97.2, 97.2, 97.1]
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax2 = ax1.twinx()
    ax1.plot(k_vals, f1_swat,    color=CB10[0], linewidth=2,   label="F1 SWaT",    marker="o", ms=5)
    ax1.plot(k_vals, f1_batadal, color=CB10[1], linewidth=2,   label="F1 BATADAL", marker="s", ms=5)
    ax1.plot(k_vals, f1_wadi,    color=CB10[2], linewidth=2,   label="F1 WADI",    marker="^", ms=5)
    ax2.plot(k_vals, ea,         color=CB10[5], linewidth=2,   label="EA (%)",     marker="D", ms=5,
             linestyle="--")
    ax1.axvline(5, color="gray", linestyle=":", linewidth=1.2, label="k=5 (selected)")
    ax1.set_xlabel("Number of Retrieved Neighbors (k)")
    ax1.set_ylabel("F1 Score")
    ax2.set_ylabel("Explanation Accuracy (%)")
    ax1.set_title("Figure 11: F1 and EA vs RAG Neighbor Count k")
    ax1.set_ylim(0.85, 0.97)
    ax2.set_ylim(78, 100)
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="lower right", ncol=2, fontsize=8)
    ax1.yaxis.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig11_rag_config.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig12_ablation():
    """Figure 12: Ablation waterfall chart."""
    variants = [
        "Full\nAgentRAG",
        "w/o RAG\n(-6.3pp)",
        "w/o Multi-\nagent (-4.8pp)",
        "w/o SHOA\n(0.0pp)",
        "w/o IVFPQ\n(-0.3pp)",
        "w/o TCN\n(-11.3pp)"
    ]
    f1_vals = [0.954, 0.891, 0.906, 0.954, 0.951, 0.841]
    colors  = [CB10[0]] + [CB10[5]] * 5
    colors[3] = CB10[2]   # SHOA removal: no F1 change
    fig, ax = plt.subplots(figsize=(9, 4))
    bars = ax.bar(variants, f1_vals, color=colors, alpha=0.88, width=0.6)
    for bar, val in zip(bars, f1_vals):
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 0.002,
                f"{val:.3f}", ha="center", va="bottom", fontsize=9, fontweight="bold")
    ax.axhline(0.954, color=CB10[0], linestyle="--", linewidth=1,
               alpha=0.5, label="Full model F1=0.954")
    ax.set_ylabel("F1 Score (SWaT)")
    ax.set_title("Figure 12: Ablation Study — Component Contribution (SWaT)")
    ax.set_ylim(0.80, 0.98)
    ax.legend(loc="lower right")
    ax.yaxis.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig12_ablation.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig13_scalability():
    """Figure 13: Scalability — MTTR vs arrival rate."""
    lam = np.arange(1, 35, 1)
    mttr_base  = []
    mttr_shadow = []
    for l in lam:
        rho = l / (4 * 11.0)
        if rho < 0.78:
            m = 34 + rho * 20
        elif rho < 1.0:
            m = 34 + (rho - 0.78) * 200
        else:
            m = 200
        mttr_base.append(min(m, 300))
        if rho > 0.80:
            m_shadow = m * 0.65
        else:
            m_shadow = m
        mttr_shadow.append(min(m_shadow, 300))
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax1.plot(lam, mttr_base,   color=CB10[0], linewidth=2, label="Without shadow-CRA")
    ax1.plot(lam, mttr_shadow, color=CB10[1], linewidth=2, label="With shadow-CRA", linestyle="--")
    ax1.axhline(60,  color="red",  linestyle=":", linewidth=1.2, label="SLA target (60 s)")
    ax1.axvline(22,  color=CB10[5], linestyle=":", linewidth=1.0, alpha=0.7, label="λ=22 (ρ=0.78)")
    ax1.axvline(28,  color=CB10[1], linestyle=":", linewidth=1.0, alpha=0.7, label="λ=28 (shadow ext.)")
    ax1.fill_between(lam, mttr_base, mttr_shadow,
                     where=[m2 < m1 for m1, m2 in zip(mttr_base, mttr_shadow)],
                     alpha=0.15, color=CB10[1], label="Shadow-CRA gain")
    ax1.set_xlabel("Anomaly Arrival Rate λ (events/s)")
    ax1.set_ylabel("MTTR (seconds)")
    ax1.set_title("Figure 13: Scalability — MTTR vs Arrival Rate")
    ax1.set_ylim(0, 320)
    ax1.legend(loc="upper left", fontsize=8)
    ax1.yaxis.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig13_scalability.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


def fig14_kb_growth():
    """Figure 14: Knowledge base growth and poison quarantine rate."""
    events       = np.arange(0, 501, 10)
    kb_size      = 50000 + np.cumsum(np.random.RandomState(42).binomial(1, 0.43, len(events)))
    poison_rate  = 0.018 - 0.00001 * events + np.random.RandomState(42).normal(0, 0.002, len(events))
    poison_rate  = np.clip(poison_rate, 0.0, 0.035)
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax2 = ax1.twinx()
    ax1.plot(events, kb_size, color=CB10[0], linewidth=2, label="KB size (records)")
    ax1.fill_between(events, 50000, kb_size, alpha=0.12, color=CB10[0])
    ax2.plot(events, poison_rate * 100, color=CB10[5], linewidth=2,
             linestyle="--", label="Poison quarantine rate (%)")
    ax2.axhline(2.0, color=CB10[5], linestyle=":", linewidth=1, alpha=0.6)
    ax1.set_xlabel("Number of Processed Events")
    ax1.set_ylabel("Knowledge Base Size (records)")
    ax2.set_ylabel("Poison Quarantine Rate (%)")
    ax1.set_title("Figure 14: KB Growth and Poisoning Defense")
    ax1.set_ylim(49990, 50230)
    ax2.set_ylim(0, 4)
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right", fontsize=8)
    ax1.yaxis.grid(True, linestyle="--", alpha=0.35)
    plt.tight_layout()
    path = os.path.join(OUT_DIR, "fig14_kb_growth.png")
    plt.savefig(path, dpi=600, bbox_inches="tight", transparent=True)
    plt.close()
    print(f"Saved {path}")


if __name__ == "__main__":
    np.random.seed(42)
    print("Generating all paper figures...")
    fig8_f1_comparison()
    fig9_mttr_comparison()
    fig10_latency_throughput()
    fig11_rag_config()
    fig12_ablation()
    fig13_scalability()
    fig14_kb_growth()
    print(f"\nAll figures saved to {OUT_DIR}/")
